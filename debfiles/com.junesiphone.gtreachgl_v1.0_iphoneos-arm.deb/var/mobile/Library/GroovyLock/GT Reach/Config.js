 var Celsius = false; // Celsius
 var Locale = "38671"; //Set your location here.
 var TwentyFourHourClock = false;  //24 Hour Clock
 var Kph = false; //kph
 var Curlanguage = "en"; //options "de","fr","sp","it","zh" type P to get phone language
 var GPS = false;
 var removeBG = true;
 var WeatherRefresh = 10; //in minutes
