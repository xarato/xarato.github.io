

/*
variables handled by Options.plist
var citycode = '38671';
var celsiusOn = true;
var gpsOn = false;
var refreshTime = '10';
var twentyfourOn = false;
var padzeroOn = true;
*/


//clock
clock({
  twentyfour : twentyfourOn,
  padzero : padzeroOn,
  refresh : 5000,
  success: function(clock){
    $$('.time').set(clock.hour() + ':' + clock.minute());
    $$('.date').set(clock.monthnum() + '/' + clock.date() + '/' + clock.year());
    $$('.day').set(clock.daytext());
  }
});
//miniWeather
miniWeather({
  code : citycode,
  temp : celsiusOn,// true for celsius, false for fareinheit
  lang : 'en',
  gps : gpsOn, //must use WidgetWeather xml if set to true
  refresh : refreshTime, // in minutes
  success: function(w){
    $$('.temp').set(w.temp + '&deg;');
    $$('.condition').set(w.condition);
    $$('.city').set(w.city);
    $$('.icon').sel().src = 'weather/' + w.icon + '.svg';
    showSVG('.icon', true);
  }
});
