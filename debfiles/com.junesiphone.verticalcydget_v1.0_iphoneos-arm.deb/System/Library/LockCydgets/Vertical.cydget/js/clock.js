/*
 ______     __         ______     ______     __  __
/\  ___\   /\ \       /\  __ \   /\  ___\   /\ \/ /
\ \ \____  \ \ \____  \ \ \/\ \  \ \ \____  \ \  _"-.
 \ \_____\  \ \_____\  \ \_____\  \ \_____\  \ \_\ \_\
  \/_____/   \/_____/   \/_____/   \/_____/   \/_/\/_/

Mini Clock Library
Website: http://JunesiPhone.com
Creator: JunesiPhone
*/
(function () {
    "use strict";
    var d = new Date(),
        clock = {
            hour: function (twentyfour, zero) {
                var hour = (twentyfour === true) ? d.getHours() : (d.getHours() > 12) ? d.getHours() - 12 : d.getHours();
                hour = (zero === true) ? (hour < 10 ? "0" : "") + hour : hour;
                return hour;
            },
            minute: function () {
                return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
            },
            am: function () {
                return (d.getHours() > 11) ? "pm" : "am";
            },
            date: function () {
                return d.getDate();
            },
            month: function () {
                return d.getMonth();
            }
        };
    window.clock = clock;
}());

