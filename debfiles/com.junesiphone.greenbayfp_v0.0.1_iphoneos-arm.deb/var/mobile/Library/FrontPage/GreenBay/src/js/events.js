//open search
document.getElementById('search').addEventListener('touchstart', function(el) {
    window.location = 'frontpage:opensearch';
});

//music
document.getElementById('musicHolder').addEventListener('touchstart', function(el) {
    switch (el.target.id) {
        case 'back':
            window.location = 'frontpage:prevtrack';
            break;
        case 'play':
            window.location = 'frontpage:playmusic';
            break;
        case 'forward':
            window.location = 'frontpage:nexttrack';
            break;
    }
});

//openDrawer
document.getElementById('appDrawer').addEventListener('touchstart', function(el) {
    FPI.drawer.toggleDrawer();
});

/* 
	Homescreen 
	Switch from weather showing to music showing.
*/

document.getElementById('down').addEventListener('touchstart', function() {
    $("#weatherHolder").animate({
        opacity: '0'
    }, 300);
    $("#musicHolder").animate({
        top: "-60",
        opacity: '1'
    }, 300);
});
document.getElementById('up').addEventListener('touchstart', function() {
    $("#weatherHolder").animate({
        top: "0",
        opacity: '1'
    }, 300);
    $("#musicHolder").animate({
        top: "100",
        opacity: '0'
    }, 300);
});


function appToBundle(app) {
    switch (app) {
        case 'phone':
            openApp('com.apple.mobilephone');
            break;
        case 'sms':
            openApp('com.apple.MobileSMS');
            break;
        case 'camera':
            openApp('com.apple.camera');
            break;
        case 'mail':
            openApp('com.apple.mobilemail');
            break;
        case 'battery':
            openApp('com.apple.Preferences');
            break;
        case 'photos':
            openApp('com.apple.mobileslideshow');
            break;
        case 'safari':
            openApp('com.apple.mobilesafari');
            break;
        case 'settings':
            openApp('com.apple.Preferences');
            break;
        case 'youtube':
            openApp('com.google.ios.youtube');
            break;
        case 'facebook':
            openApp('com.facebook.Facebook');
            break;
        case 'twitter':
            openApp('com.tapbots.Tweetbot4');
            //openApp('com.atebits.Tweetie2');
            break;
        case 'google':
            openApp('com.google.GooglePlus');
            break;
        case 'music':
            openApp(musicApp);
            break;
    }
}

document.getElementById('song').addEventListener('touchstart', function() {
    openApp(musicApp);
});
document.getElementById('middleIcon').addEventListener('touchstart', function(el) {
    appToBundle(el.target.id);
});
document.getElementById('middlebg').addEventListener('touchstart', function(el) {
    appToBundle(el.target.id);
});
document.getElementById('social').addEventListener('touchstart', function(el) {
    appToBundle(el.target.id);
});

document.getElementById('music').addEventListener('touchstart', function(el) {
    appToBundle('music');
});