// History (please do not remove this section when you fork)
//  Sep-18-2009 Written by Satoshi Nakajima (for WidgetPad.com launch)
 
// Global variables
var msecLast; // date.getTime() at the last frame
var cursors; // an array of Cursor objects
var distances; // distances between each pair of Cursor objects
var images; // an array of pre-rendered images

// Various "const" parameters
var kSpeed = 40; // pixels/sec
var kObjects = 8; // number of Cursor objects
var kDelay=1; // delay between frames (in msec)
var kImageCount = 16; // number of images

var kWall = 40; // distance from the wall
var kWallAngle = 240; // influence from the wall (degree*100)
var kCollision = 20; // collision distance (negative)
var kCollisonAngle = 120; // influence by a possible collision (degree*100)
var kGather = 50; // gathering distance (positive)
var kGatherAngle = 90; // influence to swim together (degree*100)

// Extra global variable to measure the frame rate
var msecFirst;
var frames = 0; 

window.addEventListener("load", function(){
  try {
    /* Hide the status bar */
    setTimeout(function() { window.scrollTo(0, 1); }, 10);

    /* To prevent scrolling, call WidgetPad.noscroll(true); */
    WidgetPad.noscroll(true);
    
    // Initialize msecLast and msecFirst
    var date = new Date;
    msecLast = date.getTime();
    msecFirst = msecLast;

    // Create an array of Cursor objects and add them to the "stage"
    var stage = document.getElementById('stage');
    distances = [];
    cursors = [];
    for (i=0; i<kObjects; i++) {
       cursors[i] = new Cursor(i, window.innerWidth/2, window.innerWidth/2, kSpeed, i*10*100);
       stage.appendChild(cursors[i].element);
       distances[i] = []; // nested array
    }
    
    // Pre-render a series of fish images
    images = [];
    for (i=0; i<kImageCount; i++) {
        images[i] = new FishImage(i/kImageCount);
    }
    
    // Start the animation
    setTimeout(updateFrame, kDelay);
  }
  catch (e) {
    WidgetPad.error(e);
  }
}, false);

function FishImage(ratio) {
    // Create an off-screen canvas element (we will never append to the DOM)
    this.canvas = document.createElement("canvas");
    this.canvas.width = 20;
    this.canvas.height = 40;
    
    // Render the image of fish
    var ctx = this.canvas.getContext('2d');
    ctx.fillStyle = "rgba(255,40,0,0.8)";
    ctx.beginPath();
    var xTail = 10+6*Math.sin(2*Math.PI*ratio);
    ctx.moveTo(10, 0);
    ctx.bezierCurveTo(12,0,13,3,13,10);
    ctx.bezierCurveTo(13,12,13,20,xTail,40);
    ctx.bezierCurveTo(7,20,7,12,7,10);
    ctx.bezierCurveTo(7,3,8,0,10,0);
    ctx.fill();
}

function Cursor(i, x,y,speed,deg) {
    this.i = i;
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.deg = deg;
    this.element = document.createElement("canvas");
    this.element.width = 20;
    this.element.height = 40;
    this.element.className = "fish";
}

Cursor.prototype.move = function(elapsed) {
  try {
    with (this) {
      x += speed * Math.cos(deg * Math.PI / 18000) * elapsed;
      y -= speed * Math.sin(deg * Math.PI / 18000) * elapsed;
      var dAngle = 0;

      var dir = new Direction(deg);
      var fWallS = y > 360 - kWall;
      var fWallN = y < kWall;
      var fWallE = x > window.innerWidth - kWall;
      var fWallW = x < kWall;
      if (fWallS && !dir.north) {
          dAngle = dir.west ? -kWallAngle : kWallAngle; 
      } else if (fWallN && !dir.south) {
          dAngle = (dir.west || fWallE) ? kWallAngle : -kWallAngle; 
      } else if (fWallE && !dir.west) {
          dAngle = dir.south ? -kWallAngle : kWallAngle; 
      } else if (fWallW && !dir.east) {
          dAngle = dir.south ? kWallAngle : -kWallAngle; 
      } 
       var countC = 0; // number of fish that are too close
       var xC = 0;
       var yC = 0;
       var countG = 0; // number of fish that are close enough to swim together
       var totalG = 0;
       for (j in cursors) {
          var c1 = cursors[j];
          var d = distances[i][j];
          if (d< kCollision) {
              xC += c1.x;
              yC += c1.y;
              countC++;
          }
          if (d< kGather) {
             totalG += c1.deg; 
             countG++;
          }
        }
        if (countC>0) {
          // Find the center of them and swim away from it
          xC /= countC;
          yC /= countC;
          var angle = Math.floor(Math.atan2(y - yC, xC-x) / Math.PI * 18000);
          var angle2 = (angle - deg + 72000) % 36000;
          if (angle2<9000 || angle2>27000) {
             dAngle += (angle2<18000) ? -kCollisonAngle : kCollisonAngle;
          }
        } else if (countG>0) {
          // Find the average direction and swith together
          var angle = Math.floor(totalG / countG + countG/2);
          angle = (angle - deg + 36000) % 36000;
          if (angle > kGatherAngle && angle < 36000-kGatherAngle) {
            dAngle += (angle<18000) ? kGatherAngle : -kGatherAngle;
          }
        }
     
     // The actual influence should be proportional to the elapsed time
     deg = (deg + dAngle * elapsed * 50 + 72000) % 36000;

     // Set the location and direction of the fish
     this.element.style.WebkitTransform = "translateX("+x+"px) translateY("+(y-20)+"px) rotate("+(90-Math.floor(deg/100))+"deg)";
     this.element.style.MozTransform = "translateX("+x+"px) translateY("+(y-20)+"px) rotate("+(90-Math.floor(deg/100))+"deg)";
 
     // Draw the fish (using one of pre-rendered image)
     var ctx = this.element.getContext('2d');
     ctx.clearRect(0, 0, 20, 40);
     var index = Math.floor(kImageCount * msecLast/1000 + i) % kImageCount;
     ctx.drawImage(images[index].canvas,0,0);
    }
  } catch (e) {
    WidgetPad.error(e);
  }
};

function Direction(angle) {
    angle = angle % 36000;
    this.north = (angle<18000);
    this.east = (angle<9000 || angle>27000);
    this.south = (angle>18000);
    this.west = (angle>9000 && angle<27000);
}
 
function updateFrame() {
  try {
    // Calculate the time between this frame and the last frame
    var date = new Date;
    var elapsed = (date.getTime() - msecLast) / 1000;
    msecLast = date.getTime();
    
    // Calculate the distance between each pair (no clustering optimization)
    for (i in cursors) {
       var c0 = cursors[i];
       distances[i][i] = 100000000; // large enough to ignore itself
       for (j=0; j<i; j++) {
           var c1 = cursors[j];
           var dx = c0.x - c1.x;
           var dy = c0.y - c1.y;
           var d = Math.sqrt(dx*dx + dy*dy);
           distances[i][j] = d;
           distances[j][i] = d;
       }
    }

    // Move all the cursors
    for (i in cursors) {
      cursors[i].move(elapsed);
    }
    
    // Output the frame rate for each 100 frame
    frames++;
    if (frames % 100 == 0) {
       var span = document.getElementById('fps');
       //span.innerHTML = Math.floor(frames/(msecLast-msecFirst)*1000*100+100)/100 + " fps";
    }
    setTimeout(updateFrame, kDelay);
  } catch (e) {
    WidgetPad.error(e);
  }
}