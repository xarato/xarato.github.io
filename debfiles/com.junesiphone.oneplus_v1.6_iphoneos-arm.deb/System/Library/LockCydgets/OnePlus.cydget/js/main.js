
var twentyfour = (localStorage.twentyfour) ? JSON.parse(localStorage.twentyfour) : false;
var alwaysshow = (localStorage.alwaysshow) ? JSON.parse(localStorage.alwaysshow) : false;
var replaceagenda = (localStorage.agenda) ? JSON.parse(localStorage.agenda) : false;
var mini = (localStorage.mini) ? JSON.parse(localStorage.mini) : false;
var blur = (localStorage.noblur) ? JSON.parse(localStorage.noblur) : false;
showSVG('.alarmico', true);

if(mini){
    $$('#panel').sel().style.marginTop = "160px";
    $$('.line').sel().style.marginTop = "-155px";
    $$('.swipe').sel().style.marginTop = "-155px";
    $$('.agenda').sel().style.marginTop = "20px";
}

if(localStorage.onepluscolor){
    var css = ".ani{background-color:"+localStorage.onepluscolor+"};.off{background-color:"+localStorage.onepluscolor+"};.panel{background-color:"+localStorage.onepluscolor+"};";

    var htmlDiv = document.createElement('div');
    htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
    document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);
}
if(localStorage.oneplustcolor){
    var nscolor = localStorage.oneplustcolor;
    var css = "html{color:"+nscolor+";}.line{background-color:"+nscolor+";}#weathericons{fill:"+nscolor+";}#clocksvg{fill:"+nscolor+"; }";

    var htmlDiv = document.createElement('div');
    htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
    document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);
}

if (blur) {
    var css = "#panel{-webkit-backdrop-filter:blur(0px);}";
    var htmlDiv = document.createElement('div');
    htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
    document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);
}

function showall(){
    var allevents = [];
    var evnt = getcalendarEvents(0,0);
    for (var i = 0; i < evnt.length; i++) {
        allevents.push(evnt[i].split(':')[1]);
    };
    allevents = String(allevents).replace(/,/g, '\n');
    swal({   title: "Events",   text: allevents, animation: "slide-from-top", confirmButtonColor: "#4f4f4f"  });
}

function colorchange(){
swal({
        title: "Change BG color, to change text type text:color.",
        text: "You can use color, hex, or rgba.",
        type: "input",
        showCancelButton: true,
        confirmButtonColor: "#4f4f4f",
        closeOnConfirm: true,
        animation: "slide-from-top",
        inputPlaceholder: "#52b5d5"
    },
    function(inputValue) {
        if (inputValue === false) {document.body.scrollTop = 0; return false;}
        if (inputValue === "") {
            swal.showInputError("You need to write something!");
            return false
        }
        if(inputValue.split(':')[0] == "text"){
            localStorage.setItem('oneplustcolor',inputValue.split(':')[1]);
            var ncolor = inputValue.split(':')[1];
            var css = "html{color:"+ncolor+";}.line{background-color:"+ncolor+";}#weathericons{fill:"+ncolor+";}#clocksvg{fill:"+ncolor+"; }";
            var htmlDiv = document.createElement('div');
            htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
            document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);
            document.body.scrollTop = 0;
        }
        else{
        $$('.ani').sel().style.backgroundColor = inputValue;
        localStorage.setItem('onepluscolor',inputValue);
        document.body.scrollTop = 0;
        }
        //location.reload();
    });
}


$$('.reminder').set((getcalendarEvents(0,0) === "No Events") ? "Nothing on the agenda" : getcalendarEvents(0,0)[0].split(':')[1]);


if(getcalendarEvents(0,0).length > 1){
    if(getcalendarEvents(0,0) !== "No Events"){
        $$('.reminder').set($$('.reminder').inner()+"<span class='more'> +"+ (getcalendarEvents(0,0).length - 1)+" </span>");
        $$('.more').sel().addEventListener('touchend',function(){
            showall()
        });
    }
}


function opens(){
    if($$('.panel').sel()){
        $$('.panel').sel().className = "ani";
    }
    else{
        $$('.off').sel().className = "ani";
    }
    $$('.open').sel().style.display = "none";
};


var el = $$('.panel').sel();
swipedetect(el, function(swipedir){
    if (swipedir =='down'){
        $$('.ani').sel().className = "off";
        $$('.open').sel().style.display = "block";
        if(mini){
            $$('#panel').sel().style.marginTop = "160px";
            $$('.line').sel().style.marginTop = "-155px";
            $$('.swipe').sel().style.marginTop = "-155px";
            $$('.agenda').sel().style.marginTop = "20px";
        }

    }
    else if (swipedir == 'right'){
        unlockphone();
    }
    else if (swipedir == 'left'){
        colorchange();
    }
    else if (swipedir == 'up'){
        $$('#panel').sel().style.marginTop = "0px";
        $$('.line').sel().style.marginTop = "0px";
        $$('.swipe').sel().style.marginTop = "0px";
        $$('.agenda').sel().style.marginTop = "0px";
    }
});

var el2 = $$('.open').sel();
swipedetect(el2, function(swipedir){
    if (swipedir =='up'){
        opens();
    }
    else if (swipedir == 'right'){
        unlockphone();
    }

});

var pad = true;
$$('.time').set(clock.hour(twentyfour,pad)+":"+clock.minute());
$$('.date').set(weekday[clock.day()] + " " + clock.date() + " " + month[clock.month()]);


var setAlarm, alarmHour, alarmMinute, padMinute;
setAlarm = iOSAlarms.getAlarmTimes();
if (setAlarm !== "No Alarms") {
    alarmHour = Number(setAlarm[0].split(':')[0]);
    alarmMinute = Number(setAlarm[0].split(':')[1]);
    if(!twentyfour){
        alarmHour = alarmHour - 12;
    }
    padMinute = (alarmMinute < 10) ? "0" + alarmMinute : alarmMinute;
    $$('.alarm').set("Alarm " + alarmHour + ":" + padMinute);
} else {
    $$('.alarm').set('Alarm not set');
}

try{
    var celsius = (localStorage.celsius) ? JSON.parse(localStorage.celsius) : false;
}catch(err){
    localStorage.celsius = null;
}


var weatherdivs = function () {
   $$('.wicon').sel().src = "svg/"+weather.condition()+".svg";
   showSVG('.wicon', true);

   if(replaceagenda){
        $$('.agenda').set('Weather');
        $$('.reminder').set((celsius) ? Fcondition[weather.condition()]+ ", " + weather.temp(celsius)+"&deg;C" : Fcondition[weather.condition()]+ ", " + weather.temp(celsius)+"&deg;F")
    }
};


weather.start(60000 * 15);

//localStorage.clear();

$$('.time').sel().addEventListener('touchend',function(){
sset.create('Twenty-Four','twentyfour','#52d568');
sset.create('Celsius','celsius','#52d568');
sset.create('Always-Show','alwaysshow','#52d568');
sset.create('Show-Weather','agenda','#52d568');
sset.create('Mini','mini','#52d568');
sset.create('NoBlur','noblur','#52d568');

$$('.ani').sel().className = "off";
        $$('.open').sel().style.display = "block";
});

if(alwaysshow){
    opens();
}

if(!localStorage.welcome){
    alert("Welcome to OnePlus Cydget, to begin swipe up from the bottom. Tap time to show options, swipe left to change colors.");
    localStorage.welcome = true;
}
