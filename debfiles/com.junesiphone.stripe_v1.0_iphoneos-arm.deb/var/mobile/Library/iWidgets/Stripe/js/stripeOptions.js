/*
  ________     ___   ________
 /"       )   |"  | /"       )
(:   \___/    ||  |(:   \___/
 \___  \      |:  | \___  \
  __/  \\  ___|  /   __/  \\
 /" \   :)/  :|_/ ) /" \   :)
(_______/(_______/ (_______/
Library to make writing js quicker
Website: http://JunesiPhone.com
Creator: JunesiPhone
*/
(function (window, document) {
    "use strict";
    function sJS(selector) {
        var doc = document,
            funcObj = {
                el: doc.querySelector(selector),
                sel: function () {
                    return this.el;
                },
                inner: function () {
                    return this.el.innerHTML;
                },
                set: function (inner) {
                    this.el.innerHTML = inner;
                },
                color: function (color) {
                    this.el.style.color = color;
                },
                append: function (content) {
                    this.el.innerHTML += content;
                },
                clear: function () {
                    this.el.innerHTML = null;
                }
            };
        return funcObj;
    }
    window.sJS = window.$$ = sJS;
}(window, document));



///// This is from Stripe its bad:(

                //document.getElementById('city').className = TextColor;
                //document.getElementById('city').innerHTML = 'Loading...';
                document.getElementById('overlay').src = 'images/' + OvSet + '.png';

                if (colors == 'Black') {
                    document.getElementById('line').src = 'images/lineblack.png';
                    var all = document.getElementsByClassName('TextColorWhite');
                        for (var i = 0; i < all.length; i++) {
                          all[i].style.color = '#000';
                        }
                        $$('#city').color('#000');
                        $$('#desc').color('#000');
                        $$('#temp').color('#000');
                        $$('#highlowtemp').color('#000');
                        $$('#time').color('#000');
                        $$('#date').color('#000');
                }
                else {
                    document.getElementById('line').src = 'images/linewhite.png';
                }

                if (design == 'No_conditions') { //hide desc
                    $$('#desc').sel().style.display = 'none';
                    $$('#weathericon').sel().style.display = 'none';
                    $$('#line').sel().style.height = '75px';
                    $$('#overlay').sel().style.height = '110px';
                }
                // Small_conditions = design in css file
                else if (design == 'Big_icon_on_bottom') {  //icon on bottom
                    $$('#city').sel().style.textAlign = 'right';
                    $$('#city').sel().style.left = "-132px";
                    $$('#city').sel().style.top = "97px";
                    $$('#weathericon').sel().style.top = "72px";
                    $$('#weathericon').sel().style.height = "70px";
                    $$('#weathericon').sel().style.width = "70px";
                    $$('#desc').sel().style.top = "118px";
                    $$('#line').sel().style.height = "120px";
                    $$('#overlay').sel().style.height = "150px";

                }
                else if (design == 'Big_icon_on_top') { //icon on top
                    $$('#city').sel().style.textAlign = 'right';
                    $$('#city').sel().style.left = "-132px";
                    $$('#city').sel().style.top = "97px";
                    $$('#temp').sel().style.top = "69px";
                    $$('#temp').sel().style.fontSize = "42px";
                    $$('#highlowtemp').sel().style.top = "115px";
                    $$('#weathericon').sel().style.top = "11px";
                    $$('#weathericon').sel().style.height = "70px";
                    $$('#weathericon').sel().style.width = "70px";
                    $$('#desc').sel().style.top = "118px";
                    $$('#line').sel().style.height = "120px";
                    $$('#overlay').sel().style.height = "150px";
                }