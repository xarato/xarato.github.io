/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  window,
  show,
  weather,
  weathercode,
  clock,
  twentyfour,
  translate,
  current
*/

(function () {
    var doc = document,
        panel1 = doc.querySelector('.panel1'),
        sub = doc.getElementById('subPanels');

    panel1.addEventListener('touchstart', function () {
        sub.classList.toggle('hidden');
    }, false);

    if (show) {
        sub.className = '';
    }

    var convert = function (amount) {
        return Math.round((amount - 32) * 5 / 9);
    };


    weather({
        code: weathercode,
        temp: false,
        lang: 'en',
        gps: false, //must use WidgetWeather xml if set to true
        refresh: 15, // in minutes
        success: function (w) {
            var days = 2, //how many days, can also do w.fDesc.length
                i,
                fhigh,
                flow,
                rtemp,
                rhigh,
                rlow;
            for (i = 0; i < days; i += 1) {

                fhigh = (celsius) ? convert(w.fHigh[i + 1]) : w.fHigh[i + 1];
                flow = (celsius) ? convert(w.fLow[i + 1]) : w.fLow[i + 1];
                doc.getElementById('day' + (i + 1) + 'day').innerHTML = w.fDayshort[i + 1];
                doc.getElementById('day' + (i + 1) + 'lohi').innerHTML = fhigh + '&deg;' + ' / ' + flow + '&deg;';
                doc.getElementById('day' + (i + 1) + 'icon').src = 'src/icon/' + w.fIcon[i + 1] + '.png';
            }

            rtemp = (celsius) ? convert(w.temp) : w.temp;
            rhigh = (celsius) ? convert(w.high) : w.high;
            rlow = (celsius) ? convert(w.low) : w.low;


            doc.getElementById('temp').innerHTML = rtemp + '&deg;';
            doc.getElementById('condition').innerHTML = w.condition;
            doc.getElementById('icon').src = 'src/icon/' + w.icon + '.png';
            doc.getElementById('wind').innerHTML = w.windspd + ' ' + w.winddir;
            doc.getElementById('hilo').innerHTML = rhigh + '&deg; / ' + rlow + '&deg;';
            doc.getElementById('rain').innerHTML = w.pop + '%';

        }
    });

    clock({
        twentyfour: twentyfour,
        padzero: true,
        refresh: 1000,
        success: function (clock) {
            doc.getElementById('time').innerHTML = clock.hour() + ":" + clock.minute() + clock.am();
            doc.getElementById('date').innerHTML = translate[current].weekday[clock.day()] + ', ' + clock.date() + ' ' + translate[current].month[clock.month()];
        }
    });

}());
