
//replace index of string
String.prototype.replaceAt = function (index, replace) {
    return this.substr(0, index) + replace + this.substr(index + replace.length);
}

//change css style that is defined in the html
var changeCSS = function (ruleName) { // Return requested style object
    ruleName = ruleName.toLowerCase(); // Convert test string to lower case.
    var styleSheet,
        i,
        ii,
        cssRules,
        cssRule = false; // Initialize cssRule.
    if (document.styleSheets) { // If browser can play with stylesheets
        for (i = 0; i < document.styleSheets.length; i += 1) { // For each stylesheet
            styleSheet = document.styleSheets[i];
            if (!styleSheet.href) {
                if (styleSheet.cssRules) { // Browser uses cssRules?
                    cssRules = styleSheet.cssRules; // Yes --Mozilla Style
                } else { // Browser usses rules?
                    cssRules = styleSheet.rules; // Yes IE style.
                } // End IE check.
                if (cssRules) {
                    for (ii = 0; ii < cssRules.length; ii += 1) {
                        cssRule = cssRules[ii];
                        if (cssRule) { // If we found a rule...
                            // console.log(cssRule);
                            if (cssRule.selectorText) {
                                //console.log(cssRule.selectorText);
                                if (cssRule.selectorText.toLowerCase() == ruleName) { //  match ruleName?
                                    return cssRule; // return the style object.
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return false; // we found NOTHING!
};