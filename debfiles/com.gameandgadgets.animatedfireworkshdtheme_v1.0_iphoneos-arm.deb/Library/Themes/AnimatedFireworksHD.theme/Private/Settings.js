// MultiBarLockscreen v2.0 Public Beta
// Theme by DouweM
// Based on Lockscreen3Bars by johnwalker and stelmax
// Lockbackground.png by Bram de Vogel

//GENERAL SETTINGS//

var UseCustomText          = true;        //Toggles the use of the CustomTextBar

var CustomText             = "iLove my iPhone"; //The text shown on the in the CustomTextBar


var UseLockBar             = true;         //Toggles the use of the LockBar, disabling this can be useful if you want to use Slide to Unlock

var LockTextLeft           = "Unlock";     //The text shown on the left side of the LockBar

var LockTextRight          = "iDevice";    //The text shown on the right side of the LockBar

var LockTextColor          = "";           //The color (in text: 'red' or HEX: '#FFFFFF') used to show the text on the LockBar, use an empty string ("") if you want to use the original color


//CLOCK SETTINGS//

var UseBigClock            = false;        //Toggles the use of the big 28px clock


var ClockDateFormat        = ""; //Format of the date, check the table at http://us.php.net/manual/en/function.date.php for information about the available characters.
//                           "[l], [F] [d]"       -> "Thursday, April 09"
//                           "[l], [F] [j]"       -> "Thursday, April 9"
//                           "[l], [F] [j][S]"    -> "Thursday, April 9th"
//                           "[l], [j][S] of [F]" -> "Thursday, 9th of April"
//                           "[n]/[j]/[Y]"        -> "4/9/2009"
//                           "[n]/[j]/[y]"        -> "4/9/09"

var ClockTimeFormat        = ""; //Format of the time, check the table at http://us.php.net/manual/en/function.date.php for information about the available characters.
//                           "[H]:[i]"            -> "09:24"
//                           "[G]:[i]"            -> "9:24"
//                           "[h]:[i]"            -> 16:24 as "04:24"
//                           "[g]:[i]"            -> 16:24 as "4:24"
//                           "[h]:[i] [A]"        -> 16:24 as "04:24 PM"
//                           "[g]:[i] [A]"        -> 16:24 as "4:24 PM"
//                           "[h]:[i] [a]"        -> 16:24 as "04:24 pm"
//                           "[g]:[i] [a]"        -> 16:24 as "4:24 pm"


//QUOTEWIDGET SETTINGS//

var EnableQuoteWidget      = false;        //Toggles the use of QuoteWidget


//WEATHER SETTINGS//

var EnableWeather          = false;         //Toggles the use of the WeatherBar


var WeatherSource          = "Yahoo";      //The source to use for fetching the weather: 'Apple' or 'Yahoo'. Yahoo is the fastest

var WeatherLocale          = "UKXX1421";   //If WeatherSource is Yahoo: Go to weather.yahoo.com, find your city, copy the code you see in the URL, it looks somewhat like "USNY0996"
                                           //If WeatherSource is Apple: 'Defiance, Ohio' or 'Moscow, Russia' or 'Ledyard, AT' or 'London, UK' etc.


var WeatherIconSet         = 'tick';      //The icon set to use, you can choose between 'klear' and 'tick'


var WeatherUseCelsius      = true;        //Toggles between Celcius (true) and Fahrenheit (false)

var WeatherUseRealFeel     = true;        //When you use Real Feel (true), the temperature will take into account Wind Chill, Humidity etc.


var WeatherBarLeft         = "Desc";       //What do you want to be on the left in the WeatherBar? You can choose between 'City', 'Desc' or your own custom text, use an empty string ('') if you want to leave it empty
var WeatherBarSemiRight    = "City"        //What do you want to be on the semi-right in the WeatherBar? You can choose between 'City', 'Desc' or your own custom text, use an empty string ('') if you want to leave it empty
var WeatherBarIconPlace    = "BeforeTemp"; //Where do you want the WeatherIcon to be placed?
//                           "Left"       -> [ICON] [Left]                 [SemiRight] [Temp]
//                           "Wifi"       -> [Left]      [ICON]            [SemiRight] [Temp]
//                           "Center"     -> [Left]               [ICON]   [SemiRight] [Temp]
//                           "BeforeTemp" -> [Left]                 [SemiRight] [ICON] [Temp]
//                           "Right"      -> [Left]                 [SemiRight] [Temp] [ICON]
//                           0-301        -> You can also use a number to specify the distance of icon to the left of the screen in pixels


var WeatherUpdateInterval  = 15;           //Weather update interval in minutes


//STATUSNOTIFIER SETTINGS//

var EnableNotifier         = true;         //Toggles the use of the NotificationBars (StatusNotifier must be installed)

var NotifierUpdateInterval = 3;            //Notifier update interval in seconds


var ShowEvents             = false;         //Toggles the events to be shown or not (Lockscreen Info must be installed)

var EventItems             = 3;            //The number of events to be shown

var EventsAutoExpand       = false;         //If true, the events will automatically expand


var ShowPreviews           = false;         //Toggles previews (details about missed calls, mails etc) to be shown or not (Lockscreen Info must be installed)

var PreviewItems           = 2;            //The number of previews to be shown

var PreviewsAutoExpand     = false;        //If true, the previews will automatically expand


var NotifierDateFormat     = "[l], [F] [d]"; //Format of the date, check the table at http://us.php.net/manual/en/function.date.php for information about the available characters.
//                           "[l], [F] [d]"       -> "Thursday, April 09"
//                           "[l], [F] [j]"       -> "Thursday, April 9"
//                           "[l], [F] [j][S]"    -> "Thursday, April 9th"
//                           "[l], [j][S] of [F]" -> "Thursday, 9th of April"
//                           "[n]/[j]/[Y]"        -> "4/9/2009"
//                           "[n]/[j]/[y]"        -> "4/9/09"

var NotifierEndDateFormat  = "[M] [d]";      //Format of the end-date if different than the start-date, check the table at http://us.php.net/manual/en/function.date.php for information about the available characters.
//                           "[M] [d]"            -> "Apr 9"
//                           "[M] [j]"            -> "Apr 09"
//                           "[n]/[j]"            -> "4/9"

var NotifierTimeFormat     = "[g]:[i] [A]";  //Format of the time, check the table at http://us.php.net/manual/en/function.date.php for information about the available characters.
//                           "[H]:[i]"            -> "09:24"
//                           "[G]:[i]"            -> "9:24"
//                           "[h]:[i]"            -> 16:24 as "04:24"
//                           "[g]:[i]"            -> 16:24 as "4:24"
//                           "[h]:[i] [A]"        -> 16:24 as "04:24 PM"
//                           "[g]:[i] [A]"        -> 16:24 as "4:24 PM"
//                           "[h]:[i] [a]"        -> 16:24 as "04:24 pm"
//                           "[g]:[i] [a]"        -> 16:24 as "4:24 pm"


var NotifierUpdateInterval = 3;           //Notifier update interval in seconds

//TWITTER SETTINGS//

var EnableTwitter          = false;       //Toggles the use of the TwitterBar

var TwitterAccount         = "";   //TwitterAccount to fetch timeline for

var TwitterPassword        = "";  //Password for TwitterAccount 
//Setting your password here is perfectly safe. 
//It's directly sent to the Twitter-servers via the Twitter API. 
//There is no way for me or anybody else to steal the password because you set it here.

var TwitterItems           = 3;           //The number of statuses to be shown

var TwitterTruncate        = false;       //If true, the status will be truncated if longer than 40 characters

var TwitterAutoExpand      = false;        //If true, the timeline will automatically expand

var TwitterUpdateInterval  = 5;           //Timeline update interval in minutes


//LOCALIZABLE STRINGS//

var WeekdayNames      = new Array("Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi");
var ShortWeekdayNames = new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat");
var MonthNames        = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
var ShortMonthNames   = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug","Sep", "Oct", "Nov", "Dec");
//Just edit the names in the lines above.

var WeatherDesc = new Array();
WeatherDesc['Unknown']                 = "Unknown";

WeatherDesc['Fair']                    = "Fair";

WeatherDesc['Clear']                   = "Clear";
WeatherDesc['Mostly Clear']            = "Mostly Clear";

WeatherDesc['Cloudy']                  = "Cloudy";
WeatherDesc['Partly Cloudy']           = "Partly Cloudy";
WeatherDesc['Mostly Cloudy']           = "Mostly Cloudy";
WeatherDesc['Overcast']                = "Overcast";

WeatherDesc['Sunny']                   = "Sunny";
WeatherDesc['Partly Sunny']            = "Partly Sunny";
WeatherDesc['Mostly Sunny']            = "Mostly Sunny";

WeatherDesc['Fog']                     = "Fog";
WeatherDesc['Light Fog']               = "Light Fog";

WeatherDesc['Drizzle']                 = "Drizzle";
WeatherDesc['Light Drizzle']           = "Light Drizzle";
WeatherDesc['Light Rain']              = "Light Rain";
WeatherDesc['Rain']                    = "Rain";
WeatherDesc['Rain Shower']             = "Rain Shower";
WeatherDesc['Light Rain Shower']       = "Light Rain Shower";
WeatherDesc['Showers in the Vicinity'] = "Showers in the Vicinity";
/*
You can translate the WeatherDescriptions above, by editing like this:
WeatherDesc['ENGLISH DESCRIPTION'] = "DESCRIPTION IN YOUR OWN LANGUAGE";
These are not all WeatherDescriptions you can get, of course. You can add more translations by copying that line to the ones above.
*/


var Notifications = new Array();

Notifications['Silent']   = "";
Notifications['Events']   = "";
  
Notifications['Call'] = new Array(
  "1",       //one item
  "[Count]" //more than one items
);
  
Notifications['Voicemail'] = new Array(
  "",
  ""
);
  
Notifications['SMS'] = new Array(
  "1",
  "[Count]"
);
  
Notifications['MMS'] = new Array(
  "",
  ""
);
  
Notifications['Mail'] = new Array(
  "1",
  "[Count]"
);
  
Notifications['IM'] = new Array(
  "",
  ""
);
  
Notifications['RSS'] = new Array(
  "1",
  "[Count]"
);