var rssArray = ['blank', 'Quotes-http://feeds.feedburner.com/quotationspage/qotd', 'World News-http://feeds.reuters.com/Reuters/worldNews', 'Entertainment-http://feeds.reuters.com/reuters/entertainment', 'Media-http://feeds.reuters.com/news/reutersmedia', 'Science-http://feeds.reuters.com/reuters/scienceNews', 'Top News-http://feeds.reuters.com/reuters/topNews', 'Little Man-http://feeds.feedburner.com/DumbLittleMan', 'Crunch Gear-http://feeds.feedburner.com/crunchgear', 'CNN-http://rss.cnn.com/rss/cnn_topstories','Modmyi-http://feeds.modmyi.com/home_all'];
var rsscount = 0;
var feedname = feedstuff.split('-')[0]; //pulled from Option.plist
var feedurl = feedstuff.split('-')[1]; //pulled from Option.plist

var callRSSAjax = function (url) {
    document.getElementById('rss').innerHTML = '';
    var xmlhttp,
        s = '',
        def = {
            ShowDesc: true,
            ShowPubDate: true,
            CharacterLimit: 0,
            TitleLinkTarget: "_blank",
            DateFormat: "",
            DateFormatLang: "en"
        };
    xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4) {
            var data = JSON.parse(xmlhttp.responseText),
                item,
                datePD;
            for (item in data.responseData.feed.entries) {
                if (data.responseData.feed.entries.hasOwnProperty(item)) {
                    item = data.responseData.feed.entries[item];
                    s += '<li><div class="itemTitle"><a href=' + item.link + ' target="_blank" onclick=openlink("' + item.link + '") >' + item.title + "</a></div>";
                    if (def.ShowPubDate) {
                        datePD = new Date(item.publishedDate);
                        s += '<div class="itemDate">' + datePD.toLocaleDateString() + "</div>";
                    }
                    if (def.ShowDesc) {
                        if (def.DescCharacterLimit > 0 && item.content.length > def.DescCharacterLimit) {
                            s += '<div class="itemContent">' + item.content.substr(0, def.DescCharacterLimit) + "...</div>";
                        } else {
                            s += '<div class="itemContent">' + item.content + "</div>";
                        }
                    }
                }
            }
            document.getElementById('rss').innerHTML = '<div id="name">' + feedname + '</div><ul class="feedlist">' + s + '</ul>';
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
};
function togglefeed(state) { //called from changePage function
    'use strict';
    if (state === 'open') {
        document.getElementById('rssarrows').style.display = "block";
        feedname = feedstuff.split('-')[0];
        callRSSAjax("http://ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=5&output=json&q=" + feedurl + "&hl=en");
    } else {
        document.getElementById('rssarrows').style.display = "none";
        document.getElementById('rssfeeds').innerHTML = "";
    }
}
function changefeed(state) { //called from nextrss onclick
    'use strict';
    var newurl;
    if (rsscount >= rssArray.length) {
        rsscount = 0;
    }
    if (state === 'next') {
        rsscount += 1;
        newurl = "http://ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=5&output=json&q=" + rssArray[rsscount].split('-')[1] + "&hl=en";
        feedname = rssArray[rsscount].split('-')[0];
        callRSSAjax(newurl);
    } else {
        rsscount = ((rsscount - 1) <= 0) ? 0 : rsscount - 1;
        newurl = "http://ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=5&output=json&q=" + rssArray[rsscount].split('-')[1] + "&hl=en";
        feedname = rssArray[rsscount].split('-')[0];
        callRSSAjax(newurl);
    }
}