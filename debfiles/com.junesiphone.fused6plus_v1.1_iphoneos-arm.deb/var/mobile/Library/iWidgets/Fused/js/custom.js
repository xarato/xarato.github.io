var css = '';
//var font = 'bebas'; var background = true; //Options.plist

if (!background) {
    css += '.container{background-color:transparent;}';
}

if (font === 'bebas') {
   css += 'body{font-family:bebas;}';
   css += '.time{font-size:45px;}';
   css += '.am{font-size:20px;margin-left:20px;}';
   css += '.batterypercent{font-size:20px;margin-left:-20px;}';
   css += '.selectBlock li{font-size:20px;margin-top: 13px;}';
   css += '.selectBlock .selected{font-size:35px}';
   css += '.condition{font-size:25px;}.temp{font-size:30px;margin-top:12px;}.hilo{font-size:20px;}';
   css += '.bfirst li{margin-left:12px; font-size:20px;}';
   css += '.date{font-size:50px;margin-top:5px;}.month{font-size:20px;margin-top:10px;}';
   css += '.todo{font-size:20px;margin-left:-50px;}';
   css += 'label{font-size:13px;bottom:4px;text-shadow: 0px 2px black;}';
   css += '#rsstext{margin-left:47px;top:15px;font-size:15px;}';
   css += '#memory,#space{margin-top:3px;font-size:20px}';
   css += '#mavail,#mused,#savail,#sused{font-size:15px;}';
   css += '#devicename{font-size:20px;}';
   css += '.musictext{font-size:25px;}.apptext{font-size:15px;margin-top:10px;}';
   css += '.newstitle{font-size:25px;}.newspost{font-size:15px;margin-top:10px;}.safarinews{margin-top:20px;-webkit-transform:scale(1.8);}';
   css += '#favapps{font-size:25px;}#titleapps{font-size:15px;margin-top:10px;}#respring{margin-top:20px;-webkit-transform:scale(1.5);}#respringtext{font-size:12px}';
   css += '#edit{font-size:20px;}';
   css += '.firstApp:after, .secondApp:after, .fourthApp:after{left:-53px;}';
   css += '.firstApp,.secondApp,.fourthApp{bottom:-8px;}';
}else if (font === 'porcha'){
    css += 'label{text-shadow: 0px 2px black;}';
}



var htmlDiv = document.createElement('div');
htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);