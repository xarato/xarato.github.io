/*
    Widget: A2k for iOS
    Creator: JunesiPhone
    Website: http://junesiphone.com
    Modder: NA

    This Javascript file is used to modify the colors
    It can be posted to the public by any on who mods it.

    Each section you can edit is marked by EDIT and ends
    with END EDIT.

    I would add this to Options.plist but I feel that is
    complicated to the majority of users to have a bunch of
    color options and they don't understand hex. Instead I will leave
    it here for modders to have an easy way of changing colors and sharing.

    If you modify the main html please do not post the code in its entirety,
    instead contact me and I will host it on my repo. Instead you can share
    this file EDITME.js and any .svg icons you might add.
*/

/* -------------------------EDIT APP SELECTION------------------------ */
/*
  There is two app icons on the page that open apps. You can change what
  app they open by editing the bundleID below.

  There is also only two icons located in this widget, you will need
  to add your own icon in the svg/ folder and put the name below.

  To make sure the color adjustments work properly when creating the svg
  make sure to use all fills and no strokes.
*/

/*EDIT*/
main.firstApp = 'com.apple.mobilemail';
main.secondApp = 'com.apple.MobileSMS';

var firstAppIcon = 'mail.svg',
    secondAppIcon = 'message.svg';
/*END EDIT*/

/* -----------------------ADJUST COLORS HERE--------------------------- */
/*
    Instead of having you edit many entries to change the colors I have
    categorized them below. You can edit the values below and change all
    of the colors to this widget.

    Default Settings
    var iconColor = 'white',
        darkColor = '#312f32',
        whiteColor = 'white',
        lightColor = '#737270',
        orangeColor = '#aa9053',
        dockColor = '#aa9053',
        selectedPage = "#312f32",
        notificationBadge = 'rgba(117,116,114,0.2)',
        notificationOdd = '#312f32',
        notificationOddText = 'white',
        notificationEven = '#312f32',
        notificationEvenText = '#aa9053',
        musicControlsC = "#312f32",
        musicControlsBG = '#cac1b2';
*/

/*EDIT*/
var iconColor = 'white', //dock and side
    darkColor = '#a1b74f', // top bar, notification bg
    whiteColor = 'black', //page color, app seperator, notification, time, month, track, artist, temp, city
    lightColor = 'white', //menubar
    orangeColor = 'white', // day, song, condition, notification even text
    dockColor = '#343434', //dock
    selectedPage = "#a1b74f", //selected page
    notificationBadge = 'rgba(117,116,114,0.2)', // notification badge
    notificationOdd = '#a1b74f', //odd number for notification
    notificationOddText = 'black', //odd number for notification
    notificationEven = 'rgba(255,255,255,0.3)', //even number for notification
    notificationEvenText = 'black', //even number for notification
    musicControlsC = '#312f32', //music controls
    musicControlsBG = '#a1b74f', // music bg
    batteryColor = '#a1b74f',
    appnotifyColor = '#a1b74f',
    appnotifyBG = '#343434';
/*END EDIT*/

/* ----------------------ADVANCED COLOR EDITING----------------------- */
/*
    You don't have to edit below this line, but you can.
    This is basically taking the colors from above and creating
    css that will override the stock settings.

    You could rearrange the code below, removing items from
    a color category and adding them to another. This is the reason
    they are not nested example: .top, .selected, .apps {color}
*/
var css = ""; //DON'T CHANGE

/*EDIT*/
//Dark Color
css += ".top{background-color:" + darkColor + "}" +
       ".apps{background-color: " + darkColor + ";}" +
       ".notifications{background-color: " + darkColor + ";}";
//selectedPage
css += ".selected{color:" + selectedPage + "!important;}";
//light color
css += ".menu{background-color: " + lightColor + "}";
//Notification Odd
css += ".notifications li:nth-child(even) {background-color: " + notificationEven + ";}";
//Notification Even
css += ".notifications li:nth-child(odd) {background-color: " + notificationOdd + ";}";
//Notification Odd Text
css += ".notifications li:nth-child(odd){color:" + notificationOddText + ";}";
//Notification Even Text
css += ".notifications li:nth-child(even) {color:" + notificationEvenText + ";}";
//whiteColor
css += ".pages div{color:" + whiteColor + ";}" +
       ".apps div{background-color:" + whiteColor + ";}" +
       "#NotificationsButton{ color: " + whiteColor + " }" +
       "#time, #month, #track, #artist,#temp,#city{color:" + whiteColor + ";}";
//orangeColor
css += "#day, #song,#condition{color:" + orangeColor + ";}";
//dock
css += ".dock{background-color:" + dockColor + ";}";
//notificationBadge
css += ".notifications li:before{background-color: " + notificationBadge + "}";
//musicControls
css += ".holder{background-color:" + musicControlsBG + "; border: 2px solid " + musicControlsBG + ";}";
//Icons
css += ".dock g, .apps g{fill:" + iconColor + ";}";
//Music Controls
css += ".buttons g{fill:" + musicControlsC + ";}";
//Battery
css += ".battery{background-color: " + batteryColor + ";}";

css += "#app1Notify,#app2Notify{background-color:" + appnotifyBG + ";color:" + appnotifyColor + ";}";
/*END EDIT*/


//FORECAST
// .temps li{color}
// .days li{color}

/* ----------------------ADVANCED DOM EDITING----------------------- */
/* Here you could edit any of the dom. This file loads after
   the document, so you could pretty much edit anything.
*/

/*
 Below is just an example, remove the // in front of $$('#NotificationsButton') to activate it.
 It moves the notification menu button down to above home.
 $$ is short for document.querySelector, which is like document.getElementById but you can select classes
 You also need to include # for ids and . for classes, id is shown below.
*/

/*EDIT*/

//$$('#NotificationsButton').style.top = '630px';
css += "#NotificationsButton,#search{color:#a1b74f;}";
css += '.icons div{background-color:#a1b74f;}';

/*END EDIT*/









/* ---------------------------DO NOT EDIT----------------------------- */
$$('#app1').src = 'svg/' + firstAppIcon;
$$('#app2').src = 'svg/' + secondAppIcon;
var htmlDiv = document.createElement('div');
htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);