var mnml = {
    target: null,
    changingIcon: false,
    changingApp: false,
    holder: document.getElementById('holder'),
    drawer: document.getElementById('drawertouch'),
    controls: document.getElementById('controls'),
    disableMusic: false,
    addEvents: function(){
        this.holder.addEventListener('touchend', function(el){
            var bundle = el.target.getAttribute('bundle');
            if(bundle && !mnml.changingIcon && !mnml.changingApp){
                openApp(bundle);
            }
        });
        this.drawer.addEventListener('touchstart', function(){
            Drawer.toggleDrawer();
        });
        taphold({
            time: 400,
            element: document.getElementById('holder'),
            action: function(target) {
                mnml.showPopup(target);
            },
            passTarget: true
        });
        this.controls.addEventListener('touchstart', function(el){
            if(el.target.id === 'play'){
                window.location = 'frontpage:playmusic';
            }
            if(el.target.id === 'next'){
                window.location = 'frontpage:nexttrack';
            }
            if(el.target.id === 'prev'){
                window.location = 'frontpage:prevtrack';
            }
        });
        document.getElementById('mnml').addEventListener('touchstart', function(el){
            if(el.target.className === 'mnml'){
                jSettings.closeSettings();
                jSettings.closeSettingsMenus();
                jSettings.closeColorPickers();
            }
        });
    },
    loadSavedApps: function(){
        this.holder.innerHTML = "";
        var iconBundles = lStorage.iconHolderBundles;
        for (var i = 0; i < iconBundles.length; i++) {
            var div = document.createElement('div'),
                bundle = iconBundles[i],
                icon = '/var/mobile/Library/FrontPageCache/' + bundle + '.png';
                if (lStorage.iconImageLocations[bundle]) {
                    icon = lStorage.iconImageLocations[bundle];
                }
                if(FPI.bundle[bundle]){
                    //app is installed
                    if(FPI.bundle[bundle].badge > 0){
                        div.innerHTML = "<div class='badge'></div>";
                    }else{
                        div.innerHTML = "";
                    }
                }else{
                    //app isn't installed or doesn't exist, give default icon.
                    icon = "src/addApp.png";
                }
                div.id = bundle;
                div.className = 'icon';
                div.setAttribute('bundle', bundle);
                div.style.backgroundImage = 'url("' + icon + '")';
                this.holder.appendChild(div);
        }
    },
    initSettings: function(){
        jSettings({
            options: ['colorMenu', 'togglesMenu', 'panelColor', 'panelTextColor', 'drawerColor', 'badgeColor', 'drawerBGColor', 'drawerBadgeColor', 'drawerLabelColor', 'drawerShortcutColor', 'iconRoundness', 'drawerButtonWidth', 'showTime', 'showBattery', 'hideBadge', 'hideService', 'disableMusic', 'roundDrawer', 'drawerShadow', 'dockShadow', 'clearIcons', 'clearUserSettings', 'respring'],
            colorMenu: {
                saveName: '',
                type: 'menu',
                menuID: 'colorMenu',
                placeholder: 'Color Options',
                callback: function(menu){
                    jSettings.closeSettings();
                    menu.style.display = 'block';
                }
            },
            togglesMenu:{
                saveName: '',
                type: 'menu',
                menuID: 'toggleMenu',
                placeholder: 'Toggles',
                callback: function(menu){
                    jSettings.closeSettings();
                    menu.style.display = 'block';
                }
            },
            panelColor: {
                menu: 'colorMenu',
                saveName: 'panelColor',
                type: 'input',
                color: true,
                defaultColor: 'rgba(0, 0, 0, 0.6)',
                placeholder: 'Dock Color',
                callback: function(input, ref){
                    document.querySelector('.panel').style.backgroundColor = input.value;
                    document.querySelector('.music').style.backgroundColor = input.value;
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            panelTextColor: {
                menu: 'colorMenu',
                saveName: 'panelTextColor',
                type: 'input',
                color: true,
                defaultColor: 'white',
                placeholder: 'Dock Text Color',
                callback: function(input, ref){
                    document.querySelector('.panel').style.color = input.value;
                    document.querySelector('.music').style.color = input.value;
                    document.getElementById('service').style.backgroundColor = input.value;
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            badgeColor: {
                menu: 'colorMenu',
                saveName: 'badgeColor',
                type: 'input',
                color: true,
                defaultColor: 'white',
                placeholder: 'Dock badge Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".badge", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerBGColor: {
                menu: 'colorMenu',
                saveName: 'drawerBGColor',
                type: 'input',
                color: true,
                defaultColor: 'rgba(0,0,0,0.3)',
                placeholder: 'Drawer bg Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".drawer_main", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerBadgeColor: {
                menu: 'colorMenu',
                saveName: 'drawerBadgeColor',
                type: 'input',
                color: true,
                defaultColor: 'black',
                placeholder: 'Drawer badge Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".drawer_icon::before", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerLabelColor: {
                menu: 'colorMenu',
                saveName: 'drawerLabelColor',
                type: 'input',
                color: true,
                defaultColor: 'white',
                placeholder: 'Drawer label Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".drawer_icon::after", "color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerShortcutColor: {
                menu: 'colorMenu',
                saveName: 'drawerShortcutColor',
                type: 'input',
                color: true,
                defaultColor: 'white',
                placeholder: 'Drawer shortcut Color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".shortcut", "color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerColor: {
                menu: 'colorMenu',
                saveName: 'drawerColor',
                type: 'input',
                color: true,
                defaultColor: 'rgba(255,255,255,0.6)',
                placeholder: 'Drawer button color',
                callback: function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], "#drawer", "background-color: " + input.value + "!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            iconRoundness: {
                saveName: 'iconRoundness',
                type: 'input',
                example: 'Number 0-100',
                placeholder: 'Dock icon roundness (0)',
                callback:function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], ".iconHolder div", "border-radius: " + input.value + "px!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            drawerButtonWidth: {
                saveName: 'drawerButtonWidth',
                type: 'input',
                example: 'Number 0-320',
                placeholder: 'Drawer button width (40)',
                callback:function(input, ref){
                    changeCSS.addRule(document.styleSheets[0], "#drawer", "width: " + input.value + "px!important;");
                    changeCSS.addRule(document.styleSheets[0], "#drawertouch", "width: " + input.value + 40 + "px!important;");
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.value);
                    }
                }
            },
            roundDrawer: {
                menu: 'toggleMenu',
                saveName: 'roundDrawer',
                type: 'toggle',
                placeholder: 'Round drawer icons',
                callback: function(input, ref){
                    if(input.checked){
                        changeCSS.addRule(document.styleSheets[0], ".drawer_icon", "border-radius: 99px!important;");
                    }else{
                        changeCSS.addRule(document.styleSheets[0], ".drawer_icon", "border-radius: 0px!important;");
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            drawerShadow: {
                menu: 'toggleMenu',
                saveName: 'drawerShadow',
                type: 'toggle',
                placeholder: 'Drawer shadows',
                callback: function(input, ref){
                    if(input.checked){
                        changeCSS.addRule(document.styleSheets[0], ".drawer_icon", "box-shadow: 0 8px 6px -6px rgba(0,0,0,0.6)!important;");
                    }else{
                        changeCSS.addRule(document.styleSheets[0], ".drawer_icon", "box-shadow: 0 8px 6px -6px rgba(0,0,0,0)!important;");
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            dockShadow: {
                menu: 'toggleMenu',
                saveName: 'dockShadow',
                type: 'toggle',
                placeholder: 'Dock shadows',
                callback: function(input, ref){
                    if(input.checked){
                        changeCSS.addRule(document.styleSheets[0], ".iconHolder div", "box-shadow: 0 8px 6px -6px rgba(0,0,0,0.6)!important;");
                    }else{
                        changeCSS.addRule(document.styleSheets[0], ".iconHolder div", "box-shadow: 0 8px 6px -6px rgba(0,0,0,0)!important;");
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            showTime: {
                menu: 'toggleMenu',
                saveName: 'showTime',
                type: 'toggle',
                placeholder: 'Hide Time',
                callback: function(input, ref){
                    if(input.checked){
                        document.getElementById('clock').style.display = "none";
                    }else{
                        document.getElementById('clock').style.display = "block";
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            showBattery: {
                menu: 'toggleMenu',
                saveName: 'showBattery',
                type: 'toggle',
                placeholder: 'Hide Battery',
                callback: function(input, ref){
                    if(input.checked){
                        document.getElementById('battery').style.display = "none";
                    }else{
                        document.getElementById('battery').style.display = "block";
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            hideService: {
                menu: 'toggleMenu',
                saveName: 'hideService',
                type: 'toggle',
                placeholder: 'Hide Service Icon',
                callback: function(input, ref){
                    if(input.checked){
                        document.getElementById('service').style.display = 'none';
                    }else{
                        document.getElementById('service').style.display = 'block';
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            disableMusic: {
                menu: 'toggleMenu',
                saveName: 'disableMusic',
                type: 'toggle',
                placeholder: 'Disable Music Player',
                callback: function(input, ref){
                    if(input.checked){
                        mnml.disableMusic = true;
                    }else{
                        mnml.disableMusic = false;
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            hideBadge: {
                menu: 'toggleMenu',
                saveName: 'hideBadge',
                type: 'toggle',
                placeholder: 'Hide Badge Icon',
                callback: function(input, ref){
                    if(input.checked){
                        changeCSS.addRule(document.styleSheets[0], ".badge", "opacity: 0!important;");
                    }else{
                        changeCSS.addRule(document.styleSheets[0], ".badge", "opacity: 1!important;");
                    }
                    if(ref){
                        lStorage.replaceStorageItem(ref, input.checked);
                    }
                }
            },
            clearIcons: {
                saveName: 'clearIcons',
                type: 'button',
                placeholder: 'Clear icon images',
                callback: function(input, ref){
                    jSettings.closeSettings();
                    jPopup({
                        type: "confirm",
                        message: "This removes all set icon images and will go to defaultt or whatever theme you have applied. Are you sure you want to do this?",
                        yesButtonText: "Yes",
                        noButtonText: "No",
                        functionOnNo: function() {
                            
                        },
                        functionOnOk: function() {
                            lStorage.replaceStorageItem('iconImageLocations', {});
                            location.href = location.href;
                        }
                    });
                }
            },
            clearUserSettings: {
                saveName: 'clearUserSettings',
                type: 'button',
                placeholder: 'Clear all user settings',
                callback: function(input, ref){
                    jSettings.closeSettings();
                    jPopup({
                        type: "confirm",
                        message: "This clears all settings back to defaultt. Are you sure you want to do this?",
                        yesButtonText: "Yes",
                        noButtonText: "No",
                        functionOnNo: function() {
                            
                        },
                        functionOnOk: function() {
                            localStorage.removeItem(lStorage.storageName);
                            location.href = location.href;
                        }
                    });
                }
            },
            respring: {
                saveName: 'respring',
                type: 'button',
                placeholder: 'Respring device',
                callback: function(input, ref){
                    location.href = 'frontpage:respring';
                }
            }
        });
        tripleTap({
            div: document.querySelector('.mnml'),
            callback: function(){
                document.getElementById('jSettings').style.display = "block";
            }
        });
    },
    initStorage: function(){
        lStorage.init({
            name: 'mnmlFP',
            storedNames: ['drawerButtonWidth', 'iconImageLocations', 'iconHolderBundles', 'panelColor', 'showTime', 'showBattery', 'badgeColor', 'hideService', 'roundDrawer', 'disableMusic', 'hideBadge', 'iconRoundness', 'drawerColor', 'drawerShadow', 'dockShadow', 'drawerBadgeColor', 'drawerLabelColor', 'drawerShortcutColor', 'panelTextColor', 'drawerBGColor'],
            storageItems: {
                iconImageLocations: {},
                iconHolderBundles: ['com.apple.mobilephone', 'com.apple.MobileSMS', 'com.apple.mobilemail', 'com.apple.mobilesafari', 'com.apple.Preferences']
            }
        });
    },
    init: function(){
        this.initStorage();
        this.initSettings();
        this.addEvents();
    },
    showPopup: function(target) {
        this.changingIcon = true;
        this.changingApp = true;
        this.target = target;
        jPopup({
            type: "confirm",
            message: "Choose an option below",
            yesButtonText: "Set App",
            noButtonText: "Set Icon",
            functionOnNo: function() {
                this.changeIcon = true;
                window.location = 'frontpage:loadIconBrowser';
            },
            functionOnOk: function() {
                this.changeApp = true;
                Drawer.toggleDrawer({
                    state: 'changingApp',
                    callback: function(newApp) {
                        mnml.changingIcon = false;
                        mnml.changingApp = false;
                        lStorage.replaceInAppArray('iconHolderBundles', mnml.target.getAttribute('bundle'), newApp);
                        mnml.loadSavedApps();
                    }
                });
            }
        });
    }
}
mnml.init();