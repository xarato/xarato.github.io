var FPI = {},
    createDrawer,
    startClock,
    openApp,
    appsInstalled,
    setFPIInfo,
    FPIloaded,
    loadApps,
    loadMusic,
    badgeUpdated,
    loadBattery,
    loadStatusBar,
    loadSystem,
    loadSwitcher,
    loadNotifications,
    loadFolders,
    loadAlarms,
    loadWeather,
    loadMemory,
    deviceUnlocked,
    selectedImageFromFP,
    selectedImageFromFPCanceled,
    wifiBars = [0, 5, 10, 15],
    signalBars = [100, 76, 52, 28, 0];

createDrawer = function() {
    //alert(window.innerHeight);
    var iconW = 11,
        iconM = 25,
        pagingAmount = 20;
    // iPhone X
    if (window.innerHeight == 812) {
        iconW = 12;
        iconM = 15;
        pagingAmount = 32;
    }
    //iPhone 6S+
    if(window.innerHeight == 736){
        iconW = 11;
        iconM = 18;
        pagingAmount = 28;
    }
    // iPhone 7
    if (window.innerHeight == 667) {
        iconW = 11;
        iconM = 23;
        pagingAmount = 20;
    }
    // iPhone 5, 5s, SE
    if (window.innerHeight == 568) {
        iconW = 12;
        iconM = 15;
        pagingAmount = 24;
    }
    FPI.drawer = new Drawer({
        labels: true,
        idPrefix: "APP",
        pagingAmount: pagingAmount,
        iconWidth: iconW,
        iconMargin: iconM,
        pageSpacing: 20,
        pagePadding: 10,
        labelTopPadding: 1,
        onClose: function(){
            mnml.changingApp = false;
            mnml.changingIcon = false;
        }
    });
};
startClock = function(){
    clock({
    twentyfour : (FPI.system.twentyfour == "yes") ? true : false,
    padzero : true,
    refresh : 1000,
    success: function(clock){
      document.getElementById('clock').innerHTML = clock.hour() + clock.minute();
    }
  });
};
openApp = function(bundle) {
    if (bundle === 'com.junesiphone.drawer') {
        Drawer.toggleDrawer();
    } else {
        window.location = 'frontpage:openApp:' + bundle;
    }
};
appsInstalled = function() {
    FPI.drawer.reloadIcons();
};
setFPIInfo = function(info, label, parse) {
    if (parse) {
        FPI[label] = JSON.parse(info);
    } else {
        FPI[label] = info;
    }
};
FPIloaded = function() {
    createDrawer();
    startClock();
    mnml.loadSavedApps();
};
badgeUpdated = function(bundle) {
    Drawer.updateBadge(bundle);
    if(document.getElementById(bundle)){
        if(FPI.bundle[bundle].badge > 0){
            document.getElementById(bundle).innerHTML = "<div class='badge'>" + FPI.bundle[bundle].badge + "</div>";
        }else{
            document.getElementById(bundle).innerHTML = "";
        }
    }
};
loadBattery = function() {
    document.getElementById('battery').innerHTML = FPI.battery.percent;
};
selectedImageFromFP = function(img){
  lStorage.replaceIconLocation('iconImageLocations', mnml.target.getAttribute('bundle'), img);
  mnml.loadSavedApps();
  mnml.changingIcon = false;
  mnml.changingApp = false;
};
selectedImageFromFPCancelled = function(){
  mnml.changingIcon = false;
  mnml.changingApp = false;
};
loadStatusBar = function() {
    var wifiState,
        wifiDIV = document.getElementById('service');
      if(FPI.statusbar.wifiName === "NA"){
        wifiState = "";
        wifiState = "url('src/css/service/signal" + FPI.statusbar.signalBars + ".png')";
      }else{
        wifiState = "";
        wifiState = "url('src/css/service/wifi" + FPI.statusbar.wifiBars + ".png')";
      }
      wifiDIV.style.cssText += '-webkit-mask-image:' + wifiState + ";";
};
loadMusic = function(){
    if(!mnml.disableMusic){
        var title = document.getElementById('title'),
        artist = document.getElementById('artist'),
        mainPage = document.querySelector('.mnml'),
        music = document.querySelector('.music'),
        playButton = document.getElementById('play');
      if(FPI.music.isPlaying){
        if(FPI.music.albumArt){
            mainPage.style.backgroundImage = "url('" + FPI.music.albumArt + "')";
        }
        music.style.display = "block";
        title.innerHTML = (FPI.music.title === '(null)') ? "" : FPI.music.title;
        if(FPI.music.title.length > 36){
            title.className = 'scrollAnimation';
        }
        artist.innerHTML = (FPI.music.artist === '(null)') ? "" : FPI.music.artist;
        if(FPI.music.artist.length > 36){
            artist.className = 'scrollAnimation';
        }
        play.innerHTML = "X";
      }else{
        music.style.display = "none";
        mainPage.style.backgroundImage = "url('')";
        play.innerHTML = "x";
      }
    }
};
loadSystem = function() {};
loadSwitcher = function() {};
loadNotifications = function() {};
loadFolders = function() {};
loadAlarms = function() {};
loadWeather = function() {};
loadMemory = function() {};
deviceUnlocked = function() {};
loadApps = function() {};