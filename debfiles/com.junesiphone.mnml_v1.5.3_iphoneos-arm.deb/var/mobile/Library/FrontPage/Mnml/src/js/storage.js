/*
	requires jpopup.js

	Usage -------------

	Saving Info:
		lStorage.replaceIconLocation('iconImageLocations', 'original.bundle', 'new.bundle');
		lStorage.replaceInAppArray('iconHolderBundles', 'com.apple.mobilephone', 'new.apple.bundle');
		lStorage.replaceStorageItem('default', true);
	
	Initializing lStorage:
		lStorage.init({
            name: 'mnml',
            storedNames: ['iconImageLocations', 'iconHolderBundles', 'default'],
            storageItems: {
                iconImageLocations: {},
                iconHolderBundles: ['com.apple.mobilephone', 'com.apple.MobileSMS', 'com.apple.mobilemail', 'com.apple.mobilesafari', 'com.apple.Preferences']
            }
        });

*/

var lStorage = {
	storageName: '',
	storedNames: [],
	saveStorage: function(){
		var save = {};
		for (var i = 0; i < this.storedNames.length; i++) {
			save[this.storedNames[i]] = this[this.storedNames[i]];
		}
		localStorage.setItem(this.storageName,JSON.stringify(save));
	},
	loadStorage: function(){
		var storage = JSON.parse(localStorage.getItem(lStorage.storageName)),
			i;
		if(storage != null){
			for (i = 0; i < this.storedNames.length; i++) {
				lStorage[this.storedNames[i]] = storage[this.storedNames[i]];
			}
		}
	},
	replaceInAppArray: function(array, older, newer){
		if(this[array].indexOf(newer) > -1){
			jPopup({
            	type: "alert",
            	message: "This app is already placed.",
            	okButtonText: "OK"
        	});
			return;
		}
		var index = this[array].indexOf(older);
        if (index !== -1) {
            this[array][index] = newer;
        }
        this.saveStorage();
	},
	replaceIconLocation: function(storageName, bundle, location){
		lStorage[storageName][bundle] = location;
        this.saveStorage();
	},
	replaceStorageItem: function(storageName, itemValue){
		lStorage[storageName] = itemValue;
		this.saveStorage();
	},
	clearStorage: function(){
		localStorage.removeItem(this.storageName);
	},
	init: function(object){
		if(!object){console.log('Must have an object (storage.js)');return;}
		var i;
		this.storageName = object.name;
		this.storedNames = object.storedNames;
		if(localStorage.getItem(object.name)){
			this.loadStorage();
			return;
		}
		for (i = 0; i < this.storedNames.length; i++) {
			lStorage[this.storedNames[i]] = object.storageItems[this.storedNames[i]];
		}
		if(localStorage.getItem([this.object] != null)){
			this.loadStorage();
		}
	}
};

