/*
	Important:
		<style> needs to be in the index.html above any other stylesheets
	Usage:
		changeCSS.addRule(document.styleSheets[0], ".wifi", "background-color:" + color + "!important");
		changeCSS.removeRule(document.styleSheets[0], ".wifi", "background-color");
*/

var changeCSS = {
	addRule: function (sheet, selector, styles) {
        if (sheet.insertRule) {
            return sheet.insertRule(selector + " {" + styles + "}", sheet.cssRules.length);
        }
        if (sheet.addRule) {
            return sheet.addRule(selector, styles);
        }
    },
    removeRule: function (sheet, selector, styles){
        var she, e, st;
        if(sheet.cssRules){
            for (she = 0; she < sheet.cssRules.length; she++) {
                if (sheet.cssRules[she].selectorText == selector) { 
                    //battery border is a special fuck
                    if(selector == "#battery"){
                        for (e = 0; e < sheet.cssRules[she].style.length; e++) {
                            st = sheet.cssRules[she].style[e];
                            if(st === "border-top-color"){
                                sheet.deleteRule(she);   
                            }
                        }
                    }
                    //all other css values
                    if(sheet.cssRules[she].style[0] == styles){
                        sheet.deleteRule(she);
                    }
                }
            }
        }
    }
};