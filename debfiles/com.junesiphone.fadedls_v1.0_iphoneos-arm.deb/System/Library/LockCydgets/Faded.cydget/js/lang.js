var language = window.navigator.language;
if(language.length > 2){
  language = language.split('-');
  language = language[0];
}
else{language=language;}

//language="zh";// tester

  if(language=="en"){
  var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  var menu = ["Today","Hourly","Daily","Settings"];
  var settingstxt = ["24hr Clock","Celsius","Kph","Weather Walls","Update Weather"];
  var updatedtxt = "Updated: ";
  var windchilltxt = "Wind Chill: ";
  var windtxt = "Wind: ";
  var feeltxt = "Feels Like";
  var sunrisetxt = "Sunrise: ";
  var sunsettxt = "Sunset: ";
  var textstringlater="Later Today: ";
  var humidtxt="Humidity: ";
  var warningtxt = "Warning ";
  var elevationtxt = "Elevation: ";
  var preciptxt = "Chance of rain: ";
  var dewpointtxt = "Dewpoint: ";
  var notxt = "No ";
  var visibilitytxt = "Visibility: ";
  var Fcondition = [ "Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank" ];
 
  }
  else if(language=="cz"){
  var weekday = ["Neděle","Pondělí","Úterý","Středa","Čtvrtek","Pátek","Sobota"];
  var month=["Leden","Únor","Březen","Duben","Květen","Červen","Červenec","Srpen","Září","Říjen","Listopad","Prosinec"];
  var smonth=["Led","Úno","Bře","Dub","Kvě","Čen","Čec","Srp","Zář","Říj","Lis","Pro"];
  var sday=["Ne","Po","Út","St","Čt","Pá","So"];
  var menu = ["Dnes","Po hodinách","Po dnech","Nastavení"];
  var settingstxt = ["24h zobrazení","Celsius","K/h","Weather Walls","Aktualizovat počasí"];
  var updatedtxt = "Aktualizováno: ";
  var windchilltxt = "Efektivní teplota: ";
  var windtxt = "Vítr: ";
  var feeltxt = "Pocitově";
  var sunrisetxt = "Východ slunce: ";
  var sunsettxt = "Západ slunce: ";
  var textstringlater="Dnes později: ";
  var humidtxt="Vlhkost: ";
  var warningtxt = "Varování ";
  var elevationtxt = "Elevation: ";
  var preciptxt = "Šance na déšť: ";
  var dewpointtxt = "Rosný bod: ";
  var notxt = "Ne ";
  var visibilitytxt = "Viditelnost: ";
  var Fcondition = [ "Tornádo", "Tropická bouře", "Hurikán", "Bouře", "Bouře", "Sněžení", "Déšť a sníh", "Déšť a sníh", "Mrznoucí mrholení", "Mrholení", "Mrznoucí déšť", "Přeháňky", "Přeháňky", "Poryvy větru", "Sněžení", "Sněžení", "Sněžení", "Kroupy", "Déšť a sníh", "Prach", "Mlhy", "Řídké mlhy", "Kouř", "Větrno s bouřkami", "Větrno", "Chladno", "Oblačno", "Oblačno", "Oblačno", "Oblačno", "Oblačno", "Jasno", "Slunečno", "Krásně", "Krásně", "Déšť a sníh", "Horko", "Bouře", "Bouře", "Bouře", "Přeháňky", "Husté sněžení", "Lehké sněžení", "Husté sněžení", "Polojasno", "Bouře", "Sněžení", "Bouře", "prázdné" ];
  }
  else if(language=="it"){
  var weekday = ['Domenica','Luned&#236','Marted&#236','Mercoled&#236','Gioved&#236','Venerd&#236','Sabato'];
  var month=["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];
  var smonth=["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"];
  var sday=["Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat"];
  var menu = ["Oggi","Ogni Ora","Quotidiano","Impostazioni"];
  var settingstxt = ["24hr Orologio","Centigrado","Kph","Walls meteo","Aggiornamento Meteo"];
  var updatedtxt = "Aggiornato: ";
  var windchilltxt = "Wind Chill: ";
  var windtxt = "Vento: ";
  var feeltxt = "Sembra";
  var sunrisetxt = "Alba: ";
  var sunsettxt = "Tramonto: ";
  var textstringlater="Più tardi oggi: ";
  var humidtxt="Umidità: ";
  var warningtxt = "Avvertimento ";
  var elevationtxt = "Elevazione: ";
  var preciptxt = "Possibilità di pioggia: ";
  var dewpointtxt = "Punto di rugiada: ";
  var notxt = "No ";
  var visibilitytxt = "Visibilità: ";
  var Fcondition = [ "Tornado", "Tempesta Tropicale", "Uragano", "Temporali Forti", "Temporali", "Pioggia mista a Neve", "Nevischio", "Nevischio", "Pioggia Gelata", "Pioggerella", "Pioggia Ghiacciata", "Pioggia", "Pioggia", "Neve a Raffiche", "Neve Leggera", "Tempesta di Neve", "Neve", "Grandine", "Nevischio", "Irregolare", "Nebbia", "Foschia", "Fumoso", "Raffiche di Vento", "Ventoso", "Freddo", "Nuvoloso", "Molto Nuvoloso", "Molto Nuvoloso", "Nuvoloso", "Nuvoloso", "Sereno", "Sereno", "Bel Tempo", "Bel Tempo", "Pioggia e Grandine", "Caldo", "Temporali Isolati", "Temporali Sparsi", "Temporali Sparsi", "Rovesci Sparsi", "Neve Forte", "Nevicate Sparse", "Neve Forte", "Nuvoloso", "Rovesci Temporaleschi", "Rovesci di Neve", "Temporali isolati", "Non Disponibile" ];
 
  }
  else if(language=="sp"){
  var weekday = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
  var month=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
  var smonth=["Ene","Feb","Mar","Abr","Mayo","Jun","Jul","Aug","Sep","Oct","Nov","Dic"];
  var sday=["Sol","Mon","Mar","Mie","Jue","Vie","Sat"];
  var menu = ["Hoy","Cada Hora","Diario","Ajustes"];
  var settingstxt = ["Reloj 24 horas","Celsio","Kph","Tiempo Paredes","Actualización Tiempo"];
  var updatedtxt = "Actualizado: ";
  var windchilltxt = "Viento Helado: ";
  var windtxt = "Viento: ";
  var feeltxt = "Sensación térmica";
  var sunrisetxt = "Salida del sol: ";
  var sunsettxt = "Puesta del sol: ";
  var textstringlater="Para hoy más tarde: ";
  var humidtxt="Humedad: ";
  var warningtxt = "Advertencia ";
  var elevationtxt = "Elevación: ";
  var preciptxt = "Probabilidad de lluvia: ";
  var dewpointtxt = "Punto de rocío: ";
  var notxt = "No ";
  var visibilitytxt = "Visibilidad: ";
  var Fcondition = [ "Tornado", "Tormenta Tropical", "Huracan", "Tormentas Electricas Severas", "Tormentas Electricas", "Mezcla de Lluvia y Nieve", "Mezcla de lluvia y aguanieve", "Mezcla de nieve y aguaniev", "Llovizna helada", "Llovizna", "Lluvia bajo cero", "Chubascos", "Chubascos", "Rafagas de nieve", "Ligeras precipitaciones de nieve", "Viento y nieve", "Nieve", "Granizo", "Aguanieve", "Polvareda", "Neblina", "Bruma", "Humeado", "Tempestuoso", "Vientoso", "Frio", "Nublado ", "Mayormente nublado", "Mayormente nublado", "despejado", "despejado", "Despejado", "Soleado", "Lindo", "Lindo", "Mezcla de lluvia y granizo", "Caluroso", "Tormentas electricas aisladas", "Tormentas electricas dispersas", "Tormentas electricas dispersas", "Chubascos dispersos", "Nieve fuerte", "Precipitaciones de nieve dispersas", "Nieve fuerte", "despejado", "Lluvia con truenos y relampagos", "Precipitaciones de nieve", "Tormentas aisladas", "No disponible" ];
 
  }
else if(language=="de"){
var weekday = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
var month=["Januar","Februar","März","April","Mai","Juni","Ju li","August","September","Oktober","November","Dez ember"];
var smonth=["Jan", "Feb", "Mä", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "];
var sday=["Son","Mon","Die","Mit","Don","Fre","Sam"];
var menu = ["Momentan","Stündlich","Tag","Einstellungen"];
var settingstxt = ["24-Stunden","Celsius","Kmh","Wetter Walls","Wetter -Update"];
var updatedtxt = "Aktualisiert: ";
var windchilltxt = "Windstill: ";
var windtxt = "Wind: ";
var feeltxt = "Gefühlt wie";
var sunrisetxt = "Sonnenaufgang: ";
var sunsettxt = "Sonnenuntergang: ";
var textstringlater="Im Laufe des Tages: ";
var humidtxt="Luftfeuchtigkeit: ";
var warningtxt = "Warnung ";
var elevationtxt = "Hoch: ";
var preciptxt = "Niederschlag: ";
var dewpointtxt = "Taupunkt: ";
var notxt = "Nein";
var visibilitytxt = "Sichtbarkeit: ";
var Fcondition = [ "Tornado", "Tropischer Sturm", "Wirbelsturm", "Schwere Gewitter", "Gewitter", "Regen und Schnee", "Graupelschauer", "Schneeregen", "Gefrierender Nieselregen", "Nieselregen", "Gefrierender Regen", "Schauer", "Schauer", "Schneegestöber", "Leichte Schneeschauer", "Schneetreiben", "Schnee", "Hagel", "Schneeregen", "Staubig", "Nebelig", "Dunstschleier", "Dunstig", "Stürmisch", "Windig", "Kalt", "Bewölkt", "Meist Bewölkt", "Meist Bewölkt", "Bewölkt", "Bewölkt", "Klar", "Sonnig", "Heiter", "Heiter", "Regen und Hagel", "Heiss", "Örtliche Gewitter", "Vereinzelte Gewitter", "Vereinzelte Gewitter", "Vereinzelte Schauer", "Starker Schneefall", "Vereinzelte Schneeschauer", "Starker Schneefall", "Bewölkt", "Gewitter", "Scheeschauer", "Örtliche Gewitterschauer", "Nicht Verfügbar" ]; 
  }
  else if(language=="fr"){
  var weekday = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  var month=["Janvie","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
  var smonth=["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"];
  var sday=["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
  var menu = ["Aujourd'hui","Horaire","Tous les jours","Paramètres"];
  var settingstxt = ["Horloge 24 heures","Celsius","Kph","Météo Murs","Mise à jour Météo"];
  var updatedtxt = "Mise à jour: ";
  var windchilltxt = "Wind Chill: ";
  var windtxt = "Vent: ";
  var feeltxt = "Ressenti";
  var sunrisetxt = "Lever du soleil: ";
  var sunsettxt = "Coucher du soleil: ";
  var textstringlater="Plus tard aujourd'hui: ";
  var humidtxt="Humidité: ";
  var warningtxt = "Avertissement ";
  var elevationtxt = "Elévation: ";
  var preciptxt = "Risque de pluie: ";
  var dewpointtxt = "Point de rosée: ";
  var notxt = "No ";
  var visibilitytxt = "Visibilité: ";
  var Fcondition = [ "Tornade", "Tropical", "Ouragan", "Orages Violents", "Orages", "Pluie", "Pluie", "Neige", "Bruine", "Bruine", "Pluie", "Averses", "Averses", "Quelques Flocons", "Faibles Chutes de Neige", "Rafales de Neige", "Neige", "GrÃªle", "Neige Fondue", "PoussiÃ©reux", "Brouillard", "Brume", "Brumeux", "TempÃªte", "Vent", "Temps Froid", "Temps Nuageux ", "TrÃ¨s Nuageux", "TrÃ¨s Nuageux", "Nuageux", "Nuageux", "Temps Clair", "Ensoleille", "Beau Temps", "Beau Temps", "Pluie et GrÃªles", "Temps Chaud", "Orages IsolÃ©s", "Orages Eparses", "Orages Eparses", "Averses Eparses", "Fortes Chutes de Neige", "Chutes de Neige Eparses", "Fortes Chutes de Neige", "Nuageux", "Orages", "Chute de Neige", "Orages IsolÃ©s", "Non Disponible" ];

  }
  else if(language=="zh"){
    var weekday = ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'];
    var month=['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var smonth=['一','二','三','四','五','六','七','八','九','十','十一','十二'];
    var sday=['周日','周一','周二','周三','周四','周五','周六'];
    var menu = ["今天","每小時","日報","設置"];
    var settingstxt = ["24小時時鐘","攝氏","公里","天氣牆","更新天氣"];
    var updatedtxt = "更新: ";
    var windchilltxt = "風寒: ";
    var windtxt = "风: ";
    var feeltxt = "感觉好像";
    var sunrisetxt = "日出: ";
    var sunsettxt = "日落: ";
    var textstringlater="今天晚些时候: ";
    var elevationtxt = "海拔: ";
    var humidtxt="湿度: ";
    var warningtxt = "警告 ";
    var preciptxt = "可能有雨: ";
    var dewpointtxt = "露點: ";
    var notxt = "沒有 ";
    var visibilitytxt = "能見度: ";
    var Fcondition = [ "龙卷风", "热带风暴", "飓风", "雷暴", "雷暴", "雪", "雨雪", "雨雪", "冻毛毛雨", "细雨", "冻雨", "淋浴", "淋浴", "飘雪", "雪", "雪", "雪", "Hail", "雨雪", "尘", "牙齿", "阴霾", "烟", "风起云涌", "有风", "冷", "多云", "多云", "多云", "多云", "多云", "明确", "晴朗", "公平", "公平", "雨雪", "Hot", "雷暴", "雷暴", "雷暴", "淋浴", "大雪", "小雪", "大雪", "半 多云", "雷暴", "雪", "雷暴", "空白" ];
  

  }
  else{
  var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var smonth=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var sday=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  var menu = ["Today","Hourly","Daily","Settings"];
  var settingstxt = ["24hr Clock","Celsius","Kph","Weather Walls","Update Weather"];
  var updatedtxt = "Updated: ";
  var windchilltxt = "Wind Chill: ";
  var windtxt = "Wind: ";
  var feeltxt = "Feels Like";
  var sunrisetxt = "Sunrise: ";
  var sunsettxt = "Sunset: ";
  var textstringlater="Later Today:";
  var humidtxt="Humidity: ";
  var warningtxt = "Warning ";
  var elevationtxt = "Elevation: ";
  var preciptxt = "Chance of rain: ";
  var dewpointtxt = "Dewpoint: ";
  var notxt = "No ";
  var visibilitytxt = "Visibility: ";
  var Fcondition = [ "Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank" ];

  }
