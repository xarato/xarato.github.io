function setQuote() {
    var quotes, random;
    quotes = {
        "Quote": [{
            "Author": "Motivation",
            "Quote": "Enjoy <br> your day!"
        }, {
            "Author": "Karma",
            "Quote": "I <br> saw that."
        }, {
            "Author": "Motivation",
            "Quote": "Take <br> the risk."
        }, {
            "Author": "Motivation",
            "Quote": "You <br> are powerful."
        }, {
            "Author": "Motivation",
            "Quote": "Hang <br> in there."
        }, {
            "Author": "Proverb",
            "Quote": "Haste <br> makes waste."
        }, {
            "Author": "Truth",
            "Quote": "Nothing <br> is impossible."
        }, {
            "Author": "Truth",
            "Quote": "Knowledge <br> is power."
        }, {
            "Author": "Motivation",
            "Quote": "Focus <br> and win."
        }, {
            "Author": "Motivation",
            "Quote": "Success <br> is yours."
        }, {
            "Author": "Motivation",
            "Quote": "Be <br> the change."
        }, {
            "Author": "Motivation",
            "Quote": "Do <br> your best."
        }, {
            "Author": "Motivation",
            "Quote": "You <br> are unique."
        }, {
            "Author": "Inspiration",
            "Quote": "Dreams <br> come true."
        }, {
            "Author": "Inspiration",
            "Quote": "Be <br> different."
        }, {
            "Author": "Inspiration",
            "Quote": "Dream <br> big."
        }, {
            "Author": "Truth",
            "Quote": "Onwards <br> and upwards."
        }, {
            "Author": "Motivation",
            "Quote": "Rise <br> and shine."
        }, {
            "Author": "Motivation",
            "Quote": "Live <br> your life."
        }, {
            "Author": "Motivation",
            "Quote": "Never <br> give up."
        }, {
            "Author": "Motivation",
            "Quote": "Remember <br> to live."
        }, {
            "Author": "Motivation",
            "Quote": "Seize <br> the day."
        }, {
            "Author": "Motivation",
            "Quote": "Attitude <br> is everything."
        }, {
            "Author": "Motivation",
            "Quote": "Be <br> here now."
        }, {
            "Author": "Motivation",
            "Quote": "Live <br> with passion."
        }, {
            "Author": "Motivation",
            "Quote": "Believe <br> in yourself."
        }, {
            "Author": "Motivation",
            "Quote": "Yes <br> you can."
        }, {
            "Author": "Motivation",
            "Quote": "Keep <br> it cool."
        }, {
            "Author": "Inspiration",
            "Quote": "All <br> is well."
        }, {
            "Author": "Inspiration",
            "Quote": "Genius <br> is patience."
        }, {
            "Author": "Inspiration",
            "Quote": "Thought <br> is free."
        }, {
            "Author": "Inspiration",
            "Quote": "Believe <br> you can."
        }, {
            "Author": "Motivation",
            "Quote": "Think <br> for yourself."
        }]
    };
    random = Math.floor((Math.random() * quotes.Quote.length) + 1);
    if (random === Number(localStorage.getItem('random'))) {
        setQuote();
    } else {
        getEL("quote").innerHTML = quotes.Quote[random - 1].Quote + '<h3>' + quotes.Quote[random - 1].Author + '</h3>';
        localStorage.setItem('quote', quotes.Quote[random - 1].Quote);
        localStorage.setItem('author', quotes.Quote[random - 1].Author);
        localStorage.setItem('time', currentTime);
        localStorage.setItem('random', random);
    }
}

if (Number(localStorage.getItem('time')) + quoteInterval < currentTime) {
    setQuote();
} else {
    getEL("quote").innerHTML = localStorage.getItem('quote') + '<h3>' + localStorage.getItem('author') + '</h3>';
}