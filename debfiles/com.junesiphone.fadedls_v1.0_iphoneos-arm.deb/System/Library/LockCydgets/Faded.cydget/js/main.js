function loadWeather() {
    var WC, count, i;
    WC = getWeather(); // get cached weather
    getEL('temp').innerHTML = (localStorage.getItem('celsius') === "true") ? CvtF(WC.temperature) + "&deg;" : WC.temperature + "&deg;";
    getEL('city').innerHTML = WC.name;
    getEL('wicon').src = "svg/" + WC.conditionCode + ".svg";
    getEL('details').innerHTML = Math.round(WC.precipitationForecast) + "%" + " " + windDirection() + " " + Math.round(WC.windSpeed) + "mph";
    getEL('condition').innerHTML = Fcondition[WC.conditionCode];
    for (i = 0; i < 4; i += 1) {
        count = i + 1;
        getEL("f" + count).src = "svg/" + (WC.dayForecasts[i].icon === 3200 ? WC.conditionCode : WC.dayForecasts[i].icon) + ".svg";

    }
    if (localStorage.getItem('celsius') === "true") {
        getEL('forecast').innerHTML = CvtF(WC.dayForecasts[1].high) + "&deg;/" + CvtF(WC.dayForecasts[1].low) + "&deg; " + CvtF(WC.dayForecasts[2].high) + "&deg;/" + CvtF(WC.dayForecasts[2].low) + "&deg; " + CvtF(WC.dayForecasts[3].high) + "&deg;/" + CvtF(WC.dayForecasts[3].low) + "&deg; " + CvtF(WC.dayForecasts[4].high) + "&deg;/" + CvtF(WC.dayForecasts[4].low) + "&deg;";
    } else {
        getEL('forecast').innerHTML = WC.dayForecasts[1].high + "&deg;/" + WC.dayForecasts[1].low + "&deg; " + WC.dayForecasts[2].high + "&deg;/" + WC.dayForecasts[2].low + "&deg; " + WC.dayForecasts[3].high + "&deg;/" + WC.dayForecasts[3].low + "&deg; " + WC.dayForecasts[4].high + "&deg;/" + WC.dayForecasts[4].low + "&deg;";
    }
}
function startClock(set) {
    if (set) {
        localStorage.setItem('twenty', set);
    }
    if (localStorage.getItem('twenty')) {
        updateClock(localStorage.getItem('twenty'));
    } else {
        updateClock("false");
    }
}
function setTemp(set){
    localStorage.setItem('celsius',set);
    localStorage.removeItem('lastUpdate');
    updateWeather();
    loadWeather();
}
function getLI(el) {
    addClass(getEL(el), "clicked");
    setTimeout(function() {
        removeClass(getEL(el), "clicked");
    }, 500);
    if (el === "chquote") {
        localStorage.removeItem('time');
        setQuote();
    }
    if (el === "celsius") {
        if(localStorage.getItem('celsius') === "true"){
            setTemp("false");
        } else {
            setTemp("true");
        }
    }
    if (el === "hour") {
        if (localStorage.getItem('twenty') === "true") {
            startClock("false");
        } else {
            startClock("true");
        }
    }
}
function menu() {
    if (hazClass(getEL('menuAni'), 'animate')) {
        getEL('time').style.display = "block";
        removeClass(getEL('menuAni'), "animate");
        removeClass(getEL('transform'), "transform");
    } else {
        getEL('time').style.display = "none";
        addClass(getEL('menuAni'), "animate");
        addClass(getEL('transform'), "transform");
    }
}
function swipedetect(el, callback) {
    var touchsurface = el,
        swipedir,
        startX,
        startY,
        distX,
        distY,
        threshold = 10, //required min distance traveled to be considered swipe
        restraint = 20, // maximum distance allowed at the same time in perpendicular direction
        allowedTime = 3000, // maximum time allowed to travel that distance
        elapsedTime,
        startTime,
        handleswipe = callback || function (swipedir) {}

    touchsurface.addEventListener('touchstart', function(e) {
        var touchobj = e.changedTouches[0]
        swipedir = 'none'
        dist = 0
        startX = touchobj.pageX
        startY = touchobj.pageY
        startTime = new Date().getTime() // record time when finger first makes contact with surface
        e.preventDefault()
    }, false)

    touchsurface.addEventListener('touchmove', function(e) {
        e.preventDefault() // prevent scrolling when inside DIV
    }, false)

    touchsurface.addEventListener('touchend', function(e) {
        var touchobj = e.changedTouches[0]
        distX = touchobj.pageX - startX // get horizontal dist traveled by finger while in contact with surface
        distY = touchobj.pageY - startY // get vertical dist traveled by finger while in contact with surface
        elapsedTime = new Date().getTime() - startTime // get time elapsed
        if (elapsedTime <= allowedTime) { // first condition for awipe met
            if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint) { // 2nd condition for horizontal swipe met
                swipedir = (distX < 0) ? 'left' : 'right' // if dist traveled is negative, it indicates left swipe
            } else if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint) { // 2nd condition for vertical swipe met
                swipedir = (distY < 0) ? 'up' : 'down' // if dist traveled is negative, it indicates up swipe
            }
        }
        handleswipe(swipedir)
        e.preventDefault()
    }, false)
}
(function() {
   var el = getEL('touchlayer');
   var hidetimer = null;
   swipedetect(el, function(swipedir) {
       if (swipedir == "up") {
           addClass(getEL('animated'), "animate");
           addClass(getEL('controls'), "animate");
           clearTimeout(hidetimer);
       }

       if (swipedir == "down") {
           removeClass(getEL('animated'), "animate");
           removeClass(getEL('controls'), "animate");
           clearTimeout(hidetimer);
       }
       if (swipedir == "right") {
           unlock();
       }
   });
   getEL('limenu').addEventListener('touchstart', function(e) {
       getLI(e.target.id);
   });
   getEL("name").innerHTML = "Welcome " + deviceName();
   if (currentTime > Number(localStorage.getItem('lastUpdate'))) {
       loadWeather();
       updateWeather();
       localStorage.setItem('lastUpdate', currentTime + weatherInterval);
       setTimeout(function() {
           loadWeather();
       }, 2500); //delay to make sure gps returns.
   } else {
       loadWeather();
   }
   if (window.innerWidth === 375) {
       document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.18, maximum-scale=1.18, user-scalable=0');
   } else if (window.innerWidth === 414) {
       document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.3, maximum-scale=1.3, user-scalable=0');
   }
}());