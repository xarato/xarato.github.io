// Enable Greetings
var EnableGreeting = false;

// Enable Weather SpringBoard
var enableWallpaper = true;