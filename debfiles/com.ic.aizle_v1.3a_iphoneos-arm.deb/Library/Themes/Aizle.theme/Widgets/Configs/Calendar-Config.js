// Enable Lockscreen Calendar
var CalendarEnabled = false;

// Enable Springboard Calendar
var EnableSpringBoardCalendar = true;

// Enable Calendar Grid
var EnabledGrid = false;