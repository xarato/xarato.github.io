function buildCal(i){
	var j = 1+i;
	var todaydate = new Date(); 
	var m = todaydate.getMonth()+j; 
	var y = todaydate.getFullYear();  
	var cM = "main";
	var cH = "month";
	var cDW = "daysofweek";
	var cD = "days";
  var brdr
	if (m > 12)
	{
		var moreyear = Math.floor((m-1) / 12);
		
		y = y + moreyear;
		m = m - (12 * moreyear);
	}
	
	if (m < 12)
	{
		var lessyear = Math.floor((m-1) / 12);
		
		y = y + lessyear;
		m = m - (12 * lessyear);
	}
	
var w = i-1;
var z = i+1;

var mn=['January','February','March','April','May','June','July','August','September','October','November','December'];
var dim=[31,0,31,30,31,30,31,31,30,31,30,31];

var oD = new Date(y, m-1, 1); //DD replaced line to fix date bug when current day is 31st
oD.od=oD.getDay()+1; //DD replaced line to fix date bug when current day is 31st

var todaydate=new Date() //DD added
var scanfortoday=(y==todaydate.getFullYear() && m==todaydate.getMonth()+1)? todaydate.getDate() : 0 //DD added

dim[1]=(((oD.getFullYear()%100!=0)&&(oD.getFullYear()%4==0))||(oD.getFullYear()%400==0))?29:28;

if (EnabledGrid == true) {
var t='<div class="'+cM+'"><table class="'+cM+'" cols="7" cellpadding="0" border="'+brdr+'" cellspacing="0"><tr align="center">';
}
else
{
var t='<div class="'+cM+'"><table class="'+cM+'" cols="7" cellpadding="0" cellspacing="0"><tr align="center">';
}

t+='<td colspan="8" align="center" class="'+cH+'">'+mn[m-1]+' '+y+'</td></tr><tr align="center">';

for(s=0;s<7;s++)t+='<td class="'+cDW+'">'+"SMTWTFS".substr(s,1)+'</td>';

t+='</tr><tr align="center">';

for(i=1;i<=42;i++) {

var x=((i-oD.od>=0)&&(i-oD.od<dim[m-1]))? i-oD.od+1 : '&nbsp;';

if (x==scanfortoday) //DD added
x='<span id="today">'+x+'</span>' //DD added
t+='<td class="'+cD+'">'+x+'</td>';

if(((i)%7==0)&&(i<36))t+='</tr><tr align="center">';
}
if (CalendarEnabled == true){
t+='<td id="Close" onClick="javascript:hide()">';
	document.getElementById("cal").innerHTML = t;
	document.getElementById("ButtonCalendar").value = "Remove Calendar";
	document.getElementById("ButtonCalendar").onclick = function () { hide(); };
}
}
if (CalendarEnabled == true){
function hide()
{
	document.getElementById("cal").innerHTML = "";
	document.getElementById("ButtonCalendar").onclick = function () { buildCal(0); };
	document.getElementById("ButtonCalendar").value = "Display Calendar";
}
}