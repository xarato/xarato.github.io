/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  window,
  show,
  weather,
  weathercode,
  clock,
  twentyfour,
  translate,
  current
*/

var os = {};


os.createDOM = function (params) {
    var d = document.createElement(params.type);
    if (params.class) {
        d.setAttribute('class', params.class);
    }
    if (params.src) {
        d.src = params.src;
    }
    if (params.id) {
        d.id = params.id;
    }
    if (params.innerHTML) {
        d.innerHTML = params.innerHTML;
    }
    if (params.attribute) {
        d.setAttribute(params.attribute[0], params.attribute[1]);
    }
    if (params.attribute2) {
        d.setAttribute(params.attribute2[0], params.attribute2[1]);
    }
    if (params.attribute3) {
        d.setAttribute(params.attribute3[0], params.attribute3[1]);
    }
    if (params.type === "img") {
        d.src = params.src;
    }
    if (params.appendChild) {
        d.appendChild(params.appendChild);
    }
    return d;
};

// var weathercode = 38671;
// var celsius = false;
// var twentyfour = false;


(function () {
    var doc = document;

    var convert = function (amount) {
        return Math.round((amount - 32) * 5 / 9);
    };

    weather({
        code: weathercode,
        temp: false,
        lang: 'en',
        gps: false, //must use WidgetWeather xml if set to true
        refresh: 15, // in minutes
        success: function (w) {

                //
                // <div id="city">Southaven</div>
                // <div id="condition">Cloudy</div>
                // <div id="feelslike">Feels like: 63&deg;</div>
                // <div id="temp">65&deg;</div>
                w.temp = (celsius) ? convert(w.temp) : w.temp;
                w.feelslike = (celsius) ? convert(w.feelslike) : w.feelslike;

                document.getElementById('city').innerHTML = w.city;
                document.getElementById('condition').innerHTML = w.condition;
                document.getElementById('feelslike').innerHTML = "Feels Like: " + w.feelslike + "&deg;";
                document.getElementById('temp').innerHTML = w.temp + "&deg;";
                var string = "Currently " + w.temp + "&deg;" + " with a " + w.pop + "% chance of " + w.precip_type + "." + " Humidity is " + w.humid + "% with a wind speed of " + w.windspd + " from the " + w.winddir + ", dewpoint resting at " + w.dew + '&deg;';

                document.getElementById('string').innerHTML = string;




                //dew, feelsLike, humid, icon, key, pop, precip_type, temp, uv, wDesc, wDir, wDesc, wDirText, wSpeed

                var d, ampms, hrs, mns, time, i,
                    hourlyForecast = document.getElementById('hourlyforecast');
                hourlyForecast.innerHTML = '';

                for (i = 0; i < w.hourly.length - 1; i++) {
                    d = new Date(w.hourly[i].dateTime * 1000);
                    ampms = (!twentyfour) ? (d.getHours() > 11) ? "pm" : "am" : '';
                    hrs = (twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
                    mns = (d.getMinutes() === 0) ? "0" + d.getMinutes() : d.getMinutes();
                    time = hrs + ampms;

                    // <div class="hourlyforecast" id="hourlyforecast">
                    //   <div class="hour">
                    //     <div class="hourlytime">10PM</div>
                    //     <img class="hourlyicon" src="src/icon/32_small.png" />
                    //     <div class="hourlytemp"> 78&deg; </div>
                    //     <div class="hourlypercent"> 0% Rain</div>
                    //   </div>

                    var hrtemp = (celsius) ? convert(w.hourly[i].temp) : w.hourly[i].temp;




                    var hourcontainer = os.createDOM({
                            type: 'div',
                            class: 'hour'
                        }),
                        hourlyicon = os.createDOM({
                            type: 'img',
                            class: 'hourlyicon',
                            src: 'src/icon/' + w.hourly[i].icon + '_small.png'
                        }),
                        hourlytime = os.createDOM({
                            type: 'div',
                            class: 'hourlytime',
                            innerHTML: time
                        }),
                        hourlytemp = os.createDOM({
                            type: 'div',
                            class: 'hourlytemp',
                            innerHTML: hrtemp + '&deg;'
                        }),
                        hourlypercent = os.createDOM({
                            type: 'div',
                            class: 'hourlypercent',
                            innerHTML: '<span class="rainpercent">' + w.hourly[i].pop + '%' + ' </span>' + w.hourly[i].precip_type
                        });


                    hourcontainer.appendChild(hourlytime);
                    hourcontainer.appendChild(hourlyicon);
                    hourcontainer.appendChild(hourlytemp);
                    hourcontainer.appendChild(hourlypercent);
                    hourlyForecast.appendChild(hourcontainer);
                }




                var dayForecast = document.getElementById('dayforecast');


                dayForecast.innerHTML = '';

                //  console.log(w.daily);

                for (i = 0; i < w.daily.length - 1; i++) {


                    var dayText = new Date(w.daily[i].validDate * 1000),
                        dtday = dayText.getDay(),
                        iconnum,
                        high,
                        low,
                        pop,
                        dayText = translate[current].weekday[dtday],
                        sdayText = translate[current].sday[dtday];


                    try {
                        iconnum = w.daily[i].day.icon;
                        pop = w.daily[i].day.pop;
                    } catch (err) {
                        iconnum = w.daily[i].night.icon;
                        pop = w.daily[i].night.pop;
                    }

                    high = (celsius) ? convert(w.daily[i].maxTemp) : w.daily[i].maxTemp;
                    low = (celsius) ? convert(w.daily[i].minTemp) : w.daily[i].minTemp;



                    if (w.daily[i].precip_type === "") {
                        try {
                            percent = pop + '% ' + w.daily[i].night.precip_type;
                        } catch (err) {
                            percent = pop + '% ' + w.daily[i].day.precip_type;
                        }
                    } else {
                        percent = pop + '% ' + w.daily[i].precip_type;
                    }

                    if (isNaN(high)) {
                        high = w.temp;
                    }

                    graphMaker.storage.dataArray.push(high / 10);
                    graphMaker.storage.data2Array.push(low / 10);
                    graphMaker.storage.highArray.push(high);
                    graphMaker.storage.lowArray.push(low);
                    console.log(high + "low: " + low);

                    graphMaker.storage.daysArray.push(sdayText);
                    //icon = (forecast[i].condition === 3200) ? currentCondition : forecast[i].condition;
                    //graphMaker.storage.iconArray.push(icon);

                    // <div class="dailyforecast">
                    // 	<div class="day">
                    // 		<div class="daytext">Wednesday</div>
                    // 		<img class="dayicon" src="src/icon/32_small.png" />
                    // 		<div class="dayhigh"> 78&deg; </div>
                    // 		<div class="daylow"> 72&deg; </div>
                    // 		<div class="daypercent"> 0% Rain</div>
                    // 	</div>


                    var day = os.createDOM({
                            type: 'div',
                            class: 'day'
                        }),
                        daytext = os.createDOM({
                            type: 'div',
                            class: 'daytext',
                            innerHTML: dayText
                        }),
                        dayicon = os.createDOM({
                            type: 'img',
                            class: 'dayicon',
                            src: 'src/icon/' + iconnum + '_small.png'
                        }),
                        dayhigh = os.createDOM({
                            type: 'div',
                            class: 'dayhigh',
                            innerHTML: high + '&deg;'
                        }),
                        daylow = os.createDOM({
                            type: 'div',
                            class: 'daylow',
                            innerHTML: low + '&deg;'
                        }),
                        daypercent = os.createDOM({
                            type: 'div',
                            class: 'daypercent',
                            innerHTML: percent
                        });


                    day.appendChild(daytext);
                    day.appendChild(dayicon);
                    day.appendChild(dayhigh);
                    day.appendChild(daylow);
                    day.appendChild(daypercent);


                    dayForecast.appendChild(day);
                }






                graphMaker.loadGraph();
                if (celsius) {
                    document.getElementById('graphbox').style.top = "-50px";

                }

            } //end success
    });

    clock({
        twentyfour: twentyfour,
        padzero: true,
        refresh: 1000,
        success: function (clock) {
            document.getElementById('time').innerHTML = clock.hour() + ":" + clock.minute() + clock.am();
        }
    });

}());
