/*jslint
  node: true,
  sloppy: true,
  browser: true
*/

/*global
  d3,
  showLows,
  IS2W,
  translate,
  current
*/

'use strict';
var graphMaker = {
    storage: {
        forecastInfo: null,
        condition: null,
        icon: null,
        dataArray: [],
        data2Array: [],
        highArray: [],
        lowArray: [],
        iconArray: [],
        daysArray: []
    },
    clearGraph: function () {
        document.getElementById('graph').innerHTML = '';
        document.getElementById('graph2').innerHTML = '';
        document.getElementById('dots').innerHTML = '';
        document.getElementById('days').innerHTML = '';
    },
    emptyArrays: function () {
        graphMaker.storage.dataArray = [];
        graphMaker.storage.data2Array = [];
        graphMaker.storage.highArray = [];
        graphMaker.storage.lowArray = [];
        graphMaker.storage.iconArray = [];
        graphMaker.storage.daysArray = [];
    },
    createDots: function (x, y, low) {
        var dot = document.createElement('div');
        dot.style.left = x - 4 + 'px';
        dot.style.top = y - 4 + 'px';
        if (low) {
            dot.className = 'dotlow';
        } else {
            dot.className = 'dot';
        }
        document.getElementById('dots').appendChild(dot);
    },
    createDays: function (x, y, count, low) {
        var day = document.createElement('div'),
            temp = document.createElement('div'),
            img = document.createElement('img');
        day.style.left = x - 15 + 'px';
        day.style.top = y - 20 + 'px';

        temp.style.left = x - 13 + 'px';
        if (low) {
            temp.style.top = (y + 40) + 'px';
        } else {
            temp.style.top = (y + 5) + 'px';
        }
        temp.className = 'temps';
        if (low) {
            temp.innerHTML = graphMaker.storage.lowArray[count - 9] + '&deg;';
        } else {
            temp.innerHTML = graphMaker.storage.highArray[count] + '&deg;';
        }

        //
        // img.style.left = x - 15 + 'px';
        // img.style.top = y - 40 + 'px';
        // img.className = 'img';
        // img.src = 'src/images/icons/weather/' + graphMaker.storage.iconArray[count] + '.png';

        day.innerHTML = graphMaker.storage.daysArray[count];
        day.className = 'days';
        if (!low) {
            //  document.getElementById('days').appendChild(img);
            document.getElementById('days').appendChild(day);
        }
        document.getElementById('days').appendChild(temp);

    },
    loadGraph: function () {
        this.clearGraph();
        var dotArrayX = [],
            dotArrayY = [],
            w = screen.width + 20,
            h = 120,

            data = graphMaker.storage.dataArray,
            data2 = graphMaker.storage.data2Array,
            x = d3.scale.linear().domain([0, data.length + 1]).range([0, w]),
            y = d3.scale.linear().domain([0, 10]).range([h, 0]),
            line = d3.svg.line().x(function (d, i) {
                dotArrayX.push(x(i));
                return x(i);
            }).y(function (d) {
                dotArrayY.push(y(d));
                return y(d);
            }),
            graph = d3.select("#graph").append("svg:svg").attr("width", w).attr("height", h + 100).append("svg:g"),
            graph2 = d3.select("#graph2").append("svg:svg").attr("width", w).attr("height", h + 100).append("svg:g"),
            i;

        graph.append("svg:path").attr("d", line(data));


        //  if (showLows) {
        graph2.append("svg:path").attr("d", line(data2));
        //  }

        for (i = 0; i < dotArrayX.length; i += 1) {
            console.log(dotArrayX.length);
            if (i >= data.length) {
                graphMaker.createDots(dotArrayX[i], dotArrayY[i], true);
                graphMaker.createDays(dotArrayX[i], dotArrayY[i], i, true);
            } else {
                graphMaker.createDots(dotArrayX[i], dotArrayY[i], false);
                graphMaker.createDays(dotArrayX[i], dotArrayY[i], i, false);
            }
        }
        this.emptyArrays();
    }
};


/* implementation heavily inspired by http://bl.ocks.org/1166403 */
