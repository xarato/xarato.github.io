/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  os
*/

(function (window, doc) {
    function load_calendar() {
        var calendar = {},
            date = new Date(),
            dayOfWeekAsString = function (dayIndex) {
                return translate[current].sday[dayIndex];
            },
            monthsAsString = function (monthIndex) {
                return translate[current].month[monthIndex];
            },
            createCalendarDay = function (num, day, mon, year) {
                var currentCalendar = doc.getElementById("calendar"),
                    newDay = doc.createElement("div"),
                    date = doc.createElement("p"),
                    dayElement = doc.createElement("p");
                date.innerHTML = num;
                dayElement.innerHTML = day;
                newDay.className = "calendar-day ";
                date.className = 'calendar-date';
                dayElement.className = 'calendar-dayname';
                // Set ID of element as date formatted "8-January" etc
                newDay.id = num + "-" + mon + "-" + year;
                newDay.appendChild(date);
                newDay.appendChild(dayElement);
                currentCalendar.appendChild(newDay);
            },
            clearCalendar = function () {
                var currentCalendar = doc.getElementById("calendar");
                currentCalendar.innerHTML = "";
            },
            getCurrentDay = function () {
                // Create a new date that will set as default time
                var todaysDate = new Date(),
                    today = todaysDate.getDate(),
                    currentMonth = todaysDate.getMonth(),
                    currentYear = todaysDate.getFullYear(),
                    thisMonth = monthsAsString(currentMonth),
                    currentDay;
                // Find element with the ID for today
                currentDay = doc.getElementById(today + "-" + thisMonth + "-" + currentYear);
                currentDay.className = "calendar-day today";
                os.registerEvents(currentDay, {
                    event: os.handlerType(),
                    callback: function () {
                        os.toggleClassList(doc, 'datewidget', 'menuToggle');
                        localStorage.datewidgetShow = null;
                    }
                });
            },
            createMonth = function () {
                clearCalendar();
                var dateObject = new Date(),
                    currentMonthText;
                dateObject.setDate(date.getDate());
                dateObject.setMonth(date.getMonth());
                dateObject.setYear(date.getFullYear());
                createCalendarDay(dateObject.getDate(), dayOfWeekAsString(dateObject.getDay()), monthsAsString(dateObject.getMonth()), dateObject.getFullYear());
                dateObject.setDate(dateObject.getDate() + 1);
                while (dateObject.getDate() !== 1) {
                    createCalendarDay(dateObject.getDate(), dayOfWeekAsString(dateObject.getDay()), monthsAsString(dateObject.getMonth()), dateObject.getFullYear());
                    dateObject.setDate(dateObject.getDate() + 1);
                }
                // Set the text to the correct month
                currentMonthText = doc.getElementById("current-month");
                currentMonthText.innerHTML = monthsAsString(date.getMonth()) + " " + date.getFullYear();
                getCurrentDay();
            },

            nextMonth = function () {
                clearCalendar();
                date.setMonth(date.getMonth() + 1);
                createMonth(date.getMonth());
            },
            previousMonth = function () {
                clearCalendar();
                date.setMonth(date.getMonth() - 1);
                createMonth(date.getMonth());
            };
        date.setDate(1);
        calendar.createMonth = function () {
            createMonth();
        };
        calendar.nextMonth = function () {
            nextMonth();
        };
        calendar.previousMonth = function () {
            previousMonth();
        };

        return calendar;
    }
    window.calendar = load_calendar();

    var datewidget = {},
        container = doc.getElementById('datewidget'),
        opacity = function (number) {
            container.style.opacity = number;
            localStorage.datewidgetOpacity = number;
            return "Date widget opacity set to " + number;
        },
        alwaysShow = function () {
            localStorage.datewidgetShow = "yes";
            doc.getElementById('datewidget').classList.toggle('menuToggle');
            return "Date widget will always show, close from calendar.";
        };

    if (localStorage.datewidgetShow === "yes") {
        doc.getElementById('datewidget').classList.toggle('menuToggle');
    }

    if (localStorage.datewidgetOpacity !== null) {
        if (localStorage.datewidgetOpacity !== "null") {
            opacity(localStorage.datewidgetOpacity);
        }
    }

    datewidget.opacity = function (number) {
        return opacity(number);
    };
    datewidget.alwaysshow = function () {
        return alwaysShow();
    }

    window.datewidget = datewidget;
}(window, document));
