/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  os,
  IS2T,
  IS2S,
  IS2N,
  iconDrawer,
  appDrawer,
  appInfo,
  autohidedock,
  bundleApps
*/

(function (window, doc) {
    var load_notification = function () {
        var notification = {},
            infoscrolling = false,
            appscrolling = false,
            appiconcontainer = doc.getElementById('appiconcontainer'),
            appinfocontainer = doc.getElementById('appinfocontainer'),
            sharedArray = [],
            infoArray = [],
            loadinfo = function () {
                var fragment2 = doc.createDocumentFragment(),
                    e,
                    appBundle,
                    bundle,
                    i,
                    li2,
                    ab,
                    appName,
                    messageFix,
                    newCount = 0,
                    nName;

                //children = appiconcontainer.children;
                appinfocontainer.scrollTop = 0;
                infoArray = [];
                //get info for it
              //  for (e = 0; e < sharedArray.length; e += 1) {
                  //  appBundle = IS2N('notificationsJSONForApplication:@"' + sharedArray[e] + '"');
                    //os.message('appBundle', appBundle);
                  //  if (appBundle.length > 3) {
                      //  appBundle = JSON.parse(appBundle);
                        //os.message(appBundle);

                        for (i = 0; i < FPI.notifications.all.length; i += 1) {
                            if (FPI.notifications.all[i].bundle && FPI.notifications.all[i].bundle != "com.apple.cmas"&& FPI.notifications.all[i].bundle != "crash-reporter" && FPI.notifications.all[i].bundle != "com.apple.mobilecal.today") {
                                ab = FPI.notifications.all[i];
                                bundle = ab.bundle;
                              //  alert(bundle);
                                //alert(FPI.bundle);

                            if(FPI.bundle[bundle]){ //check if a real bundle

                                if(FPI.bundle[bundle].badge >= 1){ // check if app has notifciation


                              //  alert(bundle);

                                messageFix = ab.text.replace(/\n/g, "<br />").replace(/(\.(\s+))/g, '<br /><br />');
                                //os.message(appBundle[i].message, appBundle[i].message.replace(/\n/g, '<br />'));



                                  nName = FPI.bundle[bundle].name;

                                infoArray.push({
                                    title: nName,
                                    message: messageFix,
                                    name: nName,
                                    bundle: bundle
                                });


                                //os.message('notification.js', ab.message);
                                //os.message('notification.js', ab.message.replace(/\n/g, "<br />").replace(/(\.(\s+))/g, '\$1 <br /><br />'));

                                li2 = document.createElement('li');
                                li2.innerHTML = ab.text.replace(/\n/g, "<br />");
                                li2.setAttribute('data-number', newCount);
                                newCount += 1;
                                appName = nName;
                                li2.setAttribute('data-title', appName + ' - ');
                                li2.setAttribute('full-title', appName + ' - ');
                                li2.setAttribute('bundle', bundle);
                                fragment2.appendChild(li2);

                              }
                            }
                          }
                    //    }
                  //  }
                }
                if (String(appBundle) === '[]') {
                    li2 = document.createElement('li');
                    li2.innerHTML = "No Messages";
                    li2.setAttribute('data-title', 'Notification');
                    li2.setAttribute('bundle', 'null');
                    fragment2.appendChild(li2);
                }

                appinfocontainer.appendChild(fragment2);
                fragment2 = null;
                loadEvents();
            },
            loadapps = function () {
                os.clearDiv(appiconcontainer);
                os.clearDiv(appinfocontainer);
                var array = FPI.apps.all,
                    i,
                    bundle,
                    name,
                    count,
                    li,
                    icon,
                    fragment = doc.createDocumentFragment();
                sharedArray = [];
                //loop over appInfo until you get all apps with notificationShow
                //loop over that list and get text notification
                for (i = 0; i < array.length; i += 1) {

                    name = FPI.apps.all[i].name;
                    bundle = FPI.apps.all[i].bundle;
                    count = FPI.bundle[bundle].badge;

                    if (count > 0) {
                        li = doc.createElement('li');
                        li.setAttribute('title', count);
                        li.setAttribute('data-title', name);
                        li.setAttribute('bundle', bundle);
                        sharedArray.push(bundle);

                        //check for cached image
                      //  if (appDrawer.cache.hasOwnProperty(bundle)) {
                          //  icon = appDrawer.cache[bundle];
                        //} else {
                            icon = '/var/mobile/Library/FrontPageCache/' + bundle + '.png';
                            //appDrawer.cache[bundle] = icon;
                      //  }

                        li.style.backgroundImage = "url(" + icon + ")";
                        fragment.appendChild(li);
                    }
                }
                appiconcontainer.appendChild(fragment);
            },
            removeNotificationInfo = function () {
                os.unregisterEvents(appiconcontainer);
                os.unregisterEvents(appinfocontainer);
                os.clearDiv(appiconcontainer);
                os.clearDiv(appinfocontainer);
            },
            togglePreview = function (target) {
                var number = target.getAttribute('data-number');

                try {
                    document.getElementById('infoName').innerHTML = infoArray[number].name;
                    document.getElementById('infoMessage').innerHTML = infoArray[number].message;
                    document.getElementById('infoOpenApp').setAttribute('title', infoArray[number].bundle);
                    document.getElementById('infoOpenApp').style.backgroundImage = 'url(" ' + '/var/mobile/Library/FrontPageCache/' + infoArray[number].bundle + '.png' + '   ")';

                    doc.getElementById('infoPopup').className = "openPopup";
                    doc.getElementById('notificationMenu').style.opacity = 0.4;

                    //  target.className = "zoom";
                    // if (target.className === 'zoom') {
                    //     target.className = '';
                    // } else {
                    //     target.className = 'zoom';
                    // }
                    //target.classList.toggle('zoom');

                    //target.style.backgroundColor = 'red';
                } catch (err) {
                    //alert(err); // when there is no messages this will trigger.
                }
            },
            closeInfo = function () {
                doc.getElementById('infoPopup').className = "closePopup";
                doc.getElementById('notificationMenu').style.opacity = 1;
            },
            loadEvents = function () {
                os.registerEvents(appiconcontainer, {
                    event: 'touchend',
                    callback: function (el) {
                        if (el.target.getAttribute('bundle')) {
                            if (!appscrolling && !infoscrolling) {

                                openApp(el.target.getAttribute('bundle'));
                                os.closeAllMenusBesides('nothin');
                                doc.getElementById('dock').className = 'dockshow';
                                autohidedock = false;

                            }
                            appscrolling = false;
                        }
                    }
                });

                os.registerEvents(appiconcontainer, {
                    event: 'touchmove',
                    callback: function () {
                        appscrolling = true;

                    }
                });

                os.registerEvents(appinfocontainer, {
                    event: 'touchmove',
                    callback: function () {
                        infoscrolling = true;
                    }
                });

                os.registerEvents(doc.getElementById('infoClose'), {
                    event: os.handlerType(),
                    callback: function () {
                        closeInfo();
                    }
                });

                os.registerEvents(doc.getElementById('infoOpenApp'), {
                    event: os.handlerType(),
                    callback: function (el) {
                        openApp(el.target.getAttribute('title'));
                        closeInfo();
                        os.closeAllMenusBesides('nothin');
                        doc.getElementById('dock').className = 'dockshow';
                        autohidedock = false;

                    }
                });

                os.registerEvents(appinfocontainer, {
                    event: 'touchend',
                    callback: function (el) {
                        if (el.target.getAttribute('bundle')) {
                            if (!appscrolling && !infoscrolling) {
                                togglePreview(el.target);
                                //iconDrawer.openApp(el.target.getAttribute('bundle'));
                                //os.closeAllMenusBesides('nothin');
                                //doc.getElementById('dock').className = 'dockshow';
                                //autohidedock = false;
                            }
                        }
                        setTimeout(function () {
                            infoscrolling = false;
                        }, 100);

                    }
                });
            };


        loadEvents();

        notification.show = function () {
          //window.location = 'frontpage:vibrate';
            //  var startTime = new Date().getTime(),
            //    endTime;
try{
  loadapps();
  loadinfo();
}catch(err){
  //alert(err);
}



            //  endTime = new Date().getTime();
            //  os.message('Notification.js loadapps()', "Time to execute: " + (endTime - startTime) + "ms", 'speed');

            //startTime = new Date().getTime();


            // endTime = new Date().getTime();
            // os.message('Notification.js loadinfo()', "Time to execute: " + (endTime - startTime) + "ms", 'speed');

        };
        notification.hide = function () {

            removeNotificationInfo();
        };
        notification.closeInfoPopup = function () {
            closeInfo();
        };
        return notification;
    };

    window.notification = load_notification();

}(window, document));
