// /*jslint
//   node: true,
//   sloppy: true,
//   browser: true
// */
//
// /*global
//   os,
//   appSlider,
//   iconContainer
// */
//
// (function (doc) {
//     var iWidget = doc.getElementById('iWidget'),
//         //iconContainer = doc.getElementById('iconContainer'),
//         newWidth,
//         newHeight,
//         sliderWidth,
//         //sizes the main widget and appSlider which is appDrawer
//         resetSlider = function (style) {
//             if (style === 'height') {
//                 sliderWidth = screen.height;
//                 newWidth = screen.height + 'px';
//                 newHeight = screen.width + 'px';
//             } else {
//                 sliderWidth = screen.width;
//                 newHeight = screen.height + 'px';
//                 newWidth = screen.width + 'px';
//             }
//             iWidget.style.width = newWidth;
//             iWidget.style.height = newHeight;
//             if (appSlider !== null) {
//                 appSlider.width = sliderWidth;
//                 if (appSlider.list) {
//                     appSlider.reset(appSlider);
//                 }
//             }
//         },
//         // when the width is changed it needs to be reset. appSlider.reset()
//         // if disabled landscape will still have portrait layout
//         // icon container also needs to manipulated when in either orientation
//         rotate = function (dir, widget) {
//           //  widget.className = dir; //flips entire widget container
//             if (dir === 'landscape') {
//                 doc.getElementById('closer').style.height = '100px';
//                 if (!os.ipad) {
//                     doc.getElementById('weatherHolder').style.display = 'none';
//                 }
//
//               //  macDock.getSwitcher(); //get new icons from switcher
//                 resetSlider('height'); //manually adjust width and reset app slider.
//                 macTerminal.close();
//             }
//             if (dir === 'portrait') {
//                 resetSlider('height');
//                 if (!os.ipad) {
//                     doc.getElementById('weatherHolder').style.display = 'block';
//                 }
//             }
//         },
//
//         handleOrientation = function (event) {
//
//             var x = event.beta,
//                 y = event.gamma;
//             if (x > -30 && x < 30) {
//                 if (y < -40) {
//                     if (iWidget.className !== "landscape") {
//                       //  localStorage.landscape = window.landscape;
//                         //if (window.landscape === true || window.landscape === "true") {
//                             rotate('landscape', iWidget);
//                         //}
//                     }
//                 }
//             } else {
//                 if (iWidget.className !== "portrait") {
//                   alert('test');
//                     //localStorage.landscape = window.landscape;
//                     //if (window.landscape === true || window.landscape === "true") {
//                         rotate('portrait', iWidget);
//                   //  }
//                 }
//             }
//         };
//     window.addEventListener("deviceorientation", handleOrientation, true);
// }(document));
