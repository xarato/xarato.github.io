#!/bin/sh
killall MobileMail
sqlite3 "/private/var/mobile/Library/Mail/Envelope Index" "DELETE FROM messages WHERE remote_id ISNULL;"
killall MobileMail
sleep 3
