var blacklist = [];

if(localStorage.blacklist){
	blacklist = JSON.parse(localStorage.blacklist);
}

