var tf = (localStorage.tf) ? JSON.parse(localStorage.tf) : false;
$$('.time').set(clock.hour(tf,true)+":"+clock.minute());
$$('.date').set("the " + clock.datetext() + " of " + clock.monthtext());
$$('.svg').sel().src = "svg/" + clock.day() + ".svg";
$$('.svgshadow').sel().src = "svg/" + clock.day() + ".svg";
showSVG('.svg,.svgshadow', true);
$$('.day').sel().addEventListener('click',function(){
    sset.create('24hr','tf','black');
});