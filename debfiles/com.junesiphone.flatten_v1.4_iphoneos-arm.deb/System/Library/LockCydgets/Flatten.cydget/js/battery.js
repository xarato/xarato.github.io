// simple script that takes the battery percent, timout, count, element and width of element
function setBattery(battery,timeout,count,element,elwidth){
	var calc, width, interval;
	width = 0; // starting width
	calc = Math.round((battery / 100) * elwidth); //calculate percent of the width
	function animate(){
		width += count; //add count to width every interval
		document.querySelector('.'+element).style.width = width + 'px'; //set width to dom element
		if(width >= calc){clearInterval(interval);} // clear interval
	}
	interval = setInterval(animate, timeout);
}