/*
________                            ____. _________
\______ \____________     ____     |    |/   _____/
 |    |  \_  __ \__  \   / ___\    |    |\_____  \
 |    `   \  | \// __ \_/ /_/  >\__|    |/        \
/_______  /__|  (____  /\___  /\________/_______  /
        \/           \//_____/                  \/
Simple drag library created by JunesiPhone

Declare on touchstart
drag.startMoving(slider, container, event, length, callback);

Declare on touchend
drag.stopMoving(slider, container, event, length, callback);
*/
var getStyle = function(oElm, strCssRule){
    var strValue = "";
    if(document.defaultView && document.defaultView.getComputedStyle){
        strValue = document.defaultView.getComputedStyle(oElm, "").getPropertyValue(strCssRule);
    }
    else if(oElm.currentStyle){
        strCssRule = strCssRule.replace(/\-(\w)/g, function (strMatch, p1){
            return p1.toUpperCase();
        });
        strValue = oElm.currentStyle[strCssRule];
    }
    return strValue;
};

var drag = function () {
    return {
        move: function (div, xpos, ypos) {
            div.style.left = xpos + "px";
        },
        startMoving: function (div, container, evt, stop, func) {
            evt = evt || window.event;
            var posX = evt.touches[0].clientX,
                posY = evt.touches[0].clientY,
                divTop = div.style.top.replace('px', ''),
                divLeft = div.style.left.replace('px', ''),
                offsetX = posX - divLeft,
                offsetY = posY - divTop;
            document.ontouchmove = function (evt) {
                evt.preventDefault();
                evt = evt || window.event;
                var posX = evt.touches[0].clientX,
                    posY = evt.touches[0].clientY,
                    cWidth = getStyle(document.getElementById(container), 'width').replace('px', ''),
                    dWidth = getStyle(div, 'width').replace('px', ''),
                    finalX = posX - offsetX,
                    finalY = posY - offsetY;
                if (finalX < 0) {
                    finalX = 0;
                }
                if (finalY < 0) {
                    finalY = 0;
                }
                if (finalX <= cWidth - dWidth - 8) {
                    drag.move(div, finalX, finalY);
                }
                if (posX >= stop) {
                    func();
                }
            };
        },
        stopMoving: function (div, container, evt, stop, func) {
            if (evt.changedTouches[0].clientX >= stop) {
                func();
            } else {
                div.style.left = "4px";
            }
        },
    };
}();