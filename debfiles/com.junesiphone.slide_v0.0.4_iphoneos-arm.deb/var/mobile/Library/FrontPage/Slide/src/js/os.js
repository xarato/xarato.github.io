var os = {};
os.clearDiv = function (divID) {
    while (divID.firstChild) {
        divID.removeChild(divID.firstChild);
    }
};
os.touch = function () {
    var nav = navigator.userAgent.match(/iPhone|iPad|iPod/i);
    if (nav) {
        return 'touchstart';
    }
    return 'click';
};
os.createDOM = function (params) {
    var d = document.createElement(params.type);
    if (params.className) {
        d.setAttribute('class', params.className);
    }
    if (params.id) {
        d.id = params.id;
    }
    if (params.innerHTML) {
        d.innerHTML = params.innerHTML;
    }
    if (params.attribute) {
        d.setAttribute(params.attribute[0], params.attribute[1]);
    }
    if (params.attribute2) {
        d.setAttribute(params.attribute2[0], params.attribute2[1]);
    }
    if (params.attribute3) {
        d.setAttribute(params.attribute3[0], params.attribute3[1]);
    }
    if (params.type === "img") {
        d.src = params.src;
    }
    if (params.appendChild) {
        d.appendChild(params.appendChild);
    }
    return d;
};
