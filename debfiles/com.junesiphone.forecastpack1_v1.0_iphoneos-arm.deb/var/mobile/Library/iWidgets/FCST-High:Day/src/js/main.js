/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  window,
  show,
  weather,
  weathercode,
  clock,
  twentyfour,
  translate,
  current,
  celsius
*/

var os = {};

// var weathercode = "38671";
// var twentyfour = false;
// var celsius = false;

os.createDOM = function (params) {
    var d = document.createElement(params.type);
    if (params.class) {
        d.setAttribute('class', params.class);
    }
    if (params.src) {
        d.src = params.src;
    }
    if (params.id) {
        d.id = params.id;
    }
    if (params.innerHTML) {
        d.innerHTML = params.innerHTML;
    }
    if (params.attribute) {
        d.setAttribute(params.attribute[0], params.attribute[1]);
    }
    if (params.attribute2) {
        d.setAttribute(params.attribute2[0], params.attribute2[1]);
    }
    if (params.attribute3) {
        d.setAttribute(params.attribute3[0], params.attribute3[1]);
    }
    if (params.type === "img") {
        d.src = params.src;
    }
    if (params.appendChild) {
        d.appendChild(params.appendChild);
    }
    return d;
};

// var weathercode = 38671;
// var celsius = false;
// var twentyfour = false;


(function () {
    var convert = function (amount) {
        return Math.round((amount - 32) * 5 / 9);
    };

    weather({
        code: weathercode,
        temp: false,
        lang: 'en',
        gps: false, //must use WidgetWeather xml if set to true
        refresh: 15, // in minutes
        success: function (w) {
            var dayForecast, dayText, dtday, high, sdayText, cel, i,
                day, daytext, dayhigh;
            w.temp = celsius ? convert(w.temp) : w.temp;
            w.feelslike = celsius ? convert(w.feelslike) : w.feelslike;

            dayForecast = document.getElementById('forecast');

            dayForecast.innerHTML = '';

            for (i = 0; i < w.daily.length - 1; i += 1) {

                dayText = new Date(w.daily[i].validDate * 1000);
                dtday = dayText.getDay();

                dayText = translate[current].weekday[dtday];
                sdayText = translate[current].sday[dtday];
                cel = celsius ? 'C' : 'F';

                high = celsius ? convert(w.daily[i].maxTemp) : w.daily[i].maxTemp;


                if (isNaN(high)) {
                    high = w.temp;
                }

                day = os.createDOM({
                    type: 'div',
                    class: 'day'
                });
                daytext = os.createDOM({
                    type: 'div',
                    class: 'daytext',
                    innerHTML: sdayText
                });
                dayhigh = os.createDOM({
                    type: 'div',
                    class: 'temphi',
                    innerHTML: high + '<span class="cel">' + cel + '</span>'
                });
                //day.appendChild(dayicon);
                //day.appendChild(dayprecip);
                day.appendChild(dayhigh);
                day.appendChild(daytext);
                dayForecast.appendChild(day);
            }
        } //end success
    });


}());
