/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  window,
  show,
  weather,
  weathercode,
  clock,
  twentyfour,
  translate,
  current,
  celsius
*/

var os = {};
//
// var weathercode = "38671";
// var twentyfour = false;
// var celsius = false;

os.createDOM = function (params) {
    var d = document.createElement(params.type);
    if (params.class) {
        d.setAttribute('class', params.class);
    }
    if (params.src) {
        d.src = params.src;
    }
    if (params.id) {
        d.id = params.id;
    }
    if (params.innerHTML) {
        d.innerHTML = params.innerHTML;
    }
    if (params.attribute) {
        d.setAttribute(params.attribute[0], params.attribute[1]);
    }
    if (params.attribute2) {
        d.setAttribute(params.attribute2[0], params.attribute2[1]);
    }
    if (params.attribute3) {
        d.setAttribute(params.attribute3[0], params.attribute3[1]);
    }
    if (params.type === "img") {
        d.src = params.src;
    }
    if (params.appendChild) {
        d.appendChild(params.appendChild);
    }
    return d;
};

// var weathercode = 38671;
// var celsius = false;
// var twentyfour = false;


(function () {
    var convert = function (amount) {
        return Math.round((amount - 32) * 5 / 9);
    };

    weather({
        code: weathercode,
        temp: false,
        lang: 'en',
        gps: false, //must use WidgetWeather xml if set to true
        refresh: 15, // in minutes
        success: function (w) {
            w.temp = celsius ? convert(w.temp) : w.temp;
            w.feelslike = celsius ? convert(w.feelslike) : w.feelslike;

            var dayForecast = document.getElementById('forecast'),
                i,
                dayText,
                dtday,
                iconnum,
                high,
                low,
                sdayText,
                day,
                daytext,
                dayicon,
                dayhigh;

            dayForecast.innerHTML = '';

            for (i = 0; i < w.daily.length - 1; i += 1) {

                dayText = new Date(w.daily[i].validDate * 1000);
                dtday = dayText.getDay();
                dayText = translate[current].weekday[dtday];
                sdayText = translate[current].sday[dtday];

                try {
                    iconnum = w.daily[i].day.icon;
                } catch (err) {
                    iconnum = w.daily[i].night.icon;
                }

                high = celsius ? convert(w.daily[i].maxTemp) : w.daily[i].maxTemp;
                low = celsius ? convert(w.daily[i].minTemp) : w.daily[i].minTemp;

                if (isNaN(high)) {
                    high = w.temp;
                }

                day = os.createDOM({
                    type: 'div',
                    class: 'day'
                });
                daytext = os.createDOM({
                    type: 'div',
                    class: 'daytext',
                    innerHTML: sdayText
                });
                dayicon = os.createDOM({
                    type: 'div',
                    class: 'wicon',
                    attribute: ['style', 'background-image:url("src/icon/' + iconnum + '_small.png")']
                });
                dayhigh = os.createDOM({
                    type: 'div',
                    class: 'temphi',
                    innerHTML: high + '&deg;' + ' / <span class="templo">' + low + '&deg;</span>'
                });

                day.appendChild(daytext);
                day.appendChild(dayicon);
                day.appendChild(dayhigh);
                dayForecast.appendChild(day);
            }
        } //end success
    });


}());
