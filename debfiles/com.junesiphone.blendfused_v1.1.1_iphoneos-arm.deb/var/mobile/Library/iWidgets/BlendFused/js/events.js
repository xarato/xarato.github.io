//var $$, openapp, currentNowPlayingInfo, playMusic, musicPlaying, updateMusic, waittime, defaultmusicapp, changeNextTrack, changePrevTrack, loadApps, togglefeed, selectLI, loadPicker, fileExists; //debug only
var dragging;
document.getElementById('edit').addEventListener('click', function () { //edit apps
    'use strict';
    var elements = document.getElementsByClassName('editable'),
        i,
        elementArray;
    if (elements.length === 0) {
        elements = document.getElementsByClassName('editableNow');
        elementArray = [].slice.call(elements, 0);
        for (i = 0; i < elementArray.length; i += 1) {
            elementArray[i].className = "editable";
            touchLocked = false;
        }
    } else {
        elementArray = [].slice.call(elements, 0);
        for (i = 0; i < elementArray.length; i += 1) {
            elementArray[i].className = "editableNow";
            touchLocked = true;
        }
    }
});
document.getElementById('musicmenu').addEventListener('touchstart', function (el) { //animated menu on music page
    'use strict';
    var appid = el.target.id;
    if (appid === "youtube") {
        openapp('com.google.ios.youtube');
    }
    if (appid === "itunes") {
        openapp('com.apple.MobileStore');
    }
    if (appid === "voice") {
        openapp('com.apple.VoiceMemos');
    }
    if (appid === "podcast") {
        openapp('com.apple.podcasts');
    }
});
document.getElementById('musicpanel').addEventListener('touchstart', function (el) {
    'use strict';
    if (el.target.id !== "album") {
        document.getElementById(el.target.id).className = 'nani';
        setTimeout(function () {
            document.getElementById(el.target.id).className = ' ';
        }, 1000);
    }
    if (el.target.id === "playbutton") {
        if (currentNowPlayingInfo() !== null) { //if YouTube is playing it will be null
            playMusic();
            setTimeout(updateMusic, waittime);
        } else {
            openapp(defaultmusicapp);
            setTimeout(function () {
                if (musicPlaying()) {
                    if (currentNowPlayingInfo() !== null) {
                        updateMusic();
                    }
                }
            }, 10000);
        }
    }
    if (el.target.id === "forwardbutton") {
        if(musicPlaying()){
            if(currentNowPlayingInfo() != null){
                changeNextTrack();
                setTimeout(updateMusic, waittime);
            }
        }
    }
    if (el.target.id === "prevbutton") {
        if(musicPlaying()){
            if(currentNowPlayingInfo() != null){
                changePrevTrack();
                setTimeout(updateMusic, waittime);
            }
        }
    }
});
$$('.apps').sel().addEventListener('touchstart', function () {
    'use strict';
    loadApps();
});
$$('.bodyPanel').sel().addEventListener('touchstart', function (el) {
    'use strict';
    if (el.target.className !== 'apps') {
        $$('.appPanel').sel().style.display = 'none';
    }
});
$$('.appPanel').sel().addEventListener('touchend', function (el) {
    'use strict';
    if (el.target.nodeName === "LI") {
        if (!dragging && !touchLocked) {
            openapp(el.target.getAttribute('name'));
        }
    }
});
document.body.addEventListener('touchmove', function () {
    'use strict';
    dragging = true;
});
document.body.addEventListener('touchstart', function () {
    'use strict';
    dragging = false;
});
function changePage(el) { //SelectBlock Events
    'use strict';
    var divs = ['home', 'music', 'news', 'fav'],
        i;
    for (i = 0; i < divs.length; i += 1) {
        $$('.' + divs[i]).sel().style.display = "none";
    }
    $$('.' + el).sel().style.display = "block";
    if(el === 'fav'){
        document.getElementById('edit').style.display = "block";
    }
    else{document.getElementById('edit').style.display = "none";}
    if(el === 'home'){
        getTodo();
        document.getElementById('devicename').innerHTML = "<- " + deviceName() + " ->";
        document.getElementById('devicename').style.display = "block";
    }
    else{
        document.getElementById('devicename').style.display = "none";
    }
    if (el === "news") {
        togglefeed('open');
    } else {
        togglefeed('close');
    }
}
function deselectLI() {
    'use strict';
    var node = $$(".selectBlock").sel().getElementsByTagName("li"),
        i;
    for (i = 0; i < node.length; i += 1) {
        if (node[i].className === 'selected') {
            node[i].className = '';
        }
    }
}
function selectLI(el) {
    'use strict';
    if (el.target.nodeName === "LI") {
        deselectLI();
        el.target.className = 'selected';
        changePage(el.target.id);
    }
}
$$('.selectBlock').sel().addEventListener('touchstart', function (el) {
    'use strict';
    selectLI(el);
});



/*         APP CHANGING             */
/************************************/
/************************************/


function change(el) {  //comes from app divs for changing app.
    'use strict';
    loadPicker(el.parentElement.id);
}
var appArray = [];
if (localStorage.AppArray !== null) {
    var appArray = localStorage.AppArray.split(',');
}
function setApp(el, bundle, name) {
    'use strict';
    document.getElementById('system').innerHTML = "";
    $$('.appPanel').sel().style.display = "none";
    var divEl = document.getElementById(el);
    divEl.setAttribute('ontouchstart', 'openapp(\'' + bundle + '\')');
    if (fileExists('var/mobile/Library/iWidgets/Fused/img/icon/bundles/' + bundle + '.svg')) {
        divEl.innerHTML = '<div class="editableNow" onclick="change(this)">+</div><label>' + name + '</label><img class="icons" src="img/icon/bundles/' + bundle + '.svg"/>';
    } else {
        divEl.innerHTML = '<div class="editableNow" onclick="change(this)">+</div><label>' + name + '</label><img class="icons" src="img/icon/bundles/noicon.svg"/>';
    }
    appArray.push(el + '-' + name + '-' + bundle);
    localStorage.setItem('AppArray', appArray);
}
function reloadApp() {
    'use strict';
    var AA = localStorage.getItem('AppArray'),
        i,
        el,
        name,
        bundle,
        divEl;
    if (AA !== null) {
        AA = AA.split(",");
        for (i = 0; i < AA.length; i += 1) {
            el = AA[i].split('-')[0];
            name = AA[i].split('-')[1];
            bundle = AA[i].split('-')[2];
            divEl = document.getElementById(el);
            divEl.setAttribute('ontouchstart', 'openapp(\'' + bundle + '\')');
            if (fileExists('var/mobile/Library/iWidgets/Fused/img/icon/bundles/' + bundle + '.svg')) {
                divEl.innerHTML = '<div class="editable" onclick="change(this)">+</div><label>' + name + '</label><img class="icons" src="img/icon/bundles/' + bundle + '.svg"/>';
            } else {
                divEl.innerHTML = '<div class="editable" onclick="change(this)">+</div><label>' + name + '</label><img class="icons" src="img/icon/bundles/noicon.svg"/>';
            }
        }
    }
}