var tf = (localStorage.tf) ? JSON.parse(localStorage.tf) : false;
var pd = (localStorage.pd) ? JSON.parse(localStorage.pd) : false;
var celsius = (localStorage.celsius) ? JSON.parse(localStorage.celsius) : false;
var dg = (celsius) ? 'C' : 'F';
var movable = (localStorage.move) ? JSON.parse(localStorage.move) : false;
var tapTimer;

$$('.month').set(sday[clock.day()] + ", " + smonth[clock.month()] + " " + clock.date());
$$('#hour').set(clock.hour(tf,pd));
$$('#min').set(':'+clock.minute());

var weatherdivs = function() {
    $$('.city').set(weather.city());
    $$('.condition').set(Fcondition[weather.condition()]);
    $$('.temp').set(weather.temp('&deg;') + dg);
    $$('.hi').set((weather.high('') == "--") ? weather.temp('&deg;') + ' | ' + weather.low('&deg;')  : weather.high('&deg;') + ' | ' + weather.low('&deg;'));
    $$('.icon').sel().src='weather/1/' + '30' + '.svg';
    if (weather.city() == "Local Weather") {
        updateWeather();
    }
};
weather.start(60000 * 15);

function removedouble(div) {
    "use strict";
    var i;
    for (i = 0; i < locations.length; i += 1) {

        if (locations[i].id === div) {
            locations.splice(i, 1);
        }
    }
}
if (movable) {
    $('#wrap').draggable({
        grid: [1, 1],
        start: function(event, ui){
            clearTimeout(tapTimer);
        },
        stop: function(event, ui) {
            var tops, lefts, divid;
            tops = ui.position.top;
            lefts = ui.position.left;
            divid = this.id;
            removedouble(divid);
            locations.push({
                id: divid,
                top: tops,
                left: lefts
            });
            localStorage.setItem('positionxy', JSON.stringify(locations));
            //location.reload();
        }
    });
}


$$('#wrap').sel().addEventListener('touchstart', function () {
    tapTimer = window.setTimeout(function() {
        sset.create('24hr', 'tf', 'white');
        sset.create('Celsius', 'celsius', 'white');
        sset.create('PadZero', 'pd', 'white');
        sset.create('Move', 'move', 'white');
    }, 1000);
    return false;
});

$$('#wrap').sel().addEventListener('touchend', function () {
    clearTimeout(tapTimer);
    return false;
});