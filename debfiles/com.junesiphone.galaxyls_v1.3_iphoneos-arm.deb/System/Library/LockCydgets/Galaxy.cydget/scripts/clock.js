(function () {
    "use strict";
    var TwentyFourHour, weekdays, months, currentTime, currentHours, currentMinutes, day, month, date;
    TwentyFourHour = false;
    weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday","Saturday"];
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    currentTime = new Date();
    currentHours = currentTime.getHours();
    currentMinutes = currentTime.getMinutes();
    currentMinutes = (currentMinutes < 10 ? "0" : "") + currentMinutes;
    if (!TwentyFourHour) {
        currentHours = (currentHours > 12) ? currentHours - 12 : currentHours;
        currentHours = (currentHours === 0) ? 12 : currentHours;
    }
    day = currentTime.getDay();
    month = currentTime.getMonth();
    date = currentTime.getDate();
    document.getElementById('clock').innerHTML = currentHours + '<span class="avenir">:</span>' + currentMinutes;
    document.getElementById('clockshadow').innerHTML = currentHours + '<span class="avenir">:</span>' + currentMinutes;
    document.getElementById('date').innerHTML = weekdays[day] + ", " + months[month] + " " + date;
}());