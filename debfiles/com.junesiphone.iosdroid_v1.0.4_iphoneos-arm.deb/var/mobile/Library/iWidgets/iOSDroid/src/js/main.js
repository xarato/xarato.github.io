/*jslint
  node: true,
  sloppy: true,
  browser: true
*/

/*global
  iconDrawer,
  clock,
  twentyfour,
  translate,
  current,
  appBundles,
  showSVG,
  light,
  IS2W,
  IS2S,
  cyAlarm
*/

/*
        IS2 Weather Calls
        isCelsius, isWindSpeedMph, currentLocation, currentTemperature, currentCondition, currentConditionAsString,
        naturalLanguageDescription, highForCurrentDay, lowForCurrentDay, currentWindSpeed, currentWindDirection,
        currentWindChill, currentDewPoint, currentHumidity, currentVisiblityPercent, currentChanceOfRain, currentlyFeelsLike,
        currentPressure, sunsetTime, sunriseTime, currentLatitude, currentLongitude, hourlyForecastsForCurrentLocation,
        hourlyForecastsForCurrentLocationJSON, dayForecastsForCurrentLocation, dayForecastsForCurrentLocationJSON

*/


"use strict";

showSVG('.svgIcons, .sysImage', true);


/* color change */
//var light = true;
var css;
if (light) {
    css = ".googlebar{background-color: rgba(255,255,255,0.7)}input, input::-webkit-input-placeholder{color:#959595;}#button{color:#959595;}.iWidget{background-color:#f6f6f6;}.timeHolder,.weatherHolder,.iconsHolder{background-color:white;}.statusbar,.droidButtons{background-color:black;}#messageBadge, #mailBadge{color:white;}";
}

var style = document.createElement('style');
style.type = 'text/css';
style.appendChild(document.createTextNode(css));
document.getElementsByTagName('head')[0].appendChild(style);


// Search
function openlink() {
    var search = document.getElementById("search");
    iconDrawer.openUrl("http://www.google.com/search?q=" + encodeURIComponent(search.value));
    search.value = "";
}
//end search

/* Clocks */
clock({
    twentyfour: twentyfour,
    padzero: true,
    refresh: 1000,
    success: function (clock) {
        document.getElementById('time').innerHTML = clock.hour() + ':' + clock.minute();
        document.getElementById('date').innerHTML = translate[current].weekday[clock.day()] + ', ' + translate[current].month[clock.month()] + ' ' + clock.date();
    }
});
/* End Clocks */

/* Weather */

function changeDivs() {
    var days = JSON.parse(IS2W('dayForecastsForCurrentLocationJSON')),
        celsius = (IS2W('isCelsius')) ? 'C' : 'F',
        doc = document,
        f,
        iconLocation = 'src/images/weather/plex/',
        correctImage;

    doc.getElementById('city').innerHTML = IS2W('currentLocation');
    doc.getElementById('condition').innerHTML = IS2W('currentConditionAsString');
    doc.getElementById('icon').src = 'src/images/weather/plex/' + IS2W('currentCondition') + '.png';
    doc.getElementById('temp').innerHTML = IS2W('currentTemperature');
    doc.getElementById('high').innerHTML = IS2W('highForCurrentDay') + "&deg;";
    doc.getElementById('low').innerHTML = IS2W('lowForCurrentDay') + "&deg;";

    for (f = 1; f < 4; f += 1) {
        correctImage = (days[f].condition === 3200) ? iconLocation + IS2W('currentCondition') + ".png" : iconLocation + days[f].condition + ".png";
        doc.getElementById('day' + f + 'icon').src = correctImage;
        doc.getElementById('day' + f + 'temphi').innerHTML = days[f].high + '&deg;' + celsius;
        doc.getElementById('day' + f + 'templo').innerHTML = days[f].low + '&deg;' + celsius;
        doc.getElementById('day' + f + 'day').innerHTML = translate[current].sday[days[f].dayOfWeek - 1];
    }
}

(function weather() {
    IS2W('updateWeather');
    setTimeout(function () {
        changeDivs();
    }, 2000);
    setTimeout(weather, 10 * 60000);
}());

/* Battery and stuff that loads often */
(function loadBattery() {
    var chargeText,
        chargeInt = IS2S('batteryStateAsInteger'),
        battery = IS2S('batteryPercent'),
        alarm = cyAlarm(),
        minute,
        doc = document;
    doc.getElementById('batteryPercent').innerHTML = battery + "%";
    doc.getElementById('batteryinsides').style.width = Math.round((battery / 100) * 18) + 'px';

    if (chargeInt === 1) {
        chargeText = "Device is not charging";
    } else if (chargeInt === 2) {
        chargeText = "Device is charging";
    } else {
        chargeText = "Device is fully charged";
    }
    doc.getElementById('battery').innerHTML = chargeText;

    /* Alarm */
    if (alarm && alarm[0]) {
        minute = (alarm[0].userInfo.minute == '0') ? '0' + alarm[0].userInfo.minute : alarm[0].userInfo.minute;
        alarm = String(alarm[0]).split("next")[1].split("=")[1].substring(0, 4) + " " + alarm[0].userInfo.hour + ":" + minute;
    } else {
        alarm = "No Alarms";
    }
    doc.getElementById('alarmtime').innerHTML = alarm;

    /* Badges */
    if (iconDrawer.getNotificationCount(appBundles.mail) > 0) {
        doc.getElementById('mailBadge').innerHTML = iconDrawer.getNotificationCount(appBundles.mail);
    } else {
        doc.getElementById('mailBadge').innerHTML = "";
    }

    if (iconDrawer.getNotificationCount(appBundles.messages) > 0) {
        doc.getElementById('messageBadge').innerHTML = iconDrawer.getNotificationCount(appBundles.messages);
    } else {
        doc.getElementById('messageBadge').innerHTML = "";
    }

    /* call again */
    setTimeout(loadBattery, 3000);
}());

/* End Battery */


/* Dock Events */
document.getElementById('holder').addEventListener('touchstart', function (el) {
    iconDrawer.openApp(appBundles[el.target.id]);
});
