
var setAlarm, alarmHour, alarmMinute, padMinute, setAlarm, tapTimer,
    tf = (localStorage.tf) ? JSON.parse(localStorage.tf) : false,
    celsius = (localStorage.celsius) ? JSON.parse(localStorage.celsius) : false,
    black = (localStorage.black) ? JSON.parse(localStorage.black) : false,
    dg = (celsius) ? 'c' : 'f';

//color change
if (black) {
    var css = "*{color:black;}.bgglance{background-color:rgba(255,255,255,0.6);}.bginfo{background-color:rgba(255,255,255,0.6);}.bgglance:after{background: rgba(255,255,255,0.6);}";
    var htmlDiv = document.createElement('div');
    htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
    document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);
}
if (iOSAlarms !== "No Alarms") {
    $$('.alarm').set('> next alarm ' + iOSAlarms);
} else {
    $$('.alarm').set('> next alarm 0:00');
}
//battery
$$('.battery').set("> " + batteryState() + ", " + batteryState('percent') + "%");

//weather
var weatherdivs = function() {
    $$('.weather').set("> " + Fcondition[weather.condition()] + ", " + weather.temp('&deg;') + dg);
    $$('.lohi').set("max " + weather.high('&deg;') + dg + " - min " + weather.low('&deg;') + dg);
    if (weather.city() == "Local Weather") {
        updateWeather();
    }
};
weather.start(60000 * 15);

//clock
$$('.hour').set(clock.hour(tf, true));
$$('.minute').set(clock.minute());
$$('.day').set(clock.daytext() + ", " + clock.year());
$$('.fulldate').set("> " + clock.sdaytext() + " " + clock.date() + ", " + clock.monthtext() + " " + clock.year());

//settings
var togglestate = function() {
    var state = $$('.info').sel().style.display;
    if (state === "block") {
        $$('.info').sel().style.display = "none";
        $$('.glance').sel().style.display = "block";
    } else {
        $$('.info').sel().style.display = "block";
        $$('.glance').sel().style.display = "none";
    }
};

//events
$$('.glance').sel().addEventListener('click', function () {
    togglestate();
});
$$('.info').sel().addEventListener('click', function () {
    togglestate();
});

$$('.glance').sel().addEventListener('touchstart', function () {
    tapTimer = window.setTimeout(function() {
        sset.create('24hr', 'tf', 'white');
        sset.create('Celsius', 'celsius', 'white');
        sset.create('Black', 'black', 'white');
    }, 1000);
    return false;
});

$$('.glance').sel().addEventListener('touchend', function () {
    clearTimeout(tapTimer);
    return false;
});