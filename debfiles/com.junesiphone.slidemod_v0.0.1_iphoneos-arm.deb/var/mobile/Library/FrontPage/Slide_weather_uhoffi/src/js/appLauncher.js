'use strict';

Array.prototype.move = function (old_index, new_index) {
    if (new_index >= this.length) {
        var k = new_index - this.length;
        while ((k--) + 1) {
            this.push(undefined);
        }
    }
    this.splice(new_index, 0, this.splice(old_index, 1)[0]);
    return this;
};
Array.prototype.contains = function (obj) {
    return this.indexOf(obj) > -1;
};


/* Create appDrawer methods */
var appDrawer = {
    inEditMode: false,
    inFavorites: false,
    drawerScrolling: false,
    favoriteArray: [],
    appInfo: [],
    favInfo: [],
    touchTimer: false,
    timerFired: false,
    touchedApp: "",
    iconContainer: document.getElementById('iconContainer'),
    showDrawer: function () {
        document.getElementById('appDrawerDiv').style.top = '0px';
    },
    showEditFav: function (nohide) {
        var selectors = document.getElementsByClassName('check'),
            i;
        for (i = 0; i < selectors.length; i += 1) {
            if (selectors[i].title === 'inFav') {
                selectors[i].style.opacity = 1;
            } else {
                selectors[i].style.opacity = 0.2;
            }
            if (nohide) {
                selectors[i].style.display = 'block';
            } else {
                selectors[i].style.display = 'none';
            }
        }
    },
    showEditApp: function () {
        var sheet = document.createElement('style');
        if (this.inEditMode) {
            sheet.innerHTML = ".moveup, .movedown{display:block;}";
        } else {
            sheet.innerHTML = ".moveup, .movedown{display:none;}";
        }
        document.body.appendChild(sheet);
    },
    editMode: function (nohide) {
        if (this.inFavorites) {
            this.showEditApp(); //edit the app in Favorites
        } else {
            this.showEditFav(nohide); //add apps to favorites
        }
    },
    saveLocal: function (bundle, name, save) {
        if (save) {
            this.favoriteArray.push(bundle + '~' + name);
        } else {
            var e = this.favoriteArray.indexOf(bundle + '~' + name);
            if (e !== -1) {
                this.favoriteArray.splice(e, 1);
            }
        }
        localStorage.appLauncher = JSON.stringify(this.favoriteArray);
    },
    addToStorage: function (span, bundle, name) {
        span.setAttribute('title', 'inFav');
        span.style.opacity = 1;
        this.saveLocal(bundle, name, true);
    },
    removeFromStorage: function (span, bundle, name) {
        span.setAttribute('title', 'null');
        span.style.opacity = 0.2;
        this.saveLocal(bundle, name, false);
    },
    onload: function () {
        if (localStorage.appLauncher) {
            var storage = JSON.parse(localStorage.appLauncher),
                i,
                c;
            if (storage) {
                for (i = 0; i < storage.length; i += 1) {
                    c = document.getElementById(storage[i].split('~')[0]);
                    if (c !== null) {
                        c.children[0].children[2].setAttribute('title', 'inFav');
                    }
                }
            }
        }
    },
    moveItem: function (pos, el) {
        var bundle, name, e;
        bundle = el.parentNode.parentNode.id;
        name = el.parentNode.parentNode.getAttribute('tag');
        e = this.favoriteArray.indexOf(bundle + '~' + name);
        if (pos === 'up') {
            if ((e - 1) >= 0) {
                this.favoriteArray.move(e, e - 1);
            }
        } else {
            if ((e + 1) <= this.favoriteArray.length - 1) {
                this.favoriteArray.move(e, e + 1);
            }
        }
        localStorage.appLauncher = JSON.stringify(this.favoriteArray);
        this.favApps();
        this.inEditMode = true;
    },
    createItemForLauncher: function (name, bundle) {
        var li, div, img, label, span, span1, span2, badge, badgespan;
        badge = appDrawer.getNotificationCount(bundle);
        li = document.createElement('li');
        div = document.createElement('div');
        img = document.createElement('img');
        label = document.createElement('label');
        span = document.createElement('span');
        span1 = document.createElement('span');
        span2 = document.createElement('span');
        badgespan = document.createElement('span');
        span1.innerHTML = 'l';
        span2.innerHTML = 'x';
        badgespan.innerHTML = (badge > 0) ? badge : '';
        badgespan.className = 'drawerBadges';
        badgespan.id = "badgeID" + bundle;
        span1.className = 'movedown';
        span2.className = 'moveup';
        span1.setAttribute('title', 'down');
        span2.setAttribute('title', 'up');
        span.innerHTML = "9";
        span.className = 'check';
        img.src = '/var/mobile/Library/FrontPageCache/' + appDrawer.checkBundle(bundle) + '.png';
        label.innerHTML = name;
        div.className = 'iconHolder';
        li.setAttribute('title', bundle);
        li.setAttribute('tag', name);
        li.id = bundle;
        div.appendChild(img);
        div.appendChild(label);
        div.appendChild(span);
        div.appendChild(span1);
        div.appendChild(span2);
        div.appendChild(badgespan);
        li.appendChild(div);
        this.iconContainer.appendChild(li);
    },
    hideFavs: function () {
        var sheet = document.createElement('style');
        sheet.innerHTML = ".moveup, .movedown{display:none;}";
        document.body.appendChild(sheet);
        this.inEditMode = false;
        this.inFavorites = false;
    },
    menuState: function(state){
        var fav,
            all,
            more,
            edit,
            d = document;
        switch(state) {
            case "allApps":
                fav = 'rgba(0,0,0,0)';
                all = 'rgba(0,0,0,0.1)';
                more = 'rgba(0,0,0,0)';
                edit = '1';
                break;
            case 'favApps':
                fav = 'rgba(0,0,0,0.1)';
                all = 'rgba(0,0,0,0)';
                more = 'rgba(0,0,0,0)';
                edit = 'Z';
                break;
            case 'moreApps':
                fav = 'rgba(0,0,0,0)';
                all = 'rgba(0,0,0,0)';
                more = 'rgba(0,0,0,0.1)';
                edit = '1';
                break;
        }

        d.getElementById('fav').style.backgroundColor = fav;
        d.getElementById('all').style.backgroundColor = all;
        d.getElementById('more').style.backgroundColor = more;
        d.getElementById('edit').innerHTML = edit;
    },
    allApps: function () {
        var i,
            contents;
        this.menuState('allApps');
        this.hideFavs();
        this.inFavorites = false;
        this.iconContainer.innerHTML = '';
        this.inEditMode = false;
        for (i = 0; i < appDrawer.appInfo.length; i += 1) {
            contents = appDrawer.appInfo[i].split('~');
            this.createItemForLauncher(contents[0], contents[1]);
        }
        this.onload();
    },
    savedLocalStorage: function () {
        if (localStorage.appLauncher !== null && localStorage.appLauncher !== undefined && localStorage.appLauncher !== 'null' && localStorage.appLauncher !== 'undefined') {
            return true;
        }
        return false;
    },
    getFavList: function (bundle, name) {
        this.favInfo.push(name + '~' + bundle);
    },
    checkBundle: function (iconBundle) {
        if (iconBundle === 'com.agilebits.onepassword') {
            iconBundle = 'com.agilebits.onepassword-ios';
        }
        if (iconBundle === 'com.groupme.iphone') {
            iconBundle = 'com.groupme.iphone-app';
        }
        if (iconBundle === 'com.cn') {
            iconBundle = 'com.cn-rulez.Blurify';
        }
        if (iconBundle === 'crash') {
            iconBundle = 'crash-reporter';
        }
        if (iconBundle === 'com.filippobiga.springtomize3') {
            iconBundle = 'com.filippobiga.springtomize3-app';
        }
        if (iconBundle === 'org.xbmc.kodi') {
            iconBundle = 'org.xbmc.kodi-ios';
        }
        if (iconBundle === 'com.algoriddim.djay') {
            iconBundle = 'com.algoriddim.djay-pro-iphone';
        }
        return iconBundle;
    },
    getAppIcon: function (bundle) {
        try {
            if (bundle) {
                return '/var/mobile/Library/FrontPageCache/' + appDrawer.checkBundle(bundle) + '.png';
            }
            return 0;
        } catch (err) {
            return 0;
        }
    },
    getNotificationCount: function (bundle) {
        try {
            if (bundle) {
                return FPI.bundle[appDrawer.checkBundle(bundle)].badge;
            }
            return 0;
        } catch (err) {
            return 0;
        }
    },
    favApps: function () {
        var storage, i, e, name, bundle;
        this.menuState('favApps');
        this.inFavorites = true;
        appDrawer.favInfo = [];
        this.iconContainer.innerHTML = '';
        this.inEditMode = false;
        if (this.savedLocalStorage()) {
            storage = JSON.parse(localStorage.appLauncher);
            if (storage) {
                for (i = 0; i < storage.length; i += 1) {
                    appDrawer.getFavList(storage[i].split('~')[0], storage[i].split('~')[1]);
                }
                for (e = 0; e < appDrawer.favInfo.length; e += 1) {
                    name = appDrawer.favInfo[e].split('~')[0];
                    bundle = appDrawer.favInfo[e].split('~')[1];
                    this.createItemForLauncher(name, bundle);
                }
            }
        }
    },
    moreApps: function () {
        var i,
            name,
            bundle,
            badge;
        this.menuState('moreApps');
        this.iconContainer.innerHTML = '';
        this.hideFavs();
        this.inFavorites = false;
        this.iconContainer.innerHTML = '';
        this.inEditMode = false;
        for (i = 0; i < appDrawer.appInfo.length; i += 1) {
            name = appDrawer.appInfo[i].split('~')[0];
            bundle = appDrawer.appInfo[i].split('~')[1];
            badge = appDrawer.appInfo[i].split('~')[2];
            if (appDrawer.getNotificationCount(bundle) >= 1) {
                this.createItemForLauncher(name, bundle);
            }
        }
    },
    clearBlacklist: function () {
        localStorage.removeItem('blacklist');
        appDrawer.refreshApps();
        AppDrawer.allApps();
    },
    refreshApps: function () {
        var applications = FPI.apps.all,
            i,
            displayNames,
            bundle;
        this.appInfo = [];
        for (i = 0; i < applications.length; i += 1) {
            displayNames = applications[i].name;
            bundle = applications[i].bundle;
            if (!blacklist.contains(bundle)) {
                this.appInfo.push(displayNames + '~' + bundle);
            }
        }
        this.appInfo.sort();
    },
    initializeAppDrawer: function () {
        try {
            appDrawer.refreshApps();
            if (this.savedLocalStorage()) {
                var storage = JSON.parse(localStorage.appLauncher),
                    i;
                if (storage) {
                    for (i = 0; i < storage.length; i += 1) {
                        appDrawer.favoriteArray.push(storage[i]); //push back to local array
                    }
                }
            }
            appDrawer.allApps();
        } catch (err) {
            alert("Error initializing AppDrawer: " + err);
        }
    }
};

/* Events used to control the appDrawer */
appDrawer.iconContainer.addEventListener('touchmove', function () {
    appDrawer.drawerScrolling = true;
});
appDrawer.iconContainer.addEventListener('touchstart', function (e) {
    appDrawer.touchedApp = e.target.title;
    appDrawer.touchTimer = setTimeout(function () {
        appDrawer.timerFired = true;
        var cfrm = "Do you wish to hide this app " + appDrawer.touchedApp;
        var ifOK = confirm(cfrm);
        if (ifOK) {
            if (appDrawer.touchedApp === 'com.agilebits.onepassword-ios' || appDrawer.touchedApp === 'com.agilebits.onepassword') {
                blacklist.push('com.agilebits.onepassword');
                blacklist.push('com.agilebits.onepassword-ios');
            } else {
                blacklist.push(appDrawer.touchedApp);
            }
            localStorage.blacklist = JSON.stringify(blacklist);
            appDrawer.refreshApps();
            appDrawer.allApps();
            alert("App Removed, to clear all removed hold down on the x");
        }
    }, 2000);
});
appDrawer.iconContainer.addEventListener('touchend', function (e) {
    clearTimeout(appDrawer.touchTimer);
    if (!appDrawer.drawerScrolling) {
        if (appDrawer.inEditMode) {
            if (appDrawer.inFavorites) {
                if (e.target.title === 'up' || e.target.title === 'down') {
                    appDrawer.moveItem(e.target.title, e.target);
                }
            } else {
                var span = e.target.children[0].children[2];
                if (span.title === 'inFav') {
                    appDrawer.removeFromStorage(e.target.children[0].children[2], e.target.title, e.target.getAttribute('tag'));
                } else {
                    appDrawer.addToStorage(e.target.children[0].children[2], e.target.title, e.target.getAttribute('tag'));
                }
                refreshFavAppsInActionBar();
            }
        } else {
            openApp(e.target.title);
        }
    }
    appDrawer.drawerScrolling = false;
    appDrawer.timerFired = false;
});
document.getElementById('edit').addEventListener('click', function () {
    if (!appDrawer.inEditMode) {
        appDrawer.inEditMode = true;
        appDrawer.editMode(true);
    } else {
        appDrawer.inEditMode = false;
        appDrawer.editMode(false);
    }
});
document.getElementById('all').addEventListener('touchstart', function () {
    try {
        appDrawer.allApps();
    } catch (err) {
        alert("Error initializing AppDrawer: (BTN) " + err);
    }
});
document.getElementById('fav').addEventListener('touchstart', function () {
    appDrawer.favApps();
});
document.getElementById('more').addEventListener('touchstart', function () {
    appDrawer.moreApps();
});
document.getElementById('close').addEventListener('touchstart', function () {
    appDrawer.touchTimer = setTimeout(function () {
        appDrawer.timerFired = true;
        var cfrm = "Do you wish to show all hidden apps? ",
            ifOK = confirm(cfrm);
        if (ifOK) {
            blacklist = [];
            localStorage.removeItem('blacklist');
            appDrawer.refreshApps();
            appDrawer.allApps();
        }
    }, 2000);
});
document.getElementById('close').addEventListener('touchend', function () {
    clearTimeout(appDrawer.touchTimer);
    appDrawer.timerFired = false;
    document.getElementById('appDrawerDiv').style.left = 800;
});
// document.getElementById('openDrawer').addEventListener('click', function () {
//     document.getElementById('appDrawerDiv').style.top = '0px';
// });
