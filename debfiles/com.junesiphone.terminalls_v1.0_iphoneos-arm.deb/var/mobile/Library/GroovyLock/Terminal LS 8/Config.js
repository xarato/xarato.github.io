
var textColor = "white"; //use words such as red, blue, etc, or use hex #ffffff, #67c446, etc. Settings require respring.
var bgColor = "transparent"; //use words such as red, blue, etc, or use hex #ffffff, #67c446, etc.
var fontStyle = false; //turn on to use system font, if you have bytafont it will use bytafont font.
var username = "JunesiPhone"; //If you would like to use an image as a bg, place the image in var/mobile/library/GroovyLock/Terminal LS/image.jpg
var bgImage = false; //If you would like to use an image as a bg, place the image in var/mobile/library/GroovyLock/Terminal LS/image.jpg
var INFO = ""; // commands you can enter on the LS. color, bgcolor, time, memory, name, login, and clear
