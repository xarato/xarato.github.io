/* Event Handlers */
'use strict';

$("#iwidget").on("touchstart", function (e) {
    if (!tapped) {
        tapped = setTimeout(function () {
            tapped = null;
            showHideElement(appList, 'none');
        }, 300);
    } else {
        clearTimeout(tapped); //stop single tap callback
        tapped = null;
        showIconAddMenu();
    }
});

document.getElementById('appPicker').addEventListener('click', function (el) {
    var name = el.target.getAttribute('name');
    if (name === 'Edit') {
        var editButton = document.getElementById('EditText');
        if (editButton.innerHTML === 'Enable Edit') {
            editButton.innerHTML = 'Disable Edit';
            editMode = true;
            document.getElementById('appContainer').style.pointerEvents = 'initial';
        } else {
           editButton.innerHTML = 'Enable Edit';
           editMode = false;
           document.getElementById('appContainer').style.pointerEvents = 'none';
        }

    }else{
        document.getElementById('appPicker').innerHTML = '';
        document.getElementById('appPicker').style.display = 'none';
        createIcon(name);
    }
});
document.getElementById('iwidget').addEventListener('touchend', function (el) {
    if (el.target.title == 'bg') {
        hideMenus();
    } else {
        if (!appMoving) {
            InfoStats.openApp(el.target.title);
        }
    }
}, false);
document.getElementById('notificationApps').addEventListener('touchstart', function (el) {
    InfoStats.openApp(el.target.title);
}, false);
document.getElementById('bottomTap').addEventListener('touchstart', function (el) {
    showTaskbar();
}, false);
document.getElementById('notifications').addEventListener('touchstart', function () {
    toggleDiv('notificationPanel', InfoStats.notifications, true);
}, false);
document.getElementById('switcher').addEventListener('touchstart', function (el) {
    InfoStats.openApp(el.target.title);
}, false);
document.getElementById('favApps').addEventListener('touchstart', function (el) {
    InfoStats.openApp(el.target.title);
}, false);
document.getElementById('bottomApps').addEventListener('touchstart', function (el) {
    whichBottomApp(el.target.title);
}, false);
document.getElementById('start').addEventListener('touchstart', function () {
    toggleDiv('menu', InfoStats.notifications, false);
});
document.getElementById('infoBar').addEventListener('touchstart', function () {
    toggleDiv('infoPanel', undefined, false);
    InfoStats.memoryPanel();
});
document.getElementById('timeDate').addEventListener('touchstart', function () {
    InfoStats.openApp(appBundles['clock']);
});


document.body.addEventListener('touchstart', function () {
    //hideDock();
});