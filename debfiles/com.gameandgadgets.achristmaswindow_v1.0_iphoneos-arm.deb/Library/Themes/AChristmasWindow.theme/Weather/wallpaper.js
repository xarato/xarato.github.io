/**
 * wallpaper.JS
 * Wallpaper shows clock as well as weather(fed by Yahoo), takes one row of icon.
 * By Shitiz "Dragooon" Garg (mail[at]dragooon.net)
 * Redestribution not allowed without written permission
 * Idea from "Active Weather Wallpaper" found in Cydia store
 */

var temperature, humidity, code, city, low, high, condition = '';
var weatherInterval, clockInterval = null;
var current_time = new Date();
var in_progress = false;


// OnLoad event, handles the initialisation of clock/weather
var windowOnLoad = function()
{
	// Disable BG?
	//if (!enableBG)
	//	document.getElementById('bg_el').style.display = 'none';

	// Set the date and the interval
	setClock();
	clockIntervalHandler = setInterval('setClock()', 1000);

};

// Sets the clock
var setClock = function()
{
	var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
	var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

	var current_time = new Date();

	// Get the date string
	var date_string = days[current_time.getDay()] + ', ' + current_time.getDate() + ' ' + months[current_time.getMonth()];

	var hours = current_time.getHours();
	var minutes = current_time.getMinutes();
	if (ampm_format === true)
	{
		var is_pm = hours > 12;
		var is_pm1 = hours > 11;
		hours = is_pm ? hours - 12 : hours;

		var am_pm = document.createElement('span');
		am_pm.innerHTML = is_pm1 ? 'PM' : 'AM';
		am_pm.style.fontSize = '8px';
	}

	// Get the time string
	var time_string = hours + ':' + (minutes < 10 ? '0' + minutes : minutes);

	// Set them
	document.getElementById('clock').innerHTML = time_string;
	document.getElementById('calendar').innerHTML = date_string;
	if (ampm_format === true && show_ampm)
		document.getElementById('clock').appendChild(am_pm);
}


// Parses a string in format hh:mm a/p and returns the time and minute in 24 hour format
function parseTimeString(string)
{
	var parts = string.split(':');
	var hour = parseInt(parts[0]);
	parts = parts[1].split(' ');
	var minute = parseInt(parts[0]);

	// We got PM?
	if (parts[1].toLowerCase() == 'pm' && hour != 12)
		hour += 12;

	return [hour, minute];
}
window.onload = windowOnLoad;