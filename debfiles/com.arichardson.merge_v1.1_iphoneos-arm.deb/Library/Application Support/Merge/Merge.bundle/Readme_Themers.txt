Looking to theme Merge? Currently only the action header background in the conversation view can be themed, but if you want to theme it, you need two images:

1. A 320 point wide, 43 point high portrait background image named "header_bg.png"
2. A 480 point wide, 43 point high landscape background image named "header_bg_landscape.png"

Just place those here and they'll automatically be detected on the next launch of the Messages app.