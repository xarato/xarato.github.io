'use strict';
function clock(options) {
    var getTimes = function () {
            var d = new Date(),
                funcs = {
                    hour: function () {
                        var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
                        hour = (options.padzero === true) ? (hour < 10 ? "0" + hour : " " + hour) : hour;
                        return hour;
                    },
                    minute: function () {
                        return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
                    },
                    date: function () {
                        return d.getDate();
                    },
                    day: function () {
                        return d.getDay();
                    },
                    month: function () {
                        return d.getMonth();
                    },
                    daytext: function () {
                        var textdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                        return textdays[this.day()];
                    },
                    monthtext: function () {
                        var textmonth = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                        return textmonth[this.month()];
                    }
                };
            options.success(funcs);
            setTimeout(function () {
                getTimes();
            }, options.refresh);
        };
    getTimes();
}
clock({
    twentyfour : false,
    padzero : false,
    refresh : 5000,
    success: function (clock) {
        document.getElementById('clock').innerHTML = clock.hour() + '<span class="avenir">:</span>' + clock.minute();
        document.getElementById('date').innerHTML = clock.daytext() + ", " + clock.monthtext() + " " + clock.date();
    }
});
