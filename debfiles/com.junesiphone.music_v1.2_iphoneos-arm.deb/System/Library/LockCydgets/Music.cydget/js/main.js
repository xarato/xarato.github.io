//main functions
function playmusic() {
    cyMusic.playMusic();
    cyMusic.updateMusic();
}
function nexttrack() {
    cyMusic.changeNextTrack();
    cyMusic.updateMusic();
}
function prevtrack() {
    cyMusic.changePrevTrack();
    cyMusic.updateMusic();
}
function openapp() {
    var appname = document.getElementById('app').getAttribute('name');
    cyMusic.launchApp(appname);
}
//helper
var $$ = {
    addClass: function (el, cls) {
        el.classList.add(cls);
    },
    removeClass: function (el, cls) {
        el.classList.remove(cls);
    },
    getEL: function (el) {
        return document.getElementById(el);
    },
    getStyle: function (oElm, strCssRule) {
        var strValue = "";
        if (document.defaultView && document.defaultView.getComputedStyle) {
            strValue = document.defaultView.getComputedStyle(oElm, "").getPropertyValue(strCssRule);
        } else if (oElm.currentStyle) {
            strCssRule = strCssRule.replace(/\-(\w)/g, function (p1) {
                return p1.toUpperCase();
            });
            strValue = oElm.currentStyle[strCssRule];
        }
        return strValue;
    }
};
//drag
var drag = function () {
    return {
        move: function (div, xpos, ypos) {
            div.style.left = xpos + "px";
            div.style.top = ypos + "px"; //not moving y axis in this case

        },
        startMoving: function (div, evt) {
            evt = evt || window.event;
            var posX = evt.touches[0].clientX,
                posY = evt.touches[0].clientY,
                divTop = div.style.top.replace('px', ''),
                divLeft = div.style.left.replace('px', ''),
                offsetX = posX - divLeft,
                offsetY = posY - divTop;

            $$.getEL("musiccovercircle").ontouchmove = function (evt) {
                evt.preventDefault();
                evt = evt || window.event;
                posX = evt.touches[0].clientX;
                posY = evt.touches[0].clientY;
                var cWidth = $$.getStyle($$.getEL('mcontain'), 'width').replace('px', ''),
                    dWidth = $$.getStyle($$.getEL('musiccovercircle'), 'width').replace('px', ''),
                    finalX = posX - offsetX,
                    finalY = posY - offsetY;
                if (finalX < 0) {
                    finalX = 0;
                }
                if (finalY < 0) {
                    finalY = 0;
                }
                if (finalX <= cWidth - dWidth - 8 && finalY <= cWidth - dWidth) {
                    drag.move(div, finalX, finalY);
                }

                $$.getEL('detailsm').innerHTML = "X: " + posX + "Y: " + posY;
            };
        },
        stopMoving: function (div, evt) {
            var mX = evt.changedTouches[0].clientX,
                mY = evt.changedTouches[0].clientY;
            if (mX <= 130) {
                $$.addClass($$.getEL('larrow'), "nani");
                setTimeout(function () {
                    $$.removeClass($$.getEL('larrow'), "nani");
                }, 1000);
                setTimeout(prevtrack, 0);
                evt.preventDefault();
            } else if (mX >= 225) {
                $$.addClass($$.getEL('narrow'), "nani");
                setTimeout(function () {
                    $$.removeClass($$.getEL('narrow'), "nani");
                }, 1000);
                setTimeout(nexttrack, 0);
                evt.preventDefault();
            }
            if (mY <= 280) {
                playmusic();
                if (cyMusic.isPaused()) {
                    $$.addClass($$.getEL('pbutton'), "nani");
                    setTimeout(function () {
                        $$.removeClass($$.getEL('pbutton'), "nani");
                    }, 1000);
                } else {
                    $$.addClass($$.getEL('pabutton'), "nani");
                    setTimeout(function () {
                        $$.removeClass($$.getEL('pabutton'), "nani");
                    }, 1000);
                }
            } else if (mY >= 380) {
                if ($$.getEL('musicinfo').style.display === "none") {
                    cyMusic.updateMusic();
                    $$.getEL('musicinfo').style.display = "block";
                } else {
                    $$.getEL('musicinfo').style.display = "none";
                }
            }
            div.style.left = "52px";
            div.style.top = "40px";
        },
    };
}();
//sizing
if (window.innerWidth === 375) {
    document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.18, maximum-scale=1.18, user-scalable=0');
} else if (window.innerWidth === 414) {
    document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.3, maximum-scale=1.3, user-scalable=0');
}
//autostart
if (cyMusic.musicPlaying()) { //Some apps takes longer to load next song:(
    var nowPlayingController = cyMusic.NPController(),
        waittime,
        app,
        icon,
        elemt;
    if (cyMusic.getApp() == "com.pandora") {
        cyMusic.waittime = 1500;
        app = "com.pandora";
        icon = "pandora";
    } else if (cyMusic.getApp() == "com.spotify.client") {
        cyMusic.waittime = 1500;
        app = "com.spotify.client";
        icon = "spotify";
    } else if (cyMusic.getApp() == "com.soundcloud.TouchApp") {
        cyMusic.waittime = 1500;
        app = "com.soundcloud.TouchApp";
        icon = "soundcloud";
    } else {
        cyMusic.waittime = 500;
        app = 'com.apple.Music';
        icon = "music";
    }
    document.getElementById('app').setAttribute('name', app);
    document.getElementById('app').src = 'img/' + icon + '.png';
    try {
        if (cyMusic.currentNowPlayingInfo() !== null) { //if YouTube is playing it will be null
            cyMusic.updateMusic();
        } else {
            //do nothing, if YouTube is playing (or a video is ended and still shows playing ) will send to safemode.
        }
    } catch (err) {
        alert("Show this error to the developer. " + err);
    }
}
//events
elemt = $$.getEL("musiccovercircle");
elemt.addEventListener('touchstart', function () {
    drag.startMoving(this, event);
}, false);

elemt.addEventListener('touchend', function () {
    drag.stopMoving(this, event);
}, false);
