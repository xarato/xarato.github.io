var tf = (localStorage.tf) ? JSON.parse(localStorage.tf) : false;
$$('.time').set(clock.hour(tf,true)+":"+clock.minute());
$$('.date').set("the " + clock.datetext() + " of " + clock.monthtext());
$$('.svg').sel().src = "svg/" + clock.day() + ".svg";
$$('.svgshadow').sel().src = "svg/" + clock.day() + ".svg";
showSVG('.svg,.svgshadow', true);
$$('.day').sel().addEventListener('click',function(){
    sset.create('24hr','tf','white');
    sset.create('Move','move','white');
});

var locations = (localStorage.positionxy) ? JSON.parse(localStorage.getItem('positionxy')) : [];
var movable = (localStorage.move) ? JSON.parse(localStorage.move) : false;

function removedouble(div) {
    "use strict";
    var i;
    for (i = 0; i < locations.length; i += 1) {
        if (locations[i].id === div) {
            locations.splice(i, 1);
        }
    }
}
if (movable) {
    $('#moveable').draggable({
        grid: [1, 1],
        stop: function(event, ui) {
            var tops, lefts, divid;
            tops = ui.position.top;
            lefts = ui.position.left;
            divid = this.id;
            removedouble(divid);
            locations.push({
                id: divid,
                top: tops,
                left: lefts
            });
            localStorage.setItem('positionxy', JSON.stringify(locations));
            //location.reload();
        }
    });
}
for (var a = 0; a < locations.length; a += 1) {
    $('#' + locations[a].id).css({
        'top': locations[a].top,
        'left': locations[a].left
    });
}
