
 function init ( ) {

   timeDisplay = document.createTextNode ( "" );
 }

 function calendarDate ( ) {

        var this_weekday_name_array=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

        var this_month_name_array=["Jan.","Feb.","Mar.","Apr.","May","June","July","Aug.","Sep.","Oct.","Nov.","Dec."];



        if (French == true){

        var this_weekday_name_array=["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];

       var this_month_name_array=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];

        }

        if (German == true){

        var this_weekday_name_array = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];

       var this_month_name_array=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September ","Oktober","November","Dezember"];

        }

        if (Spanish == true){

        var this_weekday_name_array = ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];

        var this_month_name_array=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Deciembre'];

        }

        if (Dutch == true){

        var this_weekday_name_array = ["zondag","maandag","dinsdag","woensdag","donderdag","vrijdag","zaterdag"];

        var this_month_name_array=['januari','februari','maart','april','mei','juni','juli','augustus','september','oktober','November','December'];

        }

        if (Italian == true){

        var this_weekday_name_array = ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"];

        var this_month_name_array=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];

        }


   var this_date_timestamp = new Date()

   var this_weekday = this_date_timestamp.getDay()
   var this_date = this_date_timestamp.getDate()
   var this_month = this_date_timestamp.getMonth()   

document.getElementById("day").firstChild.nodeValue = [this_date]  //concat long date string

document.getElementById("month").firstChild.nodeValue = this_month_name_array[this_month]  //concat long date string

document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday] //concat long date string

if ( showDay == true ){document.getElementById("day");
document.getElementById("Overlay2").style.display='true';} else { 
document.getElementById("day").style.display='none';
document.getElementById("Overlay2");}

if ( showDate == false ){document.getElementById("month").style.display='none';
document.getElementById("weekday").style.display='none';}

document.getElementById("Widget");
        if ( size == 100 ){document.getElementById("Widget").style.webkitTransform = 'scale(1.0)';}
        if ( size == 90 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.9)';
document.getElementById("Widget").style.left="-20px";}
        if ( size == 80 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.8)';
document.getElementById("Widget").style.left="-30px";}
        if ( size == 75 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.75)';
document.getElementById("Widget").style.left="-35px";}
        if ( size == 65 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.65)';
document.getElementById("Widget").style.left="-45px";}
        if ( size == 55 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.55)';
document.getElementById("Widget").style.left="-55px";}
        if ( size == 45 ){document.getElementById("Widget").style.webkitTransform = 'scale(0.45)';
document.getElementById("Widget").style.left="-65px";}
 }
 
