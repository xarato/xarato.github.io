/*
___________              __
\__    ___/____    _____|  | __  ______
  |    |  \__  \  /  ___/  |/ / /  ___/
  |    |   / __ \_\___ \|    <  \___ \
  |____|  (____  /____  >__|_ \/____  >
               \/     \/     \/     \/
** Creator: @JunesiPhone
** Website: http://junesiphone.com/
** Paypal: https://www.paypal.me/junesiphone
** Support: street.visions@yahoo.com
** Twitter: twitter.com/junesiphone
** Desc: Useable notes on the springboard. Created to be used with iWidgets.


*/



//if on iOS iWidget will pull Options.plist iOS declared in clock.js otherwise these are for testing.
if (!iOS) {
    var textColor = 'black',
        bgColor = 'red',
        hideArrow = false, //hide extend arrow
        cornerRadius = 5, //container radius
        addTime = true, //add time to note
        showAM = false, //add am to time
        addDate = false, //add date to note
        addBorder = true,
        borderColor = 'blue',
        hideWidget = true,
        hideTimer = 4000,
        iconOpacity = 0.2,
        iconImage = "&#8857;";
}

(function () {
    'use strict';
    var Tasks = {};
    Tasks = {
        //reference main container
        container : document.getElementById('container'),

        //store focused to not hide when typing
        focused : false,

        init: function () {
            var button1, button2, inputtext, expand, show, showtext;

            //items
            button1 = document.getElementById('addbutton');
            inputtext = document.getElementById('tasktext');
            showtext = document.getElementById('showText');
            expand = document.getElementById('expander');
            show = document.getElementById('show');
            button2 = document.getElementById('removebutton');

            //input handlers
            inputtext.addEventListener('blur', Tasks.createTask);
            inputtext.addEventListener('focus', Tasks.focusedSet);

            //button handlers
            button1.addEventListener('click', Tasks.createTask);
            show.addEventListener('click', Tasks.hide);
            button2.addEventListener('click', Tasks.removeTasks);
            expand.addEventListener('click', Tasks.expandList);

            //user styles
            Tasks.container.style.color = textColor;
            Tasks.container.style.backgroundColor = bgColor;
            Tasks.container.style.borderRadius = cornerRadius + 'px';

            //user wants border
            if (addBorder) {
                Tasks.container.style.border = "1px solid " + borderColor;
            }

            //set colors and opacity
            inputtext.style.borderBottomColor = textColor;
            inputtext.style.color = textColor;
            showtext.style.color = textColor;
            showtext.style.opacity = iconOpacity;

            showtext.innerHTML = iconImage + " ";

            //if user hides arrow
            if (hideArrow) {
                expand.style.color = "transparent";
            } else {
                expand.style.color = textColor;
            }

            //if user wants to hide widget
            if (hideWidget) {
                Tasks.autoHideTimer();
            }

            //load tasks
            Tasks.getAllTasks();
        },
        //parse localStorage if there is notes
        data: (JSON.parse(localStorage.getItem('data')) ? JSON.parse(localStorage.getItem('data')) : ["Tap this to delete. Tap line to add."]),
        moving: false,
        element: '',
        //change viewing window to show all notes at once.
        expandList: function () {
                var expander = document.getElementById('text');
            if (parseInt(Tasks.container.style.height, 10) === Tasks.container.scrollHeight) {
                Tasks.container.style.height = 40;
                expander.style.webkitTransform = "rotate(" + 90 + "deg)";
                expander.style.left = "15px";
            } else {
                Tasks.container.style.height = Tasks.container.scrollHeight;
                expander.style.webkitTransform = "rotate(" + 270 + "deg)";
                expander.style.left = "10px";
            }
        },
        // update the focused variable
        focusedSet: function () {
            //to know if item if focused. Changed after blur which is createTask
            Tasks.focused = true;
        },
        //hide container
        hide: function () {
            //if use is typing a note, don't hide.
            if (Tasks.focused) {
                this.autoHideTimer();
                return;
            }
            //elements effected
            var showText = document.getElementById('show'),
                expander = document.getElementById('text');
            //if container is hidden show it, otherwise show icon
            if(Tasks.container.style.display != 'none'){
                Tasks.container.style.display = "none";
                showText.style.display = "block";
            } else {
               Tasks.container.style.display = "block";
               showText.style.display = "none";
               Tasks.autoHideTimer();
               Tasks.container.style.height = 40;
                expander.style.webkitTransform = "rotate(" + 90 + "deg)";
                expander.style.left = "15px";
            }
        },
        //auto hide depending on users set time
        autoHideTimer: function () {
            if (hideWidget) {
                setTimeout(function () {
                    Tasks.hide();
                }, hideTimer);
            }
        },
        //times declared in clock.js
        getTime: function () {
            if (showAM) {
                return times.hour() + ":" + times.minute() + times.am();
            }
            return times.hour() + ":" + times.minute();
        },
        getDate: function () {
            return times.sdaytext() + " " + times.date();
        },
        // when user taps done on keyboard
        createTask: function () {
            Tasks.focused = false;
            var input = document.getElementById('tasktext');
            if (input.value !== '') {
                //is either enabled?
                if (addTime || addDate) {
                    // if both are enabled
                    if (addTime && addDate) {
                        Tasks.data.push(Tasks.getDate() + " " + Tasks.getTime() + " - " + input.value);
                    } else {
                        //if only one is enabled
                        if (addTime) {
                            Tasks.data.push(Tasks.getTime() + " - " + input.value);
                        }
                        if (addDate) {
                            Tasks.data.push(Tasks.getDate() + " - " + input.value);
                        }
                    }
                } else {
                    //if addTime and addDate are not true
                    Tasks.data.push(input.value);
                }
                input.value = '';
                //save to storage
                Tasks.saveTasks();
                //load all
                Tasks.getAllTasks();
            }
            //scroll list to top
            Tasks.container.scrollTop = 0;
        },
        //not used (testing)
        removeTasks: function () {
            localStorage.clear();
            location.reload();
        },
        //save to localstorage to persist after respring, reboot, or closing widget
        saveTasks: function () {
            localStorage.setItem('data', JSON.stringify(Tasks.data));
        },
        //used to load tasks
        getAllTasks: function () {
            var i, list, task;
            list = document.getElementById('list');
            list.innerHTML = '';
            for (i = 0; i < Tasks.data.length; i += 1) {
                task = document.createElement('li');
                task.className = 'task';
                task.setAttribute('data-id', i);
                task.innerHTML = '<div class="text"> ' + Tasks.data[i] + '</div>';
                task.children[0].addEventListener('click', Tasks.deleteTask);
                list.appendChild(task);
            }
        },
        //delete a task, event is on the element itself
        deleteTask: function (e) {
            var task, id, prmpt, prmt2;
            task = e.target.parentNode;
            //prompt for deletion incase user did not mean to tap it.
            prmpt = confirm("Are you sure you want to delete this note?" + "\n\n\"" + task.firstChild.innerHTML.replace(" ", "") + "\"");
            if (prmpt) {
                id = parseInt(task.getAttribute('data-id'), 10);
                Tasks.data.splice(id, 1);
                Tasks.saveTasks();
                Tasks.getAllTasks();
                Tasks.container.scrollTop = 0;
            } else {
                prmt2 = confirm("Do you want to add a note?");
                if (prmt2) {
                    document.getElementById('tasktext').focus();
                }
            }
        }
    };
    //initialize Tasks
    Tasks.init();
}());