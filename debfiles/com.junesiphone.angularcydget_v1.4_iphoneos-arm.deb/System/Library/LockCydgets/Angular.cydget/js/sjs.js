/*
  ________     ___   ________
 /"       )   |"  | /"       )
(:   \___/    ||  |(:   \___/
 \___  \      |:  | \___  \
  __/  \\  ___|  /   __/  \\
 /" \   :)/  :|_/ ) /" \   :)
(_______/(_______/ (_______/
Library to make writing js quicker
Website: http://JunesiPhone.com
Creator: JunesiPhone
*/
(function (window, document) {
    "use strict";
    function sJS(selector) {
        var doc = document,
            funcObj = {
                el: doc.querySelector(selector),
                sel: function () {
                    return this.el;
                },
                inner: function () {
                    return this.el.innerHTML;
                },
                set: function (inner) {
                    this.el.innerHTML = inner;
                },
                color: function (color) {
                    this.el.style.color = color;
                },
                append: function (content) {
                    this.el.innerHTML += content;
                },
                clear: function () {
                    this.el.innerHTML = null;
                }
            };
        return funcObj;
    }
    window.sJS = window.$$ = sJS;
}(window, document));
