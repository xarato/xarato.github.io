var tf = (localStorage.tf) ? JSON.parse(localStorage.tf) : false,
    pd = (localStorage.pd) ? JSON.parse(localStorage.pd) : false;

var aniPath = function(id, speed) {
    var length = id.getTotalLength();
    id.style.transition = id.style.WebkitTransition =
        'none';
    id.style.strokeDasharray = length + ' ' + length;
    id.style.strokeDashoffset = length;
    id.getBoundingClientRect();
    id.style.transition = id.style.WebkitTransition =
        'stroke-dashoffset ' + speed + 's ease-in-out';
    id.style.strokeDashoffset = '0';
};
window.onload = function() {
    var svgbase = $$("#sv").sel().getSVGDocument(),
        path, i;
    for (i = 1; i < 7; i++) {
        path = svgbase.getElementById('Path-' + i);
        aniPath(path, 2);
    }
};

$$('.time').set(clock.hour(tf, pd) + ":" + clock.minute());
$$('.day').set(clock.date());
$$('.month').set(month[clock.month()]);

$$('.time').sel().addEventListener('click', function() {
    sset.create('24hr', 'tf', 'white');
    sset.create('PadZero', 'pd', 'white');
    return false;
});

setBattery(batteryState('percent'), 1, 3, 'battery', 100);