/*jslint
  node: true,
  sloppy: true,
  browser: true
*/
/*global
  iconDrawer,
  favInfo:true,
  blacklist,
  drawer,
  appBundles,
  swiper,
  alert,
  grid,
  os,
  macDock,
  appSlider,
  Slider
*/
'use strict';

/* Add move option to array */
Array.prototype.move = function (from_index, to_index) {
    var x = this[from_index];
    this.splice(from_index, 1);
    this.splice(to_index, 0, x);
    return this;
};

var appInfo = [],
    appSlider = null;

(function (window, doc) {
    function load_appDrawer() {
        var appDrawer = {
                cache: {},
                homescreenIcons: []
            },
            isForDesktop = false,
            drawerScrolling = false,
            isChangingIcon = false,
            iconContainer = doc.getElementById('iconContainer'),
            createAppArray = function () {

            },
            //since the drawer is always backgrounded we need to update badges on show
            refreshBadges = function () {
                //loadInfo(); //I have no idea.
                var array = FPI.apps.all,
                    i,
                    bundle,
                    count,
                    badgeSpan;
                os.hasNotifications = [];
                for (i = 0; i < array.length; i += 1) {
                    count = FPI.bundle[array[i].bundle].badge;
                    bundle = array[i].bundle;
                    try {
                        if (count > 0 && doc.getElementById(bundle)) {
                            badgeSpan = doc.getElementById(bundle).children[0].children[2];
                            badgeSpan.innerHTML = count;
                        } else {
                            if (doc.getElementById(bundle)) {
                                badgeSpan = doc.getElementById(bundle).children[0].children[2];
                                badgeSpan.innerHTML = '';
                            }
                        }

                    } catch (err) {
                        os.message('error 84 appDrawer.js', err);
                    }
                }
            },
            toggleDrawer = function (state) {
                var newClass, blur; // dock;
                //firmware = iconDrawer.firmware();
                switch (state) {
                case "open":
                    newClass = "appContainer drawerVisible";
                    blur = "1";
                    //dock = "hide";
                    break;
                case "close":
                    newClass = "appContainer drawerHidden";
                    blur = "0";
                    //dock = "show";
                    break;
                }
                // if (firmware) { //if below iOS9 add fake blur
                //   doc.getElementById('fakeBlur').style.opacity = blur;
                // }
                doc.getElementById('appDrawerDiv').className = newClass;
                //doc.getElementById('dock').className = 'dock' + dock;
                if (state === 'open') {
                    appDrawer.allApps();
                    setTimeout(refreshBadges, 100); //load after everything
                    os.registerEvents(doc.getElementById('closer'), {
                        event: os.handlerType(),
                        callback: function (e) {
                            appDrawer.toggleDrawer('close');
                            os.unregisterEvents(doc.getElementById('closer'));
                            e.preventDefault();
                        }
                    });
                } else {
                    isUninstall = false;
                    os.clearDiv(iconContainer);
                }
            },
            toggleApps = function () {
                toggleDrawer('open');
                isChangingIcon = true;
            },
            toggleAppsForDesktop = function () {
                toggleDrawer('open');
                isForDesktop = true;
            },
            createItemForLauncher = function (array) {
                os.clearDiv(iconContainer);
                var app = FPI.apps.all;
                var containerLI,
                    subContainer,
                    appIcon,
                    appTitle,
                    appBadge,
                    icon,
                    badge,
                    i,
                    bundle,
                    name,
                    blob,
                    fragment = doc.createDocumentFragment(),
                    paging = 0,
                    a = document.createElement('div'),
                    pagingAmount;


                for (i = 0; i < app.length; i += 1) {

                    name = app[i].name;
                    bundle = app[i].bundle;
                    //icon = app[i].icon;
                    icon = '/var/mobile/Library/FrontPageCache/' + bundle + '.png';

                    if (!isUninstall) { // check if icon image is valid

                        paging += 1;
                        badge = app[i].badge;

                        //blob = os.toBlob(icon);

                        appIcon = os.createDOM({
                            type: 'img',
                            src: icon //URL.createObjectURL(blob)
                        });
                        containerLI = os.createDOM({
                            type: 'li',
                            attribute: ['title', bundle],
                            attribute2: ['tag', name],
                            id: bundle
                        });
                        subContainer = os.createDOM({
                            type: 'div',
                            className: 'iconHolder'
                        });
                        appTitle = os.createDOM({
                            type: 'label',
                            innerHTML: name
                        });
                        appBadge = os.createDOM({
                            type: 'span',
                            innerHTML: ((badge > 0) ? badge : ''),
                            className: 'drawerBadges'
                        });

                        subContainer.appendChild(appIcon);
                        subContainer.appendChild(appTitle);
                        subContainer.appendChild(appBadge);
                        containerLI.appendChild(subContainer);

                        //  appBundles[name.toLowerCase()] = bundle;
                        // bundleApps[bundle] = name;
                    } else {
                        if (app[i].systemApp == "yes") {
                            //alert(app[i].systemApp);
                        }
                        if (app[i].systemApp == "no") {
                            paging += 1;
                            badge = app[i].badge;

                            //blob = os.toBlob(icon);

                            appIcon = os.createDOM({
                                type: 'img',
                                src: icon //URL.createObjectURL(blob)
                            });
                            containerLI = os.createDOM({
                                type: 'li',
                                attribute: ['title', bundle],
                                attribute2: ['tag', name],
                                id: bundle
                            });
                            subContainer = os.createDOM({
                                type: 'div',
                                className: 'iconHolder'
                            });
                            appTitle = os.createDOM({
                                type: 'label',
                                innerHTML: name
                            });
                            appBadge = os.createDOM({
                                type: 'span',
                                innerHTML: ((badge > 0) ? badge : ''),
                                className: 'drawerBadges'
                            });

                            subContainer.appendChild(appIcon);
                            subContainer.appendChild(appTitle);
                            subContainer.appendChild(appBadge);
                            containerLI.appendChild(subContainer);
                        }
                    }

                    a.appendChild(containerLI);
                    if (os.ipad) { //ipad count
                        pagingAmount = 24;
                    } else {
                        pagingAmount = 20;
                    }
                    //at moment 20 icons end up in the a, save it to fragment, then reset counter
                    if (paging === pagingAmount || i === app.length - 1) {
                        paging = 0;
                        a.className = 'slider';
                        fragment.appendChild(a);
                        //iconContainer.appendChild(a);
                        a = document.createElement('div');
                    }
                }
                iconContainer.appendChild(fragment);
            },
            allApps = function () {
                createItemForLauncher(appInfo, false);
            },
            createSlider = function () {
                appSlider = new Slider('#iconContainer', '.slider', {
                    duration: 0.1,
                    autoplay: false
                });
            },
            removeAppFromDesktop = function (bundle) {
                var elem = document.getElementById(bundle + "-homescreen");
                elem.parentElement.removeChild(elem);
                var index = appDrawer.homescreenIcons.indexOf(bundle);
                if (index > -1) {
                    appDrawer.homescreenIcons.splice(index, 1);
                    localStorage.homescreenIcons = JSON.stringify(appDrawer.homescreenIcons);
                }
            },
            createDesktopApp = function (bundle) {
                appDrawer.homescreenIcons.push(bundle);
                localStorage.homescreenIcons = JSON.stringify(appDrawer.homescreenIcons);
                var view = document.getElementById('invisibleTapper'),
                    name = FPI.bundle[bundle].name,
                    icon = '/var/mobile/Library/FrontPageCache/' + bundle + '.png',
                    badge = FPI.bundle[bundle].badge,
                    appIcon, containerLI, subContainer, appTitle, appBadge;

                appIcon = os.createDOM({
                    type: 'img',
                    className: 'homescreenIcon',
                    src: icon //URL.createObjectURL(blob)
                });
                containerLI = os.createDOM({
                    type: 'li',
                    attribute: ['title', bundle],
                    attribute2: ['tag', name],
                    id: bundle + "-homescreen"
                });
                subContainer = os.createDOM({
                    type: 'div',
                    className: 'iconHolder'
                });
                appTitle = os.createDOM({
                    type: 'label',
                    innerHTML: name
                });
                appBadge = os.createDOM({
                    type: 'span',
                    innerHTML: ((badge > 0) ? badge : ''),
                    className: 'homescreenBadges',
                    id: 'hsbadge' + bundle
                });

                subContainer.appendChild(appIcon);
                subContainer.appendChild(appTitle);
                subContainer.appendChild(appBadge);
                containerLI.appendChild(subContainer);
                view.appendChild(containerLI);

            },

            initializeAppDrawer = function () {

                try {
                    createAppArray();
                    allApps();
                    createSlider();
                    //createEvents();
                } catch (err) {
                    alert(err);
                }
            };

        appDrawer.allApps = function () {
            allApps();
            createSlider();
        }

        //onload.js
        appDrawer.initializeAppDrawer = function () {
            initializeAppDrawer();
        };


        //launch.js
        appDrawer.toggleDrawer = function (state) {
            toggleDrawer(state);
        };
        appDrawer.toggleApps = function () {
            toggleApps();
        }
        appDrawer.toggleAppsForDesktop = function () {
            toggleAppsForDesktop();
        }
        appDrawer.createDesktopApp = function (bundle) {
            try {
                createDesktopApp(bundle);
            } catch (err) {
                alert(err);
            }
        }
        return appDrawer;
    }
    try {
        window.appDrawer = load_appDrawer();
    } catch (err) {
        //  alert(err);
    }
}(window, document));