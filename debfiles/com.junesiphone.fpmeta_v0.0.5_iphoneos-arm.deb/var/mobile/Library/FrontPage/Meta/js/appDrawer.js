/*jslint
  node: true,
  sloppy: true,
  browser: true
*/
/*global
os,
FPI,
Slider*/
'use strict';

var appSlider = null,
    isUninstall = false;

(function (window, doc) {
    function load_appDrawer() {
        var appDrawer = {},
            iconContainer = doc.getElementById('iconContainer'),
            pagingAmount = function () {
                var amount;
                switch (screen.width) {
                case 768:
                    amount = 24;
                    break;
                case 320:
                    amount = 12;
                    break;
                default:
                    amount = 16;
                }
                return amount;
            },
            createApplication = function (icon, bundle, name, badge) {
                var appIcon = os.createDOM({
                        type: 'img',
                        src: icon
                    }),
                    containerLI = os.createDOM({
                        type: 'li',
                        attribute: ['title', bundle],
                        attribute2: ['tag', name],
                        id: bundle
                    }),
                    subContainer = os.createDOM({
                        type: 'div',
                        className: 'iconHolder'
                    }),
                    appTitle = os.createDOM({
                        type: 'label',
                        innerHTML: name
                    }),
                    appBadge = os.createDOM({
                        type: 'span',
                        innerHTML: ((badge > 0) ? badge : ''),
                        className: 'drawerBadges'
                    });

                subContainer.appendChild(appIcon);
                subContainer.appendChild(appTitle);
                subContainer.appendChild(appBadge);
                containerLI.appendChild(subContainer);
                return containerLI;
            },
            createItemForLauncher = function () {
                if(!FPI.bundle){
                    return;
                }
                os.clearDiv(iconContainer);
                var app = FPI.apps.all,
                    containerLI,
                    icon,
                    i,
                    paging = 0,
                    fragment = doc.createDocumentFragment(),
                    a = doc.createElement('div');

                for (i = 0; i < app.length; i += 1) {

                    paging += 1;
                    icon = '/var/mobile/Library/FrontPageCache/' + app[i].bundle + '.png';

                    if (!isUninstall) {
                        containerLI = createApplication(icon, app[i].bundle, app[i].name, FPI.bundle[app[i].bundle].badge);
                    } else {
                        if (app[i].systemApp === "no") {
                            containerLI = createApplication(icon, app[i].bundle, app[i].name, FPI.bundle[app[i].bundle].badge);
                        }
                    }

                    a.appendChild(containerLI);

                    if (paging === pagingAmount() || i === app.length - 1) {
                        paging = 0;
                        a.className = 'slider';
                        fragment.appendChild(a);
                        a = doc.createElement('div');
                    }
                }
                iconContainer.appendChild(fragment);

            },
            createSlider = function () {
                appSlider = new Slider('#iconContainer', '.slider', {
                    duration: 0.2,
                    autoplay: false
                });
            },
            toggleDrawer = function (state) {
                var newClass;
                switch (state) {
                case "open":
                    newClass = "appContainer drawerVisible";
                    break;
                case "close":
                    newClass = "appContainer drawerHidden";
                    break;
                }
                doc.getElementById('appDrawerDiv').className = newClass;

                if (state === 'open') {
                    if (FPI.apps) {
                        appDrawer.loadAllApps();
                    }

                    os.registerEvents(doc.getElementById('closer'), {
                        event: os.handlerType(),
                        callback: function (e) {
                            appDrawer.toggleDrawer('close');
                            os.unregisterEvents(doc.getElementById('closer'));
                            e.preventDefault();
                        }
                    });

                } else {
                    isUninstall = false;
                    os.clearDiv(iconContainer);
                }
            };

        appDrawer.loadAllApps = function () {
            createItemForLauncher();
            createSlider();
        };

        appDrawer.toggleDrawer = function (state) {
            toggleDrawer(state);
        };

        return appDrawer;
    }
    window.appDrawer = load_appDrawer();
}(window, document));