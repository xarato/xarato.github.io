/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  iconDrawer,
  widgetContainer
*/
(function () {
    var isDragging = false;

    var swipe = {
        bgSwipe: function (direction) {
            if (direction === 'u') {
                //openCC();
            } else if (direction === 'd') {
                if (!isDragging) {
                    window.location = "frontpage:showMenu";
                }
            } else if (direction === 'l') {

            } else if (direction === 'r') {


            }
        },
        appSwipe: function (direction){
            if(direction === 'l'){
                quickApps.nextPage();
            }else if(direction === 'r'){
                quickApps.prevPage();
            }
        }
    };

    function detectswipe(el, func) {
        var data = {
                sX: 0,
                sY: 0,
                eX: 0,
                eY: 0,
                mXY: ''
            },
            min_x = 30, //min x swipe for horizontal swipe
            max_x = 50, //max x difference for vertical swipe
            min_y = 200, //min y swipe for vertical swipe
            max_y = 70, //max y difference for horizontal swipe
            direction = "",
            ele = document.querySelector(el);
        ele.addEventListener('touchstart', function (e) {
            var t = e.touches[0];
            data.sX = t.screenX;
            data.sY = t.screenY;
        }, false);
        ele.addEventListener('touchmove', function (e) {
            e.preventDefault();
            var t = e.touches[0];
            data.eX = t.screenX;
            data.eY = t.screenY;
            data.movedXY = "yes";
        }, false);
        ele.addEventListener('touchend', function () {
            if (data.movedXY === 'yes') {
                if ((((data.eX - min_x > data.sX) || (data.eX + min_x < data.sX)) && ((data.eY < data.sY + max_y) && (data.sY > data.eY - max_y)))) {
                    if (data.eX > data.sX) {
                        direction = "r";
                    } else if (data.eX < data.sX) {
                        direction = "l";
                    }
                }
                if ((((data.eY - min_y > data.sY) || (data.eY + min_y < data.sY)) && ((data.eX < data.sX + max_x) && (data.sX > data.eX - max_x)))) {
                    if (data.eY > data.sY) {
                        direction = "d";
                    } else if (data.eY < data.sY) {
                        direction = "u";
                    }
                }
            }
            if (direction !== "") {
                if (typeof func === 'function') {
                    func(direction);
                }
            }
            direction = "";
            data.movedXY = "";
        }, false);
    }
    detectswipe('#container', swipe.bgSwipe);
    detectswipe('#quickapps', swipe.appSwipe);

/* Draggable Item */
    var draggable = document.querySelector('.info');
    draggable.addEventListener('touchend', function () {
        setTimeout(function () {
            isDragging = false;
        }, 100);
    });
    draggable.addEventListener('touchmove', function (event) {
        isDragging = true;
        var touch = event.targetTouches[0];
        if (touch.pageX >= screen.width - 20) {
            return;
        }
        if (touch.pageX < 40) {
            return;
        }
        if (touch.pageY < 70) {
            return;
        }
        if (touch.pageY >= screen.height) {
            return;
        }
        if(touch.pageX < 140){
            document.querySelector('.info').style.textAlign = "left";
            localStorage.infoAlign = "left";
        }
        if(touch.pageX > 140 && touch.pageX < 220){
            document.querySelector('.info').style.textAlign = "center";
            localStorage.infoAlign = "center";
        }
        if(touch.pageX > 250){
            document.querySelector('.info').style.textAlign = "right";
            localStorage.infoAlign = "right";
        }
        //console.log(touch.pageX);
        draggable.style.left = touch.pageX - 80 + 'px';
        draggable.style.top = touch.pageY - 80 + 'px';
        localStorage.infoleft = touch.pageX - 80 + 'px';
        localStorage.infotop = touch.pageY - 80 + 'px';
        event.preventDefault();
    }, false);

    if (localStorage.infoleft) {
        document.querySelector('.info').style.left = localStorage.infoleft;
        document.querySelector('.info').style.top = localStorage.infotop;
    }
    if(localStorage.infoAlign){
        document.querySelector('.info').style.textAlign = localStorage.infoAlign;
    }
}());
