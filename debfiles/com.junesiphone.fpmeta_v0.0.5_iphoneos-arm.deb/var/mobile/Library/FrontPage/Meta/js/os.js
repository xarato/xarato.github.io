/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true
*/

/*global
  nslog,
  os,
  console,
  iconDrawer,
  appBundles,
  folderSetup,
  macDock,
  macFinder,
  notification,
  autohidedock,
  widgetContainer,
  atob,
  ArrayBuffer,
  Uint8Array,
  Blob,
  FPI,
  showpopup,
  popuptime
*/



function addStyleString(str) {
    var node = document.createElement('style');
    node.innerHTML = str;
    document.body.appendChild(node);
}


var os = {}; //object to throw methods into instead of having them global


/*
    changes a style rule directly
    os.changeCSS('.editableNow').style.backgroundColor = highColor;

 */

os.changeCSS = function (ruleName) { // Return requested style object
    ruleName = ruleName.toLowerCase(); // Convert test string to lower case.
    var styleSheet,
        i,
        ii,
        cssRules,
        cssRule = false; // Initialize cssRule.

    if (document.styleSheets) { // If browser can play with stylesheets
        for (i = 0; i < document.styleSheets.length; i += 1) { // For each stylesheet
            styleSheet = document.styleSheets[i];
            if (!styleSheet.href) {
                if (styleSheet.cssRules) { // Browser uses cssRules?
                    cssRules = styleSheet.cssRules; // Yes --Mozilla Style
                } else { // Browser usses rules?
                    cssRules = styleSheet.rules; // Yes IE style.
                } // End IE check.
                if (cssRules) {
                    for (ii = 0; ii < cssRules.length; ii += 1) {
                        cssRule = cssRules[ii];
                        if (cssRule) { // If we found a rule...
                            // console.log(cssRule);
                            if (cssRule.selectorText) {
                                //console.log(cssRule.selectorText);
                                if (cssRule.selectorText.toLowerCase() == ruleName) { //  match ruleName?
                                    return cssRule; // return the style object.
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return false; // we found NOTHING!
};

os.numberFromString = function (string) {
    return string.match(/\d/g).join("");
};

os.popup = function (message, funcYes, btnTxtYes, btnTxtNo, closeALL) {
    var systemPopup = os.createDOM({
            type: 'div',
            id: 'systemPopup'
        }),
        systemMessage = os.createDOM({
            type: 'div',
            id: 'systemMessage',
            innerHTML: message
        }),
        systemOptions = os.createDOM({
            type: 'div',
            className: 'systemOptions'
        }),
        systemYes = os.createDOM({
            type: 'div',
            id: 'systemYes',
            innerHTML: btnTxtYes,
            attribute: ['title', btnTxtYes]
        }),
        systemNo = os.createDOM({
            type: 'div',
            id: 'systemNo',
            innerHTML: btnTxtNo,
            attribute: ['title', btnTxtNo]
        });

    systemPopup.appendChild(systemMessage);
    systemOptions.appendChild(systemYes);
    systemOptions.appendChild(systemNo);
    systemPopup.appendChild(systemOptions);
    document.getElementById('iWidget').appendChild(systemPopup);

    (function () {
        var unloadEvents = function () {
                os.unregisterEvents(systemNo);
                os.unregisterEvents(systemYes);
            },
            loadEvents = function () {
                os.registerEvents(systemYes, {
                    event: os.handlerType(),
                    callback: function () {
                        funcYes();
                        if (closeALL) {
                            systemPopup.remove();
                        }
                    }
                });
                os.registerEvents(systemNo, {
                    event: os.handlerType(),
                    callback: function () {
                        unloadEvents();
                        systemPopup.remove();
                    }
                });

            };
        loadEvents();
    }());
};


os.clearStorage = function () {
    localStorage.clear();
    location.reload();
};

os.set = function (div, style, value) {
    document.getElementById(div).style[style] = value;
    return "Set " + div + " style";
};

os.hide = function (div) {
    os.set(div, 'display', 'none');
    return div + " hidden os.show() to show it.";
};
os.show = function (div) {
    os.set(div, 'display', 'block');
    return div + " is visible";
};

//toggles items className
os.toggleClassList = function (docRef, divId, className) {
    docRef.getElementById(divId).classList.toggle(className);
};

//used to include other javascript files in the javascript file
os.include = function (file) {
    var script = document.createElement('script');
    script.src = file;
    script.type = 'text/javascript';
    document.getElementsByTagName('head').item(0).appendChild(script);
};

//messaging system to put to console.log or nslog for testing
os.message = function (string, val, alert) {
    try {
        console.log("OSMessage " + string + " " + val);
        //nslog("OSMessage " + string + " " + val);
        if (alert) {
            alert("OSMessage " + string + " " + val);
        }
    } catch (ignore) {
        //ignore
    }
};

os.clearDiv = function (divID) {
    while (divID.firstChild) {
        divID.removeChild(divID.firstChild);
    }
};

os.getInner = function (div) {
    return document.getElementById(div).innerHTML;
};

os.getEl = function (el) {
    return document.getElementById(el);
};

/*
create dom elements

var mainDiv = os.createDOM({
    type: 'div',
    id: 'newDiv',
    className: 'iconHolder',
    innerHTML: 'example',
    src: 'myimage.jpg',
    attribute: ['title', bundle]
    attribute2: ['title', bundle],

});

*/

os.createDOM = function (params) {
    var d = document.createElement(params.type);
    if (params.className) {
        d.setAttribute('class', params.className);
    }
    if (params.id) {
        d.id = params.id;
    }
    if (params.innerHTML) {
        d.innerHTML = params.innerHTML;
    }
    if (params.attribute) {
        d.setAttribute(params.attribute[0], params.attribute[1]);
    }
    if (params.attribute2) {
        d.setAttribute(params.attribute2[0], params.attribute2[1]);
    }
    if (params.attribute3) {
        d.setAttribute(params.attribute3[0], params.attribute3[1]);
    }
    if (params.type === "img") {
        d.src = params.src;
    }
    if (params.appendChild) {
        d.appendChild(params.appendChild);
    }
    return d;
};

/*
  Handling events
  os.registerEvents(finderInput, {
      event: 'blur',
      callback: function () {
          closeFinder();
      }
  });
*/
os.registerEvents = function (obj, params) {
    try {
        if (typeof obj._eventListeners == 'undefined') {
            obj._eventListeners = [];
        }
        obj.addEventListener(params.event, params.callback);

        var eventListeners = obj._eventListeners;
        eventListeners.push(params);
        obj._eventListeners = eventListeners;
    } catch (ignore) {
        //  alert("os.js " + err);
    }
};

/*
  Removing Events
  os.unregisterEvents(finderInput);
*/
os.unregisterEvents = function (obj) {
    var i, e, len;
    if (typeof obj._eventListeners == 'undefined' || obj._eventListeners.length == 0) {
        return;
    }
    for (i = 0, len = obj._eventListeners.length; i < len; i += 1) {
        e = obj._eventListeners[i];
        obj.removeEventListener(e.event, e.callback);
    }
    obj._eventListeners = [];
};

//use clicks when on mobile or pc (mostly for testing)
os.handlerType = function () {
    var nav = navigator.userAgent.match(/iPhone|iPad|iPod/i);
    if (nav) {
        return 'touchstart';
    }
    return 'click';
};

os.detectDoubleTap = function () {
    if (!os.tapped) {
        os.tapped = setTimeout(function () {
            os.tapped = null;
            return false;
        }, 200);
    } else {
        clearTimeout(os.tapped); //stop single tap callback
        os.tapped = null;
        return true;
    }
};

os.showPopup = function (title, text, time) {
    var d = document;
    d.getElementById('notificationTitle').innerHTML = title;
    d.getElementById('notificationText').innerHTML = text;
    os.toggleClassList(d, 'notificationPopup', 'popupShow');

    setTimeout(function () {
        os.toggleClassList(d, 'notificationPopup', 'popupShow');
    }, time);
};

os.checkApp = function (app) {
    /* fixes for icon bundles (to open the app) */
    if (app === 'com.agilebits.onepassword') {
        app = 'com.agilebits.onepassword-ios';
    }
    if (app === 'com.groupme.iphone') {
        app = 'com.groupme.iphone-app';
    }
    return app;
};
os.checkBundle = function (bundle) {
    /* Fixes for icon images */
    if (bundle === 'com.agilebits.onepassword') {
        bundle = 'com.agilebits.onepassword-ios';
    }
    if (bundle === 'com.groupme.iphone') {
        bundle = 'com.groupme.iphone-app';
    }
    if (bundle === 'com.cn') {
        bundle = 'com.cn-rulez.Blurify';
    }
    if (bundle === 'crash') {
        bundle = 'crash-reporter';
    }
    if (bundle === 'com.filippobiga.springtomize3') {
        bundle = 'com.filippobiga.springtomize3-app';
    }
    return bundle;
};
