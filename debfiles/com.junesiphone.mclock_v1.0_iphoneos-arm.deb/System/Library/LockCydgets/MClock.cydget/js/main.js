var tf = (localStorage.tf) ? JSON.parse(localStorage.tf) : false,
    pz = true;
$$('.clock').set(clock.hour(tf, pz) + ":" + clock.minute());
$$('.day').set(clock.daytext());
$$('.date').set(clock.monthtext() + " " + clock.date() + " " + clock.year());

$$('.clock').sel().addEventListener('click', function () {
    sset.create('24hr', 'tf', 'black');
});