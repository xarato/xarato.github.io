/* Event Handlers */
'use strict';

$("#iwidget").on("touchstart", function (e) {
    if (!tapped) {
        tapped = setTimeout(function () {
            tapped = null;
            showHideElement(appList, 'none');
        }, 300);
    } else {
        clearTimeout(tapped); //stop single tap callback
        tapped = null;
        showIconAddMenu();
    }
});

document.getElementById('appPicker').addEventListener('click', function (el) {
    document.getElementById('appPicker').innerHTML = '';
    document.getElementById('appPicker').style.display = 'none';
    var name = el.target.getAttribute('name');
    createIcon(name);
});
document.getElementById('iwidget').addEventListener('touchend', function (el) {
    if (el.target.title == 'bg') {
        hideMenus();
    } else {
        if (!appMoving) {
            InfoStats.openApp(el.target.title);
        }
    }
}, false);
document.getElementById('notificationApps').addEventListener('touchstart', function (el) {
    InfoStats.openApp(el.target.title);
}, false);
document.getElementById('bottomTap').addEventListener('touchstart', function (el) {
    showTaskbar();
}, false);
document.getElementById('notifications').addEventListener('touchstart', function () {
    toggleDiv('notificationPanel', InfoStats.notifications, true);
}, false);
document.getElementById('switcher').addEventListener('touchstart', function (el) {
    InfoStats.openApp(el.target.title);
}, false);
document.getElementById('favApps').addEventListener('touchstart', function (el) {
    InfoStats.openApp(el.target.title);
}, false);
document.getElementById('bottomApps').addEventListener('touchstart', function (el) {
    whichBottomApp(el.target.title);
}, false);
document.getElementById('start').addEventListener('touchstart', function () {
    toggleDiv('menu', undefined, false);
});
document.getElementById('infoBar').addEventListener('touchstart', function (el) {
    if (el.target.title === 'carat') {
        alert('Attention user! Making this landscape is going to be ruff! Please give me time.');
    } else {
        toggleDiv('infoPanel', undefined, false);
        InfoStats.memoryPanel();
    }
});
document.getElementById('timeDate').addEventListener('touchstart', function () {
    InfoStats.openApp(appBundles['clock']);
});
