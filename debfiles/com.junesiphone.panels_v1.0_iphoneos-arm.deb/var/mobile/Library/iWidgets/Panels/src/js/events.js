/*jslint
  node: true,
  sloppy: true,
  browser: true
  */
/*global
  iconDrawer,
  media,
  appDrawer,
  appBundles,
  defaultmusicapp
*/
var eventType = function () {
    var nav = navigator.userAgent.match(/iPhone|iPad|iPod/i);
    if (nav) {
        return 'touchstart';
    }
    return 'click';
};

document.getElementById('infoSection').addEventListener(eventType(), function (el) {
    var title = el.target.title;
    if (title) {
        if (title === 'drawer') {
            appDrawer.showDrawer();
        } else {
            iconDrawer.openApp(appBundles[title]);
        }
    }
});

document.getElementById('dockSection').addEventListener(eventType(), function (el) {
    var title = el.target.title;
    if (title) {
        iconDrawer.openApp(appBundles[title]);
    }
});

document.getElementById('appHolder').addEventListener(eventType(), function (el) {
    var title = el.target.title;
    if (title) {
        iconDrawer.openApp(appBundles[title]);
    }
});

document.getElementById('controls').addEventListener(eventType(), function (el) {
    media[el.target.id]();
});

document.getElementById('song').addEventListener(eventType(), function () {
    iconDrawer.openApp(defaultmusicapp);
});
document.getElementById('artist').addEventListener(eventType(), function () {
    iconDrawer.openApp(defaultmusicapp);
});
