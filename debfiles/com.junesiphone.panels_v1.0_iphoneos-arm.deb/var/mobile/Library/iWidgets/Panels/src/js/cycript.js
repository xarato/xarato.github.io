//call IS2('currentCondition')
var IS2W = function (info) { return eval('[IS2Weather ' + info + ']');};

var IS2S = function (info) { return eval('[IS2System ' + info + ']');};
