/*jslint
  node: true,
  sloppy: true,
  browser: true
  */

/*global
  alert,
  IS2W,
  IS2S,
  IS2M,
  clock,
  twentyfour,
  translate,
  current,
  iconDrawer,
  appBundles,
  swiper,
  pink,
  centerImageBG,
  NSLog
*/

/*
        IS2 Weather Calls
        isCelsius, isWindSpeedMph, currentLocation, currentTemperature, currentCondition, currentConditionAsString,
        naturalLanguageDescription, highForCurrentDay, lowForCurrentDay, currentWindSpeed, currentWindDirection,
        currentWindChill, currentDewPoint, currentHumidity, currentVisiblityPercent, currentChanceOfRain, currentlyFeelsLike,
        currentPressure, sunsetTime, sunriseTime, currentLatitude, currentLongitude, hourlyForecastsForCurrentLocation,
        hourlyForecastsForCurrentLocationJSON, dayForecastsForCurrentLocation, dayForecastsForCurrentLocationJSON

        IS2 Media Calls

*/

/* Drawer stuff */
var appInfo = [],
    favInfo = [];
/* End Drawer stuff */

var get = function (doc, div) {
    return doc.getElementById(div);
};

function changeDivs() {
    var doc = document, //reference document to keep in scope the whole time
        mph = (IS2W('isWindSpeedMph')) ? 'mph' : 'kph';
    get(doc, 'temp').innerHTML = IS2W('currentTemperature') + '&deg;';
    get(doc, 'condition').innerHTML = IS2W('currentConditionAsString');
    get(doc, 'humidity').innerHTML = 'Humidity: ' + IS2W('currentHumidity') + '%';
    get(doc, 'wind').innerHTML = 'Wind: ' + IS2W('currentWindSpeed') + mph;
    get(doc, 'city').innerHTML = IS2W('currentLocation');
    get(doc, 'icon').src = 'src/images/icons/weather/' + IS2W('currentCondition') + '.png';
    NSLog("OPWPanels Weather Update" + ' Now Temp: ' + IS2W('currentTemperature'));
}

(function updateWeather() {
    IS2W('updateWeather'); //updating the weather
    setTimeout(changeDivs, 1000);
    setTimeout(updateWeather, 10 * 60000); //when the weather will update again
    NSLog("OPWPanels Weather Update" + ' Was Temp: ' + IS2W('currentTemperature'));
}());

(function updateBattery() {
    var doc = document,
        battery = IS2S('batteryPercent'),
        mail = iconDrawer.getNotificationCount(appBundles.mail),
        sms = iconDrawer.getNotificationCount(appBundles.messages),
        phone = iconDrawer.getNotificationCount(appBundles.phone);
    get(doc, 'batteryPercent').innerHTML = battery + "%";
    get(doc, 'batteryinsides').style.width = Math.round((battery / 100) * 18) + 'px';

    get(doc, 'mailBadge').innerHTML = (mail > 0) ? mail : '';
    get(doc, 'smsBadge').innerHTML = (sms > 0) ? sms : '';
    get(doc, 'phoneBadge').innerHTML = (phone > 0) ? phone : '';
    setTimeout(updateBattery, 3000);
    NSLog("OPWPanels Battery Update " + battery);
}());


clock({
    twentyfour: twentyfour,
    padzero: true,
    refresh: 1000,
    success: function (clock) {
        var doc = document;
        get(doc, 'time').innerHTML = clock.hour() + ':' + clock.minute();
        get(doc, 'date').innerHTML = translate[current].month[clock.month()] + ' ' + clock.date();
        get(doc, 'day').innerHTML = translate[current].weekday[clock.day()];
    }
});

var referenceScrollView;
/* Disable Paging */
function disablePaging() {
    var i,
        scrollView = iconDrawer.getScrollView(),
        scroll = false;
    for (i = 0; i < scrollView.length; i += 1) {
        if (scroll === true) {
            break;
        }
        if (scrollView[i].className == 'SBIconScrollView') {
            referenceScrollView = scrollView[i];
            iconDrawer.disablePaging();
            scroll = true;
        }
    }
}
if (!swiper) {
    disablePaging();
}

//var pink = true;
if (pink) {
    var css = ".badge{border: 1px solid #F6CCDA!important;}#batteryinsides{background-color:#F6CCDA!important;}.statusbar{background-color:#F6CCDA;} .line{background-color: #F6CCDA!important;} #ifile:before,#camera:before,#cydia:before{color:#F6CCDA!important;} #play, #next, #prev{border: 1px solid #F6CCDA!important;}";
    var style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.getElementsByTagName('head')[0].appendChild(style);
    document.getElementById('playpause').src = 'src/images/media/playPink.svg';
    document.getElementById('centerImage').style.backgroundImage = 'url("src/images/overlays/wallPink.png")';
}
