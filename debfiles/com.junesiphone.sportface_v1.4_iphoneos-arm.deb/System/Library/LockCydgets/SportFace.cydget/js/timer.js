//var $$, $, clock, weather, iOSAlarms, canceltimer, resettimer, dimlockscreen, playsound; //linter stuff
(function () {
    "use strict";
    var addmin = document.getElementById('addminute'),
        addfive = document.getElementById('addfive'),
        starttime = document.getElementById('starttime'),
        reset = document.getElementById('reset'),
        timercontrol = $$('#timercontrols').sel(),
        addto,
        resettimer,
        startTimer,
        countdown;

    addto = function (val) {
        var crnt, sp, mnt, sc;
        crnt = $$('.timer').inner();
        sp = crnt.split(':');
        mnt = Number(sp[0]) + val;
        mnt = (mnt < 10) ? "0" + mnt : mnt;
        sc = sp[1];
        $$('.timer').set(mnt + ":" + sc);
    };

    resettimer = function () {
        $$('.timer').set('00:00');
        if (window.interv) {
            window.clearInterval(interv);
        }
        dimlockscreen();
    };

    startTimer = function (duration, display) {
        var tmr = duration,
            minutes,
            seconds;
        window.interv = setInterval(function () {
            minutes = parseInt(tmr / 60, 10);
            seconds = parseInt(tmr % 60, 10);
            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;
            display.textContent = minutes + ":" + seconds;
            canceltimer();
            if (--tmr < 0) {
                resettimer();
                playsound('timer');
            }
        }, 1000);
    };

    countdown = function () {
        var cur, spl, mint, min, dsp;
        cur = $$('.timer').inner();
        spl = cur.split(':');
        mint = Number(spl[0]);
        min = 60 * mint;
        dsp = document.querySelector('.timer');
        startTimer(min, dsp);
        timercontrol.style.display = "none";
    };

    addmin.onclick = function () {
        addto(1);
    };
    addfive.onclick = function () {
        addto(5);
    };
    starttime.onclick = function () {
        countdown();
    };
    reset.onclick = function () {
        resettimer();
    };

    $$('#timerbutton').sel().addEventListener('click', function () {
        if (timercontrol.style.display === "none") {
            timercontrol.style.display = "block";
        } else {
            timercontrol.style.display = "none";
        }
    });
}());