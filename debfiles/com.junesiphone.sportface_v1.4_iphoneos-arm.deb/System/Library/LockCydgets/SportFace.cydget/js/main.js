var celsius = false;
var twentyfour = (localStorage.twentyfour) ? JSON.parse(localStorage.twentyfour) : false;
var padzero = (localStorage.padzero) ? JSON.parse(localStorage.padzero) : false;;

//var $$, $, clock, weather, iOSAlarms; //linter stuff
var tap = 0;
var showtoggles = function () {
    tap += 1;
    if(tap === 1){
    sset.create('TwentyFour','twentyfour','#b9d83d');
    sset.create('PadZero','padzero','#b9d83d');
    sset.create('Move','move','#b9d83d');
    sset.create('Face','faces','#b9d83d');
    }
    else{
        location.reload();
    }
};

if(localStorage.faces === "true"){
    $$('#wface').sel().style.display = "block";
}
else{
   $$('#wface').sel().style.display = "none";
}

//set clock time
$$('.clock').set(clock.hour(twentyfour, padzero) + ":" + clock.minute());

//set weather stuff
var splithour = function(t){
    t = String(t);
    t = t.slice(0,-2);
    return Number(t);
};
var weatherdivs = function () {
    "use strict";
    var suntime, hoursep, minsep, abr, raw;
    if (clock.hour(true,false) >= Number(splithour(weather.rawsunset()))) {
        suntime = weather.sunrise();
        raw = weather.rawsunrise();
        abr = "Sunrise: ";
    } else {
        abr = "Sunset: ";
        suntime = weather.sunset();
        raw = weather.rawsunset();
    }
    $$('.sunset').set(abr + suntime);

    hoursep =  (24 + splithour(raw) - clock.rawhour()) % 24;

    minsep = Number(suntime.split(':')[1]) - Number(clock.minute());

    if(minsep < 0){
        hoursep  = hoursep - 1;
        minsep = (60 - Number(clock.minute())) + Number(suntime.split(':')[1]);
    }
    $$('.remaining').set(hoursep + "<span class='hrs'>HRS</span>" + " " + minsep + "<span class='hrs'>MINS</span>");
    $$('.city').set(weather.city());
    if (weather.day()) {
        $$('.daynighticon').sel().src = "img/sun.svg";
    } else {
        $$('.daynighticon').sel().src = "img/moon.svg";
    }
};

//start weather
weather.start(60000 * 15);

//onload functions
(function () {
    'use strict';
    var setAlarm, alarmHour, alarmMinute, padMinute;
    //make face draggable
    //get alarms set
    setAlarm = iOSAlarms.getAlarmTimes();
    if (setAlarm !== "No Alarms") {
        alarmHour = Number(setAlarm[0].split(':')[0]);
        if(!twentyfour){
            alarmHour = (alarmHour > 12) ? alarmHour - 12 : alarmHour;
        }
        alarmMinute = Number(setAlarm[0].split(':')[1]);
        padMinute = (alarmMinute < 10) ? "0" + alarmMinute : alarmMinute;
        $$('.alarm').set(alarmHour + ":" + padMinute);
    } else {
        $$('.alarm').set('0:00');
    }
    //set face location from moved positon
}());