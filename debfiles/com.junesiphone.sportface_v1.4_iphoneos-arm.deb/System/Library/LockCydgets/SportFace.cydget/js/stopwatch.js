//var $$, $, clock, weather, iOSAlarms, canceltimer, resettimer; //linter stuff
(function () {
    "use strict";
    var startbtn = document.getElementById('start'),
        stop = document.getElementById('stop'),
        clear = document.getElementById('clear'),
        swcontrols = $$('#stopcontrols').sel(),
        seconds = 0,
        minutes = 0,
        t,
        timer,
        add;
    add = function () {
        seconds += 1;
        if (seconds >= 60) {
            seconds = 0;
            minutes += 1;
            if (minutes >= 60) {
                minutes = 0;
            }
        }
        $$('.stopwatch').set((minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds));
        timer();
        canceltimer();
    };
    timer = function () {
        t = setTimeout(add, 1000);
    };
    startbtn.onclick = function () {
        timer();
    };
    stop.onclick = function () {
        clearTimeout(t);
        resettimer();
    };
    clear.onclick = function () {
        $$('.stopwatch').set("00:00");
        seconds = 0;
        minutes = 0;
        resettimer();
    };
    $$('#stopwatchbutton').sel().addEventListener('click', function () {
        if (swcontrols.style.display === "none") {
            swcontrols.style.display = "block";
        } else {
            swcontrols.style.display = "none";
        }
    });
}());