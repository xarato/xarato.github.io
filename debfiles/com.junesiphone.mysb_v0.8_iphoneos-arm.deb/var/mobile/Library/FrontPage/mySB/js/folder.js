var folders = {
    list : document.getElementById('list'),
    folderWindow: document.getElementById('folderWindow'),
    folderOpen: false,
    addingToFolder: false,
    folderIconInfo: [],
    currentFolder: null,
    setWidth: function(width){
        sbMenu.addRule(document.styleSheets[0], ".folderWindow", "width:" + width + "%!important");
        localStorage.folderwidth = width;
    },
    setHeight: function(height){
        sbMenu.addRule(document.styleSheets[0], ".folderWindow", "height:" + height + "px!important");
        localStorage.folderheight = height;
    },
    setBorderRadius: function(radius){
        sbMenu.addRule(document.styleSheets[0], ".folderWindow", "border-radius:" + radius + "px!important");
        localStorage.folderradius = radius;
    },
    setBGColor: function(color){
        sbMenu.addRule(document.styleSheets[0], ".folderBG", "background-color:" + color + "!important");
        localStorage.foldercolor = color;
    },
    setXAxis: function(value){
        sbMenu.addRule(document.styleSheets[0], ".folderWindow", "left:" + value + "px!important");
        localStorage.folderxaxis = value;
    },
    setYAxis: function(value){
        sbMenu.addRule(document.styleSheets[0], ".folderWindow", "top:" + value + "px!important");
        localStorage.folderyaxis = value;
    },
    createFolder : function(){
        var name = prompt("Enter folder name", "");
        sb.setIcon('folder' + name);
    },
    clearOptions: function(){

        localStorage.folderwidth = null;
        localStorage.folderheight = null;
        localStorage.folderradius = null;
        localStorage.foldercolor = null;

        sbMenu.removeRule(document.styleSheets[0], ".folderWindow", "width");
        sbMenu.removeRule(document.styleSheets[0], ".folderWindow", "height");
        sbMenu.removeRule(document.styleSheets[0], ".folderWindow", "border");
        sbMenu.removeRule(document.styleSheets[0], ".folderBG", "background-color");

        document.getElementById('folderWidthInput').value = "";
        document.getElementById('folderHeightInput').value = "";
        document.getElementById('folderBorderRadiusInput').value = "";
        document.getElementById('folderColorInput').value = "";

        jPopup({
            type: "alert",
            message: "Folder options reset to default.",
            okButtonText: "OK"
        });
        sbMenu.toggleSubMenu(document.getElementById('folderOptionsMenu'));
    },
    animateWindow: function(position, element){

        //element.style.transition = 'opacity 1s ease-in-out';
        

        if(position === 'in'){
            element.style.opacity = 0;
            element.style.webkitTransform = "scale(1.0)";
            element.style.opacity = 1;
            element.style.pointerEvents = 'auto';
        }else{
            element.style.webkitTransform = "scale(0)";
            element.style.opacity = 0;
            element.style.pointerEvents = 'none';
        }
    },
    createFolderWindow: function(bundle){
        //this.folderWindow.style.display = 'block';
        this.animateWindow('in', this.folderWindow);
        this.folderOpen = true;
    },
    closeFolderWindow: function(){
        if(this.folderOpen){
            this.animateWindow('out', this.folderWindow);
            //this.folderWindow.style.display = 'none';
            this.folderOpen = false;
            folders.currentFolder = null;
        }
    },
    loadIcons: function(bundle){
        document.getElementById('folderIconHolder').innerHTML = "";
        for (i = 0; i < folders.folderIconInfo.length; i += 1) {
            if(folders.folderIconInfo[i].folder === bundle){
                //console.log(folders.folderIconInfo[i]);
                folders.addIcon(folders.folderIconInfo[i].bundle, true);
            }
        }
    },
    openFolder: function(bundle){
        setTimeout(function(){
            folders.createFolderWindow(bundle);
            folders.currentFolder = bundle;
            folders.loadIcons(bundle);
        },100);  
    },
    saveInfo: function(name, info){
        localStorage.setItem(name, JSON.stringify(info));
    },
    addIcon: function(bundle, auto){
        //alert('addIcon' + bundle);
        var icon = document.createElement('li'),
            div = document.createElement('div'),
            label = document.createElement('div'),
            image = document.createElement('div'),
            badge = document.createElement('div'),
            childId = document.getElementById('list').children.length,
            imageLoc,
            container,
            leftM,
            name;
        icon.className = 'iconViewFolder';
        icon.id = bundle;
        //leftM = new WebKitCSSMatrix(document.getElementById('container').style.webkitTransform);
        //icon.style.left = Math.abs(parseInt(leftM.m41, 10)) + "px";

       if(bundle == "com.junesiphone.drawer"){
            badge.innerHTML = "";
        }else if (FPI.bundle[bundle]) {
            if(FPI.bundle[bundle].badge > 0){
                badge.innerHTML = FPI.bundle[bundle].badge;
            }else{
                badge.innerHTML = "";
            }
        }else{
            badge.innerHTML = "";
        }

        name = FPI.bundle[bundle].name;

        icon.setAttribute('data-id', "icon_" + Number(childId) + 1);
        //icon.style.top = "100px";
        div.className = "iconHolder";
        image.className = "iconImageViewFolder";
        label.className = "iconImageLabel folderLabel";
        badge.className = "iconImageBadge";
        label.innerHTML = name;

        imageLoc = 'url("/var/mobile/Library/FrontPageCache/' + bundle + '.png")';

        if(sb.changedIcons[bundle]){
            imageLoc = sb.changedIcons[bundle].url;
        }

        image.style.backgroundImage = imageLoc;

        div.appendChild(image);
        div.appendChild(label);
        div.appendChild(badge);
        icon.appendChild(div);
        document.getElementById('folderIconHolder').appendChild(icon);
        //sb.makeDraggable(icon);
        if(!auto){
            folders.folderIconInfo.push({folder:folders.currentFolder, id: icon.id, bundle: bundle, name: name, iconImage: 'url("/var/mobile/Library/FrontPageCache/' + bundle + '.png")'});
        
            FPI.drawer.toggleDrawer();
            folders.addingToFolder = false;

            folders.saveInfo('sbfolderIconInfo', folders.folderIconInfo);
        }
    },
    removeFromFolder: function(parentEl, bundle){
        for (var i = 0; i < parentEl.children.length; i++) {
           if(parentEl.children[i].id === bundle){
                parentEl.removeChild(parentEl.children[i]);
           }
        }
        for (var e = 0; e < folders.folderIconInfo.length; e++){
            console.log(folders.folderIconInfo[e]);
            if(folders.folderIconInfo[e].bundle === bundle){
                folders.folderIconInfo.splice(e, 1);
            }
        }
        folders.saveInfo('sbfolderIconInfo', folders.folderIconInfo);
    },
    loadUserOptions: function(){
        if(localStorage.folderwidth){
            this.setWidth(localStorage.folderwidth);
        }
        if(localStorage.folderheight){
            this.setHeight(localStorage.folderheight);
        }
        if(localStorage.foldercolor){
            this.setBGColor(localStorage.foldercolor);
        }
        if(localStorage.folderradius){
            this.setBorderRadius(localStorage.folderradius);
        }
        if(localStorage.folderyaxis){
            this.setYAxis(localStorage.folderyaxis);
        }
        if(localStorage.folderxaxis){
            this.setXAxis(localStorage.folderxaxis);
        }
    },
    initFolder: function(){
        document.getElementById('folderAdd').addEventListener('touchend', function(){
            folders.addingToFolder = true;
            FPI.drawer.toggleDrawer();
        });

        var removingIcon = null,
            folderIconHolder = document.getElementById('folderIconHolder'),
            touchTimer = null;

        //Open app
        document.getElementById('folderIconHolder').addEventListener('click', function(el){
            if(el.target.parentElement.parentElement.id){
                if(!removingIcon){
                    folders.closeFolderWindow();
                    window.location = 'frontpage:openApp:' + el.target.parentElement.parentElement.id;
                }
            }
        });

        //removeIcon
        folderIconHolder.addEventListener('touchend', function (el){
          clearTimeout(touchTimer);
        });

        folderIconHolder.addEventListener('touchstart', function (el){
          touchTimer = setTimeout(function(){
                removingIcon = true;
                jPopup({
                  type: "confirm",
                  message: "Are you sure you want to remove this icon?",
                  yesButtonText: "Yes",
                  noButtonText: "No",
                  functionOnOk: function(){
                    folders.removeFromFolder(folderIconHolder, el.target.parentElement.parentElement.id);
                    removingIcon = false;
                  },
                  functionOnNo: function(){
                    removingIcon = false;
                  }
                });
            }, 200);
        });
        folderIconHolder.addEventListener('touchmove', function (el){
            clearTimeout(touchTimer);
        });

        //load array stating icons in folders
        if(localStorage.sbfolderIconInfo != 'null' && localStorage.sbfolderIconInfo != undefined){
            folders.folderIconInfo = JSON.parse(localStorage.sbfolderIconInfo);
        }

        folders.loadUserOptions();
    }   
};

folders.initFolder();