var iconpositions = {
	showGrid : false,
	getPositionCenter: function (element) {
        var data = element.getBoundingClientRect();
        return {
            x: data.left + data.width / 2,
            y: data.top + data.height / 2
        };
    },
    getDistanceBetweenElements: function(a, b) {
        var aPosition = this.getPositionCenter(a);
        var bPosition = this.getPositionCenter(b);
        return {
        	x: aPosition.x - bPosition.x,
        	y: aPosition.y - bPosition.y,
        	aposx: aPosition.x,
        	aposy: aPosition.y,
        	bposx: bPosition.x,
        	bposy: bPosition.y
        };
    },
	updateStorage: function(left, app){
		scaleVal = sb.getInfoFromStorage(sb.changingIcon, 'scale', '1.0');
        sb.removeDoubleLocation(sb.changingIcon);
        sb.locations.push({
            id: sb.changingIcon, 
            top: app.style.top.replace('px', ''), 
            left: left.replace('px', ''),
            opacity: app.style.opacity,
            scale: scaleVal
        });
        sb.saveInfo('sbpositions', sb.locations); 
	},
	centerIcon: function(){
		var icon = document.getElementById(sb.changingIcon),
			screenW = (currentPage > 0) ? screen.width * ((currentPage + 1) + currentPage) : screen.width,
			center = screenW/2 - icon.offsetWidth / 2 + "px";
		icon.style.left = center;
		this.updateStorage(center, icon);
	},
	resetLocation: function(divID){
		Object.keys(sb.locations).forEach(function(key) {
			if(sb.locations[key].id == divID){
				sb.locations[key].top = 40;
				sb.locations[key].left = 40;
			}
		});
		sb.saveInfo('sbpositions', sb.locations);
		document.getElementById(divID).style.left = "40px";
		document.getElementById(divID).style.top = "40px";
		document.getElementById('resetIconPositions').style.display = "none";
		document.getElementById('iconOptionsMenu').style.display = "none";
	},
	closeReset: function(){
		document.getElementById('resetIconPositions').style.display = "none";
		document.getElementById('iconOptionsMenu').style.display = "none";
	},
	resetIconPosition: function(){
		var holder = document.getElementById('resetIconPositions');
			holder.style.display = "block";
			holder.innerHTML = "<li class='resetIconLI' onclick='iconpositions.closeReset()'>Close Menu</li>";
			Object.keys(sb.locations).forEach(function(key) {
			  var div = document.createElement('li');
			  	  div.style.width = "100%";
			  	  div.className = "resetIconLI";
			  	  div.title =  sb.locations[key].id;
			  	  div.onclick = function(){
			  	  	iconpositions.resetLocation(this.title);
			  	  };
			  	  div.innerHTML = sb.locations[key].id + " X:" + sb.locations[key].left + " Y:" + sb.locations[key].top;
			  	  holder.appendChild(div);
			});
	},
	spacingGrid: function(codeCalled){
		var list = document.getElementById('list'),
			gridHolder = document.getElementById('customGrid'),
			listIcons = list.children;
			gridHolder.innerHTML = "";
			if(!codeCalled){
				if(this.showGrid){
					this.showGrid = false;
					return;
				}
				this.showGrid = true;
			}
			for (var i = 0; i < list.children.length; i++) {
				if(list.children[i].classList.contains('iconView')){ //only icons not widgets
					var div = document.createElement('div');
						div.style.position = "absolute";
						div.style.left = list.children[i].style.left;
						div.style.top = list.children[i].style.top;
						div.style.marginTop = "-20px";
						div.style.padding = "2px";
						div.style.paddingLeft = "4px";
						div.style.paddingRight = "4px";
						div.style.borderRadius = "99px";
						div.style.backgroundColor = 'black';
						div.style.fontSize = "10px";
						div.innerHTML = "Y:" + list.children[i].style.top.replace('px','') + " X:" + list.children[i].style.left.replace('px',''); 
						div.style.whiteSpace = 'nowrap'; 
						gridHolder.appendChild(div);
				}


				//space between icons left/right
				var leftVal = null;
				var centerVal = null;
				var topVal = null;
				var centerTopVal = null;
				for (var e = 0; e < list.children.length; e++) {
					if(list.children[e].classList.contains('iconView')){
						var L1 = parseInt(list.children[i].style.left, 10);
						var L2 = parseInt(list.children[e].style.left, 10);
						var T1 = parseInt(list.children[i].style.top, 10);
						var T2 = parseInt(list.children[e].style.top, 10);
						if(L2 > L1){
							if(!leftVal && T1 == T2){
								leftVal = L2;
								centerVal = L2 - L1;
							}else{
								if(L2 < leftVal && T1 == T2){
									leftVal = L2;
									centerVal = L2 - L1;
								}
							}
						}
					}
				}

				//space between icons top/bottom
				for (var f = 0; f < list.children.length; f++) {
					if(list.children[f].classList.contains('iconView')){
						var Le1 = parseInt(list.children[i].style.left, 10);
						var Le2 = parseInt(list.children[f].style.left, 10);
						var Te1 = parseInt(list.children[i].style.top, 10);
						var Te2 = parseInt(list.children[f].style.top, 10);
						if(Te2 > Te1){
							if(!topVal && Le1 == Le2){
								topVal = Te2;
								centerTopVal = Te2 - Te1;
							}else{
								if(Te2 < topVal && Le1 == Le2){
									topVal = Te2;
									centerTopVal = Te2 - Te1;
								}
							}
						}
					}
				}
				//center of x axis
				if(centerVal){
					var centerDiv = document.createElement('div');
						centerDiv.style.position = "absolute";
						centerDiv.className = 'spacingNumber';
						centerDiv.style.left = list.children[i].style.left;
						centerDiv.style.top = list.children[i].style.top;
						centerDiv.style.marginTop = "20px";
						centerDiv.style.marginLeft = 50 + "px";
						centerDiv.style.borderRadius = "2px";
						centerDiv.style.backgroundColor = 'red';
						centerDiv.style.fontSize = "10px";
						centerDiv.style.padding = "2px";
						centerDiv.style.paddingLeft = "4px";
						centerDiv.style.paddingRight = "4px";
						centerDiv.innerHTML = centerVal;
						gridHolder.appendChild(centerDiv);
				}
				//center of y axis
				if(centerTopVal){
					var centerDiv2 = document.createElement('div');
						centerDiv2.style.position = "absolute";
						centerDiv2.className = 'spacingNumber';
						centerDiv2.style.left = list.children[i].style.left;
						centerDiv2.style.top = list.children[i].style.top;
						centerDiv2.style.marginTop = 50 + "px";
						centerDiv2.style.marginLeft = "20px";
						centerDiv2.style.borderRadius = "2px";
						centerDiv2.style.backgroundColor = 'red';
						centerDiv2.style.fontSize = "10px";
						// centerDiv2.style.padding = "2px";
						centerDiv2.style.paddingLeft = "4px";
						centerDiv2.style.paddingRight = "4px";
						centerDiv2.innerHTML = centerTopVal;
						gridHolder.appendChild(centerDiv2);
				}
			}
	},
};





