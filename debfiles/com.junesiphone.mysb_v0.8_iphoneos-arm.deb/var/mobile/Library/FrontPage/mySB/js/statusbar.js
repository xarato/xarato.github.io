
(function(doc){
	var statusbar = {
		wifi: doc.getElementById('wifiHolder'),
		signal: doc.getElementById('signalHolder'),
		battery: doc.getElementById('batteryHolder'),
		wifiButton: doc.getElementById('showWifi'),
		signalButton: doc.getElementById('showSignal'),
		batteryButton: doc.getElementById('showBattery'),
		savePosition: function(ev, ui, elID){
			var tops = ui.position.top,
                lefts = ui.position.left,
                divid = elID;
            sb.removeDoubleLocation(divid);
            sb.locations.push({id: divid, top: tops, left: lefts});
            sb.saveInfo('sbpositions', sb.locations);
		},
		init: function(){
			$(this.wifi).draggable({
				cursorAt: { top: 20, left: 20 },
				stop: function (ev, ui) {
	                Statusbar.savePosition(ev, ui, this.id);
            	}
			});
			$(this.signal).draggable({
				cursorAt: { top: 20, left: 20 },
				stop: function (ev, ui) {
	                Statusbar.savePosition(ev, ui, this.id);
            	}
			});
			$(this.battery).draggable({
				cursorAt: { top: 20, left: 20 },
				stop: function (ev, ui) {
	                Statusbar.savePosition(ev, ui, this.id);
            	}
			});

			if (localStorage.sbshowwifi) {
				this.wifiButton.innerHTML = "Hide Wifi";
				this.wifi.style.display = "block";
            } else {
                this.wifiButton.innerHTML = "Show Wifi";
				this.wifi.style.display = "none";
            }
            if (localStorage.sbshowsignal) {
				this.signalButton.innerHTML = "Hide Signal";
				this.signal.style.display = "block";
            } else {
                this.signalButton.innerHTML = "Show Signal";
				this.signal.style.display = "none";
            }
            if (localStorage.sbshowbattery) {
				this.batteryButton.innerHTML = "Hide Battery";
				this.battery.style.display = "block";
            } else {
                this.batteryButton.innerHTML = "Show Battery";
				this.battery.style.display = "none";
            }
            if(localStorage.sbwificolor){
            	sbMenu.addRule(document.styleSheets[0], ".wifibg, .wifibg:before", "border-top-color:" + localStorage.sbwificolor + "!important;");
            }
            if(localStorage.sbsignalcolor){
            	sbMenu.addRule(document.styleSheets[0], ".sBar", "background-color:" + localStorage.sbsignalcolor + "!important;");
            }
            if(localStorage.sbbatterycolor){
            	sbMenu.addRule(document.styleSheets[0], "#battery", "border:1px solid " + localStorage.sbbatterycolor + "!important;");
				sbMenu.addRule(document.styleSheets[0], "#battery:after", "background-color:" + localStorage.sbbatterycolor + "!important;");
				sbMenu.addRule(document.styleSheets[0], "#batteryinsides", "background-color:" + localStorage.sbbatterycolor + "!important;");
            }
		},
		setWifiColor: function(value){
			localStorage.sbwificolor = value;
			sbMenu.addRule(document.styleSheets[0], ".wifibg, .wifibg:before", "border-top-color:" + value + "!important;");
		},
		setSignalColor: function(value){
			localStorage.sbsignalcolor = value;
			sbMenu.addRule(document.styleSheets[0], ".sBar", "background-color:" + value + "!important;");
		},
		setBatteryColor: function(value){
			localStorage.sbbatterycolor = value;
			sbMenu.addRule(document.styleSheets[0], "#battery", "border:1px solid " + value + "!important;");
			sbMenu.addRule(document.styleSheets[0], "#battery:after", "background-color:" + value + "!important;");
			sbMenu.addRule(document.styleSheets[0], "#batteryinsides", "background-color:" + value + "!important;");
		},
		setWifiSize: function (value){
			localStorage.sbwifisize = value;
			sbMenu.addRule(document.styleSheets[0], "#wifiHolder", "-webkit-transform:scale(" + value + ")!important;");
		},
		setBatterySize: function (value){
			localStorage.sbbatterysize = value;
			sbMenu.addRule(document.styleSheets[0], "#batteryHolder", "-webkit-transform:scale(" + value + ")!important;");
		},
		setSignalSize: function (value){
			localStorage.sbsignalsize = value;
			sbMenu.addRule(document.styleSheets[0], "#signalHolder", "-webkit-transform:scale(" + value + ")!important;");
		},
		showWifi: function(){
			var label, display;
            if (localStorage.sbshowwifi) {
                label = "Show Wifi";
                display = "none";
                localStorage.removeItem('sbshowwifi');
            } else {
                label = "Hide Wifi";
                display = "block";
                localStorage.sbshowwifi = "YES";
            }
            this.wifiButton.innerHTML = label;
            this.wifi.style.display = display;
		},
		showSignal: function(){
			var label, display;
            if (localStorage.sbshowsignal) {
                label = "Show Signal";
                display = "none";
                localStorage.removeItem('sbshowsignal');
            } else {
                label = "Hide Signal";
                display = "block";
                localStorage.sbshowsignal = "YES";
            }
            this.signalButton.innerHTML = label;
            this.signal.style.display = display;
		},
		showBattery: function(){
			var label, display;
            if (localStorage.sbshowbattery) {
                label = "Show Battery";
                display = "none";
                localStorage.removeItem('sbshowbattery');
            } else {
                label = "Hide Battery";
                display = "block";
                localStorage.sbshowbattery = "YES";
            }
            this.batteryButton.innerHTML = label;
            this.battery.style.display = display;
		},
		reload: function(){
			var statusPositions,
				loop,
				wifiPositionT = null,
				wifiPositionL = null,
				signalPositionT = null,
				signalPositionL = null,
				batteryPositionT = null,
				batteryPositionL = null;

			if(localStorage.sbpositions){
				statusPositions = JSON.parse(localStorage.sbpositions);

				for (loop = 0; loop < statusPositions.length; loop++) {
					if(statusPositions[loop].id === "wifiHolder"){
						wifiPositionT = statusPositions[loop].top;
						wifiPositionL = statusPositions[loop].left;
					}
					if(statusPositions[loop].id === "signalHolder"){
						signalPositionL = statusPositions[loop].left;
						signalPositionT = statusPositions[loop].top;
					}
					if(statusPositions[loop].id === "batteryHolder"){
						batteryPositionL = statusPositions[loop].left;
						batteryPositionT = statusPositions[loop].top;
					}
				}
			}

			if(wifiPositionT){
				this.wifi.style.top = wifiPositionT + "px";
			}else{
				this.wifi.style.top = "102px";
			}

			if(wifiPositionL){
				this.wifi.style.left = wifiPositionL + "px";
			}else{
				this.wifi.style.left = "80px";
			}

			if(signalPositionL){
				this.signal.style.left = signalPositionL + "px";
			}else{
				this.signal.style.left = "60px";
			}

			if(signalPositionT){
				this.signal.style.top = signalPositionT + "px";
			}else{
				this.signal.style.top = "104px";
			}

			if(batteryPositionT){
				this.battery.style.top = batteryPositionT + "px";
			}else{
				this.battery.style.top = "101px";
			}

			if(batteryPositionL){
				this.battery.style.left = batteryPositionL + "px";
			}else{
				this.battery.style.left = "108px";
			}
			

			if (localStorage.sbshowwifi) {
				this.wifi.style.display = "block";
				this.wifiButton.innerHTML = "Hide Wifi";
			}else{
				this.wifi.style.display = "none";
				this.wifiButton.innerHTML = "Show Wifi";
			}
			if(localStorage.sbshowsignal){
				this.signal.style.display = "block";
				this.signalButton.innerHTML = "Hide Signal";
			}else{
				this.signal.style.display = "none";
				this.signalButton.innerHTML = "Show Signal";
			}
			if(localStorage.sbshowbattery){
				this.battery.style.display = "block";
				this.batteryButton.innerHTML = "Hide Battery";
			}else{
				this.battery.style.display = "none";
				this.batteryButton.innerHTML = "Show Battery";
			}

			if(localStorage.sbwificolor){
				sbMenu.addRule(document.styleSheets[0], ".wifibg, .wifibg:before", "border-top-color:" + localStorage.sbwificolor + "!important;");
			}else{
				sbMenu.removeRule(document.styleSheets[0], ".wifibg, .wifibg::before", "border-top-color");
			}

			if(localStorage.sbsignalcolor){
				sbMenu.addRule(document.styleSheets[0], ".sBar", "background-color:" + localStorage.sbsignalcolor + "!important;");
			}else{
				sbMenu.removeRule(document.styleSheets[0], ".sBar", "background-color");
			}

			if(localStorage.sbbatterycolor){
				sbMenu.addRule(document.styleSheets[0], "#battery", "border: 1px solid " + localStorage.sbbatterycolor + "!important;");
				sbMenu.addRule(document.styleSheets[0], "#battery:after", "background-color:" + localStorage.sbbatterycolor + "!important;");
				sbMenu.addRule(document.styleSheets[0], "#batteryinsides", "background-color:" + localStorage.sbbatterycolor + "!important;");
			}else{
				sbMenu.removeRule(document.styleSheets[0], "#battery", "border");
				sbMenu.removeRule(document.styleSheets[0], "#battery::after", "background-color");
				sbMenu.removeRule(document.styleSheets[0], "#batteryinsides", "background-color");
			}

			if(localStorage.sbwifisize){
				sbMenu.addRule(document.styleSheets[0], "#wifiHolder", "-webkit-transform:scale(" + localStorage.sbwifisize + ")!important;");
			}else{
				sbMenu.removeRule(document.styleSheets[0], "#wifiHolder", "transform");
			}

			if(localStorage.sbbatterysize){
				sbMenu.addRule(document.styleSheets[0], "#batteryHolder", "-webkit-transform:scale(" + localStorage.sbbatterysize + ")!important;");
			}else{
				sbMenu.removeRule(document.styleSheets[0], "#batteryHolder", "transform");
			}

			if(localStorage.sbsignalsize){
				sbMenu.addRule(document.styleSheets[0], "#signalHolder", "-webkit-transform:scale(" + localStorage.sbsignalsize + ")!important;");
			}else{
				sbMenu.removeRule(document.styleSheets[0], "#signalHolder", "transform");
			}

			try{
				loadStatusBar();
				loadBattery();
			}catch(err){

			}
		
		}
	}
	window.Statusbar = statusbar;
}(document));
