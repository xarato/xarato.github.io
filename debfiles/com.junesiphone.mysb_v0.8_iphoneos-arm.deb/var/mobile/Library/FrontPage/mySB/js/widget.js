var widgets = {
    widgetArray: [],
    locations: [],
    dragging: false,
    holder: 0,
    editingWidget: "",
    removeDoubleLocation: function (div) {
        var i;
        for (i = 0; i < widgets.locations.length; i += 1) {
            if (widgets.locations[i].id === div) {
                widgets.locations.splice(i, 1);
            }
        }
    },
    removeWidgetFromSB: function (widget) {
        var i,
            elem,
            script,
            index;

        for (i = 0; i < widgets.locations.length; i += 1) {
            if (widgets.locations[i].id === widget) {
                widgets.locations.splice(i, 1);
            }
        }

        script = document.querySelectorAll('[title = ' + widget + ']');
        if (script) {
            script[0].parentNode.removeChild(script[0]);
        }

        setTimeout(function () {
            index = widgets.widgetArray.indexOf(widget);
            if (index > -1) {
                widgets.widgetArray.splice(index, 1);
            }
            elem = document.getElementById(widget);
            elem.parentNode.removeChild(elem);
            widgets.saveInfo('widgetspositions', widgets.locations);
        }, 0);

    },
    getInfoFromStorage: function (app, value, def) {
        var de;
        for (de = 0; de < widgets.locations.length; de += 1) {
            if (widgets.locations[de].id == app) {
                if (widgets.locations[de][value]) {
                    return widgets.locations[de][value];
                }
            }
        }
        return def;
    },
    saveInfo: function (name, info) {
        localStorage.setItem(name, JSON.stringify(info));
    },
    scaleWidget: function (value) {
        var app = document.getElementById(widgets.editingWidget),
            colorVal = widgets.getInfoFromStorage(widgets.editingWidget, 'color', 'white');
        app.style.webkitTransform = "scale(" + value + ")";
        widgets.removeDoubleLocation(widgets.editingWidget);
        widgets.locations.push({
            id: widgets.editingWidget,
            top: app.style.top.replace('px', ''),
            left: app.style.left.replace('px', ''),
            scale: value,
            color: colorVal,
            widget: 'yes'
        });
        widgets.saveInfo('widgetspositions', widgets.locations);
    },
    colorWidget: function (value) {
        var app = document.getElementById(widgets.editingWidget),
            scaleVal = widgets.getInfoFromStorage(widgets.editingWidget, 'scale', '1.0');
        app.style.color = value;
        widgets.removeDoubleLocation(widgets.editingWidget);
        widgets.locations.push({
            id: widgets.editingWidget,
            top: app.style.top.replace('px', ''),
            left: app.style.left.replace('px', ''),
            scale: scaleVal,
            color: value,
            widget: 'yes'
        });
        widgets.saveInfo('widgetspositions', widgets.locations);
    },
    showWidgetMenu: function () {
        try {
            var script = document.querySelectorAll('[title = widgetlist]');
            if (script) {
                script[0].parentNode.removeChild(script[0]);
            }
        } catch (err) {
            //didn't exist
            //console.log('createWidgetList' + err);
        }
        this.loadJSFile('http://lockplus.us/mySB/widgets/resources/widget.js', widgets.createWidgetList, 'widgetlist');
        document.getElementById('widgets').style.display = 'block';
    },
    closeWidget: function () {
        document.getElementById('widgets').style.display = 'none';
        document.getElementById('widgetPreviews').innerHTML = "";
        try {
            var script = document.querySelectorAll('[title = widgetlist]');
            if (script) {
                script[0].parentNode.removeChild(script[0]);
            }
        } catch (err) {
            //didn't exist
            //console.log('createWidgetList' + err);
        }
    },
    createWidgetList: function () {
        var divimg, imgs, i;
        for (i = 0; i < widgetArray.length; i++) {
            divimg = document.createElement('li');
            divimg.className = 'divimg';
            imgs = document.createElement('img');
            imgs.src = 'http://lockplus.us/mySB/widgets/images/' + widgetArray[i] + '.jpg';
            imgs.title = widgetArray[i];
            divimg.title = widgetArray[i];
            divimg.appendChild(imgs);
            document.getElementById('widgetPreviews').appendChild(divimg);
        };
    },
    showWidgetEditMenu: function () {
        //widgets.removeWidgetFromSB(el.target.id);
        document.getElementById('widgetEditMenu').style.display = 'block';
    },
    widgetLoaded: function () {
        try {
            for (var i = 0; i < widgets.widgetArray.length; i++) {
                if (document.getElementById(widgets.widgetArray[i]).getAttribute('data') == "eventAdded") {
                    //console.log('event already added');
                } else {
                    $('#' + widgets.widgetArray[i]).draggable({
                        cancel: ".canceledIcons",
                        //disabled: locked,
                        stop: function (ev, ui) {
                            setTimeout(function () {
                                widgets.dragging = false;
                            }, 1000);
                            var tops = ui.position.top,
                                lefts = ui.position.left,
                                divid = this.id,
                                scaleVal = widgets.getInfoFromStorage(divid, 'scale', '1.0'),
                                colorVal = widgets.getInfoFromStorage(divid, 'color', 'white');

                            widgets.removeDoubleLocation(divid);
                            widgets.locations.push({
                                id: divid,
                                top: tops,
                                left: lefts,
                                scale: scaleVal,
                                color: colorVal,
                                widget: 'yes'
                            });
                            widgets.saveInfo('widgetspositions', widgets.locations);
                            try {
                                document.getElementById(this.id).classList.remove("iconViewDragging");
                                document.getElementById(this.id).classList.remove("iconViewDraggingVert");
                            } catch (err) {}
                        },
                        drag: function (ev, ui) {
                            ui.position.left = Math.round(ui.position.left);
                            ui.position.top = Math.round(ui.position.top);
                            try {
                                document.getElementById(this.id).classList.add("iconViewDragging");
                                document.getElementById(this.id).classList.add("iconViewDraggingVert");
                            } catch (err) {}

                            widgets.dragging = true;
                            // console.log(ui.position.top);
                        }
                    });
                    document.getElementById(widgets.widgetArray[i]).addEventListener('touchstart', function (el) {
                        touchTimer = setTimeout(function () {
                            if (!widgets.dragging) {
                                widgets.dragging = true;
                                widgets.editingWidget = el.target.id;
                                widgets.showWidgetEditMenu();
                                setTimeout(function () {
                                    widgets.dragging = false;
                                }, 300);
                            }
                        }, 800);
                    });
                    document.getElementById(widgets.widgetArray[i]).addEventListener('touchend', function () {
                        clearTimeout(touchTimer);
                    });
                    document.getElementById(widgets.widgetArray[i]).addEventListener('touchcancel', function () {
                        clearTimeout(touchTimer);
                    });
                    document.getElementById(widgets.widgetArray[i]).setAttribute('data', 'eventAdded');
                }

                // if items are locked
                if (localStorage.sblock) {
                    document.getElementById(widgets.widgetArray[i]).classList.add('canceledIcons');
                    document.getElementById(widgets.widgetArray[i]).style.pointerEvents = "none";
                } else {
                    document.getElementById(widgets.widgetArray[i]).classList.remove('canceledIcons');
                    document.getElementById(widgets.widgetArray[i]).style.pointerEvents = "initial";
                }
                if (localStorage.widgetBG) {
                    widgets.moveWidget('statusbarItems');
                    document.getElementById('widgetBG').innerHTML = "Unlock Widget Paging";
                }
                widgets.loadWidgetDisable();
            }
            for (i = 0; i < widgets.locations.length; i += 1) {
                if (widgets.locations[i].id) {
                    document.getElementById(widgets.locations[i].id).style.top = widgets.locations[i].top + "px";
                    document.getElementById(widgets.locations[i].id).style.left = widgets.locations[i].left + "px";
                    if (widgets.locations[i].scale) {
                        document.getElementById(widgets.locations[i].id).style.webkitTransform = "scale(" + widgets.locations[i].scale + ")";
                    }
                    if (widgets.locations[i].color) {
                        document.getElementById(widgets.locations[i].id).style.color = widgets.locations[i].color;
                    }
                }
            }
        } catch (err) {
            console.log(err + " in widgetLoaded");
        }
    },
    moveWidget: function (toThis) {
        var array = [],
            widgets = document.getElementsByClassName("mySBWidget"),
            newParent = document.getElementById(toThis);

        for (var i = 0; i < widgets.length; i++) {
            array.push(widgets[i].id);
        }

        for (var i = 0; i < array.length; i++) {
            newParent.appendChild(document.getElementById(array[i]));
        }
    },
    setWidgetDisableMove: function (addorremove) {
        //console.log(addorremove);
        var widgets = document.getElementsByClassName("mySBWidget");
        for (var i = 0; i < widgets.length; i++) {
            if (addorremove === "add") {
                widgets[i].classList.add('canceledIcons');
            } else {
                widgets[i].classList.remove('canceledIcons');
            }
        }
    },
    setWidgetDisable: function (stringVal, styleVal) {
        var div = document.getElementById('widgetDisable'),
            widgets = document.getElementsByClassName("mySBWidget");

        div.innerHTML = stringVal;
        for (var i = 0; i < widgets.length; i++) {
            widgets[i].style.pointerEvents = styleVal;
        }
    },
    loadWidgetDisable: function () {
        if (localStorage.widgetdisable) {
            widgets.setWidgetDisable('Enable Widget Touch', 'none');
        } else {
            widgets.setWidgetDisable('Disable Widget Touch', 'initial');
        }
    },
    widgetDisable: function () {
        if (localStorage.widgetdisable) {
            localStorage.removeItem('widgetdisable');
            widgets.setWidgetDisable('Disable Widget Touch', 'initial');
        } else {
            localStorage.widgetdisable = "YES";
            widgets.setWidgetDisable('Enable Widget Touch', 'none');
        }
    },
    toggleBackground: function () {
        if (localStorage.widgetBG) {
            localStorage.removeItem('widgetBG');
            widgets.moveWidget('container');
            document.getElementById('widgetBG').innerHTML = "Lock Widget Paging";
        } else {
            localStorage.widgetBG = "yes";
            widgets.moveWidget('statusbarItems');
            document.getElementById('widgetBG').innerHTML = "Unlock Widget Paging";
        }
    },
    selectWidget: function (el) {
        var widgetEl = document.getElementById(el);
        if (widgetEl === null) {
            this.widgetArray.push(el);
            this.loadJSFile('http://lockplus.us/mySB/widgets/' + el + '.js', this.widgetLoaded, el);
            this.closeWidget();
        } else {
            jPopup({
                type: "alert",
                message: "This widget already exists on your springboard.",
                okButtonText: "OK"
            });
        }
    },
    loadJSFile: function (name, func, title) {
        var milli = new Date().getMilliseconds(),
            link = name + "?" + milli,
            fileref = document.createElement('script');
        fileref.setAttribute("type", "text/javascript");
        fileref.setAttribute('title', title);
        fileref.setAttribute("src", link);
        fileref.async = true;
        if (fileref !== "undefined") {
            document.getElementsByTagName("head")[0].appendChild(fileref);
        }
        fileref.onload = function () {
            setTimeout(function () {
                func();
            }, 200);
        };
    },
    clearWidgets: function (downloaded) {
        //console.log('removing');
        for (var i = 0; i < widgets.widgetArray.length; i++) {
            widgets.removeWidgetFromSB(widgets.widgetArray[i]);
            //console.log("removed " + widgets.widgetArray[i]);
        }
        if (downloaded) {

        } else {
            localStorage.removeItem('widgetspositions');
        }
        widgets.widgetArray = [];
    },
    loadWidgets: function () {
        var i;
        if (localStorage.widgetspositions) {
            try {
                widgets.locations = JSON.parse(localStorage.getItem('widgetspositions'));
            } catch (err) {
                alert(err);
            }
        }
        for (i = 0; i < widgets.locations.length; i += 1) {
            try {
                widgets.selectWidget(widgets.locations[i].id);
            } catch (err) {
                alert(err);
                console.log("ERROR: " + widgets.locations[i].id + " " + err);
            }
        }
    },
    reload: function () {
        widgets.loadWidgets();
    }
};

document.getElementById('widgetPreviews').addEventListener('click', function (event) {
    widgets.selectWidget(event.target.title);
});

//localStorage.removeItem('widgetspositions');
widgets.loadWidgets();