var uploader = {
	showFrame : function (){
		var iframeB = document.createElement('iframe'),
			closeBtn = document.createElement('closeFrame');
		    iframeB.frameBorder = 0;
		    iframeB.width = screen.width;
		    iframeB.height = screen.height;
		    iframeB.id = "uploadFrame";
		    closeBtn.innerHTML = "Close Uploader";
		    closeBtn.id = "closeFrame";
		    closeBtn.onclick = function(){
		    	var iFrame = window.parent.document.getElementById('uploadFrame'),
		    		iFButton = document.getElementById('closeFrame');
					iFrame.parentNode.removeChild(window.parent.document.getElementById('uploadFrame'));
					iFButton.parentNode.removeChild(iFButton);
		    };
		    document.body.appendChild(iframeB);
		    document.body.appendChild(closeBtn);
		    iframeB.setAttribute("src", "upload.html");
		},
		closeFrame: function (){

		},
		showViewFrame: function (){
			var iframeB = document.createElement('iframe'),
			closeBtn2 = document.createElement('closeFrame');
		    iframeB.frameBorder = 0;
		    iframeB.width = screen.width;
		    iframeB.height = screen.height;
		    iframeB.id = "viewFrame";
		    iframeB.scrolling = "no";
		    closeBtn2.innerHTML = "Close Downloader";
		    closeBtn2.id = "closeViewFrame";
		    closeBtn2.onclick = function(){
		    	var iFrame = window.parent.document.getElementById('viewFrame'),
		    		iFButton = document.getElementById('closeViewFrame');
					iFrame.parentNode.removeChild(window.parent.document.getElementById('viewFrame'));
					iFButton.parentNode.removeChild(iFButton);
		    };
		    document.body.appendChild(iframeB);
		    document.body.appendChild(closeBtn2);
		    iframeB.setAttribute("src", "download.html");
		}
};
