/* 

    currentPage and pagesCount are referenced from global variables

*/
(function (doc) {
    var pageDots = {
        holder: doc.getElementById('pageDotHolder'),
        button: doc.getElementById('hidePageDots'),
        init: function () {
            var i, div, label, display;
            if(localStorage.sbpagedots){
                pagesCount = localStorage.sbpagedots;
                document.getElementById('container').style.width = screen.width * pagesCount + "px";
            }else{
                pagesCount = 5;
                document.getElementById('container').style.width = screen.width * pagesCount + "px";
            }
            for (i = 0; i < pagesCount; i++) {
                div = document.createElement('div');
                div.className = "dot";
                if (currentPage === 0 && i === 0) {
                    div.className += " doton";
                }
                this.holder.appendChild(div);
            }
            if (localStorage.sbhidepagedots) {
                display = 'none';
                label = "Show PageDots";
            } else {
                display = 'block';
                label = "Hide PageDots";
            }
            this.button.innerHTML = label;
            this.holder.style.display = display;
        },
        updatePageCount: function () {
            this.holder.innerHTML = "";
            pageDots.init();
        },
        changePageCount: function (value) {
            localStorage.sbpagedots = value;
            pagesCount = value;
            this.updatePageCount();
            document.getElementById('container').style.width = screen.width * pagesCount + "px";
        },
        changeDots: function (page) {
            var holderChildren = this.holder.children,
                i;
            for (i = 0; i < holderChildren.length; i++) {
                if (page === i) {
                    holderChildren[i].className = "dot doton";
                } else {
                    holderChildren[i].className = "dot";
                }
            }
        },
        hidePageDots: function () {
            var label, display;
            if (localStorage.sbhidepagedots) {
                label = "Hide PageDots";
                display = "block";
                localStorage.removeItem('sbhidepagedots');
            } else {
                label = "Show PageDots";
                display = "none";
                localStorage.sbhidepagedots = "YES";
            }
            this.button.innerHTML = label;
            this.holder.style.display = display;
        },
        reload: function(){
            if (localStorage.sbhidepagedots) {
                this.holder.style.display = "none";
                this.button.innerHTML = "Show PageDots";
            }else{
                this.holder.style.display = "block";
                this.button.innerHTML = "Hide PageDots";
            }
        }
    }
    window.PageDots = pageDots;
}(document));
