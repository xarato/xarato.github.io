window.onerror = customHandler;

function customHandler(desc,page,line,chr)  {
    alert(
    'JavaScript error occurred! \n'
     +'The error was handled by '
     +'a customized error handler.\n'
     +'\nError description: \t'+desc
     +'\nPage address:      \t'+page
     +'\nLine number:       \t'+line
    )
 return true
}

var settings = getSettings();
//var settings = "test";

if (settings === null) {
    settings = {};
}

var showLoadTime = settings.showLoadTime !== null ? !!+settings.showLoadTime : false;
if (showLoadTime) {
    var preDate = Date.now();
    var postDate = Date.now();
}


/*var allGood = true;
if (localStorage.lastLineReached === 458) {
    localStorage.lastLineReached = 23;
} else {
    allGood = false;
}*/

// Switches
var twentyfour = settings.twentyfour ? !!+settings.twentyfour : false;
var zero = settings.zero ? !!+settings.zero : false;
var replaceagenda = settings.replaceagenda ? JSON.parse(settings.replaceagenda) === 0 : true; // To convert a value of "1" to true and "0" to false
var mini = settings.mini ? !!+settings.mini : true;
var alarm = settings.alarm ? !!+settings.alarm : true;
var celsius = settings.celsius ? !!+settings.celsius : false;
var updateBGColor = settings.updateBGColor ? !!+settings.updateBGColor : true;
var BGOpacity = settings.BGOpacity ? JSON.parse(settings.BGOpacity) : 1.0;
var skipMini = settings.skipMini ? !!+settings.skipMini : false;
var showSeconds = settings.showSeconds ? !!+settings.showSeconds : false;
var animate = settings.animations ? !+settings.animations : true;
var colorChange = settings.colorChange ? !!+settings.colorChange : true;
var showIndex = settings.showIndex ? !!+settings.showIndex : true;
var smallSeconds = settings.smallSeconds ? !!+settings.smallSeconds : true;
//alert("mini: " + mini + "\n skipMini: " + skipMini);

// Timing
$$('.line').sel().style.webkitAnimationDuration = (!isNaN(settings.lineLoadDuration) ? settings.lineLoadDuration : "0.55") + "s";
$$('.line').sel().style.webkitAnimationDelay = (!isNaN(settings.lineLoadDelay) ? settings.lineLoadDelay : "0.2") + "s";
$$('.footer').sel().style.webkitAnimationDuration = (!isNaN(settings.footerDuration) ? settings.footerDuration : "0.55") + "s";
$$('.backgroundindex').sel().style.webkitAnimationDuration = (!isNaN(settings.indexDuration) ? settings.indexDuration : "0.9") + "s";

// Multi-selects
var colorLineWhen = settings.colorLineWhen ? JSON.parse(settings.colorLineWhen) : 0;
var showPercentageWhen = settings.showPercentageWhen ? JSON.parse(settings.showPercentageWhen) : 1;

// Colors
var chargingColor = getColorFromSettings(settings.chargingColor, "#4ED964");

var loadCount = localStorage.loadCount ? JSON.parse(localStorage.loadCount) : 0;

if (!updateBGColor && settings.backgroundColor != "") {
    if (settings.backgroundColor.charAt(0) === "#") {
        localStorage.onepluscolor = hexToRGB(settings.backgroundColor);
    } else {
        localStorage.onepluscolor = settings.backgroundColor;
    }
}

//if (localStorage.lastLineReached === 23 && allGood) localStorage.lastLineReached = 50;

/*if (settings.textColor != "") {
    localStorage.oneplustcolor = settings.textColor;
}*/

localStorage.oneplustcolor = getColorFromSettings(settings.textColor, "#ffffff");

if (alarm) {
    $$('#alarmico').sel().src = "clock.svg";
}

loadCount = loadCount + 1;
localStorage.setItem('loadCount', loadCount);

if(mini){
    setMini(false);
}

//Battery/Charging info support
var batteryPercent = batteryPercent();
var isCharging = isCharging();

// 0 = Always
// 1 = When charging
// 2 = When not charging
// 3 = Never
if (colorLineWhen === 0 || (colorLineWhen === 1 && isCharging) || (colorLineWhen === 2 && !isCharging)) {
    document.styleSheets[0].addRule(".line:before", "right: " + (100 - batteryPercent) + "%;");
}
if (showPercentageWhen === 0 || (showPercentageWhen === 1 && isCharging) || (showPercentageWhen === 2 && !isCharging)) {
    $$('#line').sel().dataset.percentage = batteryPercent + "%";
}

document.styleSheets[0].addRule(".line:before", "background-color: " + chargingColor + ";");

if(localStorage.onepluscolor){
    var css = ".ani{background-color:"+localStorage.onepluscolor+"};.off{background-color:"+localStorage.onepluscolor+"};.panel{background-color:"+localStorage.onepluscolor+"};";

    var htmlDiv = document.createElement('div');
    htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
    document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);
    /*var fakeDiv = document.createElement('div');
    fakeDiv.style.display = 'none';
    fakeDiv.style.className = 'ani';
    $$('.ani').sel().backgroundColor = localStorage.onepluscolor;
    fakeDiv.style.className = 'off'
    $$('.off').sel().backgroundColor = localStorage.onepluscolor;
    fakeDiv.style.className = 'panel';
    $$('.panel').sel().backgroundColor = localStorage.onepluscolor;*/
}
if(localStorage.oneplustcolor){
    var nscolor = localStorage.oneplustcolor;
    var css = "html{color:"+nscolor+";}.line{background-color:"+nscolor+";}#weathericons{fill:"+nscolor+";}#clocksvg{fill:"+nscolor+"; }";

    var htmlDiv = document.createElement('div');
    htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
    document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);
}

//if (localStorage.lastLineReached === 50 && allGood) localStorage.lastLineReached = 92;

function checkAnimation() {
    if (animate) {
        var animationTimes = !!+settings.animationTimes;
        if (animationTimes) {
            var startHour = (settings.startHour) ? Math.floor(JSON.parse(settings.startHour)) : 0;
            var startMinute = (settings.startMinute) ? Math.floor(JSON.parse(settings.startMinute)) : 0;
            var stopHour = (settings.stopHour) ? Math.floor(JSON.parse(settings.stopHour)) : 0;
            var stopMinute = (settings.stopMinute) ? Math.floor(JSON.parse(settings.stopMinute)) : 0;

            //alert("startHour: " + startHour + "\n startMinute:" + startMinute + "\n stopHour: " + stopHour + "\n stopMinute: " + stopMinute);

            var currentDate = new Date();
            var startDate = new Date();
            var stopDate = new Date();

            startDate.setHours(startHour, startMinute, 0); // setHours(Hour, Minute, Second)
            stopDate.setHours(stopHour, stopMinute, 59);

            if (stopDate < startDate) {
                stopDate.setDate(startDate.getDate() + 1); // Increase to the next day
                if (currentDate >= startDate && currentDate <= stopDate) animate = false;

                stopDate.setDate(startDate.getDate() - 2);
                if (currentDate >= startDate && currentDate <= stopDate) animate = false;

                stopDate.setDate(startDate.getDate());
                startDate.setDate(stopDate.getDate() - 1);
                if (currentDate >= startDate && currentDate <= stopDate) animate = false; // I hate repeating lines like this but this is the simplest, easiest way that I see
            } else {
                if (currentDate >= startDate && currentDate <= stopDate) animate = false;
            }
        }
    }
}
checkAnimation();

function showall(){
    var allevents = [];
    var evnt = getcalendarEvents(0,0);
    for (var i = 0; i < evnt.length; i++) {
        allevents.push(evnt[i].split(':')[1]);
    };
    allevents = String(allevents).replace(/,/g, '\n');
    swal({   title: "Events",   text: allevents, animation: "slide-from-top", confirmButtonColor: "#4f4f4f"  });
}

function colorchange(){
    alert("colorChange()");
swal({
        title: "Change BG color, to change text type text:color.",
        text: "You can use color, hex, or rgba.",
        type: "input",
        showCancelButton: true,
        confirmButtonColor: "#4f4f4f",
        closeOnConfirm: true,
        animation: "slide-from-top",
        inputPlaceholder: "#52b5d5"
    },
    function(inputValue) {
        if (inputValue === false) {document.body.scrollTop = 0; return false;}
        if (inputValue === "") {
            swal.showInputError("You need to write something!");
            return false
        }
        if(inputValue.split(':')[0] == "text"){
            localStorage.setItem('oneplustcolor',inputValue.split(':')[1]);
            var ncolor = inputValue.split(':')[1];
            var css = "html{color:"+ncolor+";}.line{background-color:"+ncolor+";}#weathericons{fill:"+ncolor+";}#clocksvg{fill:"+ncolor+"; }";
            var htmlDiv = document.createElement('div');
            htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
            document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);
            document.body.scrollTop = 0;
        }
        else{
            $$('#panel').sel().style.backgroundColor = inputValue;
            localStorage.setItem('onepluscolor',inputValue);
            document.body.scrollTop = 0;
        }
    });
}

if (!replaceagenda) {
	$$('#reminder').set((getcalendarEvents(0,0) === "No Events") ? "Nothing on the agenda" : getcalendarEvents(0,0)[0].split(':')[1]);

	if(getcalendarEvents(0,0).length > 1){
	    if(getcalendarEvents(0,0) !== "No Events"){
	        $$('#reminder').set($$('#reminder').inner()+"<span class='more' id='more'> +"+ (getcalendarEvents(0,0).length - 1)+" </span>");
	        $$('#more').sel().addEventListener('touchend',function(){
	            showall()
	        });
	    }
	}
}

//if (localStorage.lastLineReached === 92 && allGood) localStorage.lastLineReached = 152;

function setIdClass(id, className) {
    clearOfAnimationClasses(id);
    $$('#' + id).sel().className = className;
}

/*function addClassToId(id, toAdd) {
    clearOfAnimationClasses(id);
    $$('#' + id).sel().className = ('#' + id).sel().className + toAdd;
}*/ // For some reason this didn't work. I have no freaking idea why and it wasn't wortht the time to debug.

//This assumes that you put the animation classes after the other classes
function clearOfAnimationClasses(id) {
    var splitClasses = $$('#' + id).sel().className.split(' ');
    if (splitClasses[0] != $$('#' + id).sel().className) { // If what's before the space is not equal to what's after
        $$('#' + id).sel().className = splitClasses[0]; // Set the class to only what's before
    }
    if (typeof callback === "function") {
        callback();
    }
}

function setMini(animation) {
    if (animation) {
        clearOfAnimationClasses('panel');
        $$('#panel').sel().className = $$('#panel').sel().className + " panelFullToMini";
        clearOfAnimationClasses('footer');
        $$('#footer').sel().className = $$('#footer').sel().className + " footerFullToMini";
        $$('#agenda').sel().style.marginTop = "20px";
    } else {
        $$('#panel').sel().style.marginTop = "160px";
        clearOfAnimationClasses('footer');
        $$('#footer').sel().style.marginTop = "-155px";
        $$('#agenda').sel().style.marginTop = "20px";
    }
}

function setFull(animation) {
    if (animation) {
        clearOfAnimationClasses('panel');
        $$('#panel').sel().className = $$('#panel').sel().className + " panelMiniToFull";
        clearOfAnimationClasses('footer');
        $$('#footer').sel().className = $$('#footer').sel().className + " footerMiniToFull";
        $$('#agenda').sel().style.marginTop = "0px";
    } else {
        $$('#panel').sel().style.marginTop = "0px";
        $$('#footer').sel().style.marginTop = "5px";
        $$('#agenda').sel().style.marginTop = "0px";
    }
}

function opens() {
	if (animate) {
    	$$('#line').sel().className = 'line lineAnimateIn';
    	setIdClass('panel', 'ani animateIn');
    	$$('.animateIn').sel().style.webkitAnimationDuration = (!isNaN(settings.wholeLoadDuration) ? settings.wholeLoadDuration : "0.2") + "s";
    } else {
    	$$('#line').sel().className = 'line';
    	$$('.line').sel().width = "326px";
    	$$('#panel').sel().className = 'ani';
    }
    $$('#backgroundindex').sel().innerHTML = localStorage.paletteIndex; // This ensures that the actual index and the displayed index are always in sync
    $$('#open').sel().style.display = "none";
};


var el = $$('#panel').sel();
swipedetect(el, function(swipedir) {
    if (swipedir =='down') {
        //alert("Swiped Down \nSkipMini: " + skipMini + "\nMini: " + mini + "\nOther: " + (!mini && !+settings.mini))
        if(skipMini || mini || (!mini && !+settings.mini)) { // Make it fully disappear
            $$('#open').sel().style.display = "block";
            if (animate) {
            	setIdClass('panel', 'off animateOut');
        	} else {
        		$$('#panel').sel().className = 'off';
        	}
            $$('.off').sel().style.backgroundColor = localStorage.onepluscolor ? localStorage.onepluscolor : "#52b5d5";
            window.setTimeout(function() {
                $$('#line').sel().className = 'line'; // So it can be re-triggered later
            }, JSON.parse(!isNaN(settings.wholeLoadDuration) ? settings.wholeLoadDuration : "0.2") * 475); // The *500 is to convert seconds to milliseconds, then divide by 2
        } else if (settings.mini ? !!+settings.mini : true) { // Just go into mini mode
            setMini(animate);
            mini = true;
        }
    }
    else if (swipedir == 'right') {
        unlockphone();
    }
    else if (swipedir == 'left' && colorChange && updateBGColor) { // Change to the next palette color
        tempPaletteIndex = JSON.parse(localStorage.paletteIndex); // The palette index it's currently on
        tempPalette = JSON.parse(localStorage.palette);
        localStorage.setItem('paletteIndex', tempPaletteIndex === tempPalette.length - 1 ? tempPaletteIndex - (tempPalette.length - 1) : tempPaletteIndex + 1); // This logic is for cycling back around... 8, 9, 0, 1, 2...
        setBackgroundColor(getPaletteRGB(JSON.parse(localStorage.palette), localStorage.paletteIndex));

        // Change indicator number stuff (top right)
        if (showIndex) {
            $$('#backgroundindex').sel().innerHTML = localStorage.paletteIndex; // Actually change the number
            if (animate) {
                // Got this method ↓ from: https://css-tricks.com/restart-css-animation/
                $$('#backgroundindex').sel().classList.remove("backgroundindexAnimate");
                $$('#backgroundindex').sel().offsetWidth = $$('#backgroundindex').sel().offsetWidth; // I have no idea why this is necessary but it is
                $$('#backgroundindex').sel().classList.add("backgroundindexAnimate");
            } else {
                $$('#backgroundindex').sel().style.opacity = 1.0;
                window.setTimeout(function() {
                    $$('#backgroundindex').sel().style.opacity = 0.0;
                }, JSON.parse(isNaN(settings.indexDuration) ? settings.indexDuration : "0.9") * 500);
            }
        }
    }
    else if (swipedir == 'up') {
        setFull(animate);
        mini = false;
    }
});

//if (localStorage.lastLineReached === 152 && allGood) localStorage.lastLineReached = 244;

var el2 = $$('.open').sel();
swipedetect(el2, function(swipedir){
    if (swipedir =='up'){
        opens();
        if (!!+settings.mini) {
            setMini(false);
            mini = true;
        } else {
            setFull(false);
            mini = false;
        }
    }
    else if (swipedir == 'right'){
        unlockphone();
    }

});

function updateTime(updateDate) {
    var append;
    if (showSeconds) {
        if (smallSeconds) {
            append = document.createElement("mark");
            append.className = "smallText";
            append.style.fontSize = (!isNaN(settings.smallSecondsSize) ? settings.smallSecondsSize : "45") + "px";
            append.appendChild(document.createTextNode(":" + clock.seconds()));
        } else {
            append = document.createTextNode(":" + clock.seconds());
        }
    } else {
        append = document.createTextNode("");
    }

	$$('#time').set(clock.hour(twentyfour,zero) + ":" + clock.minute());
    $$('#time').sel().appendChild(append);
	if (updateDate) {
		switch (settings.dateLayout ? JSON.parse(settings.dateLayout) : 2) {
		    case 0:
		        $$('#date').set(weekday[clock.day()] + " " + clock.date() + " " + month[clock.month()]);
		        break;
		    case 1:
		        $$('#date').set(weekday[clock.day()] + ", " + clock.date() + " " + month[clock.month()]);
		        break;
		    case 2:
		        $$('#date').set(weekday[clock.day()] + ", " + month[clock.month()] + " " + clock.date());
		        break;
		    case 3:
		        $$('#date').set(weekday[clock.day()] + " " + month[clock.month()] + " " + clock.date());
		        break;
		    case 4:
		        $$('#date').set(weekday[clock.day()]);
		        break;
		    case 5:
		        $$('#date').set(month[clock.month()] + " " + clock.date());
		        break;
		    case 6:
		        $$('#date').set(clock.date() + " " + month[clock.month()]);
		        break;
		}
	}
}
updateTime(true);

// This is all to first sync the updating with the actual time, while optimizing to ensure that it's not updating excessively
// then to continue updating the time at a reasonable rate.
var millisecondRefresh = setInterval(function() { // Check every millisecond if we're on the tenth millisecond
	clock.refreshDate();
	if (clock.rawMilliseconds() % 10 === 0) { // If we're on a tenth millisecond, like 10, 20, 150, etc.
		window.clearInterval(millisecondRefresh); // Stop the millisecond updating
		var startingSeconds = clock.rawSeconds();
		var decaMillisecondsRefresh = setInterval(function() { //Check every ten milliseconds to see if the second changed
			clock.refreshDate();
			if (clock.rawSeconds() !== startingSeconds) {
				updateTime(false);
				window.clearInterval(decaMillisecondsRefresh); // End the updating every 10 milliseconds
				var startingMinute = clock.rawMinutes();
				var secondsRefresh = setInterval(function () { // Check every second to see if the minute (or second) changed
					clock.refreshDate();
					if (showSeconds) {
					   updateTime((clock.hour(true, false) === 0 && clock.minute === 0) ? true : false); // This ternary is to only update the date if it's possible for it to change
					   //if (clock.rawSeconds() === 0) checkAnimation();
                    } else if (clock.rawMinutes() !== startingMinute) {
						updateTime((clock.hour(true, false) === 0 && clock.minute === 0) ? true : false);
						window.clearInterval(secondsRefresh); // End the second updating
                        //checkAnimation();
						var minuteRefresh = setInterval(function() { // Update the time every minute
							clock.refreshDate();
							updateTime((clock.hour(true, false) === 0 && clock.minute === 0) ? true : false);
                            //checkAnimation();
						}, 60000);
					}
				}, 1000);
			}
		}, 10);
	}
}, 1);

//if (localStorage.lastLineReached === 244 && allGood) localStorage.lastLineReached = 325;

if (alarm) {
    var setAlarm, alarmHour, alarmMinute, padMinute;
    setAlarm = iOSAlarms.getAlarmTimes();
    if (setAlarm !== "No Alarms") {
        alarmHour = Number(setAlarm[0].split(':')[0]);
        alarmMinute = Number(setAlarm[0].split(':')[1]);
        padMinute = (alarmMinute < 10) ? "0" + alarmMinute : alarmMinute;
        $$('#alarm').set("Alarm " + alarmHour + ":" + padMinute);
    } else {
        $$('#alarm').set('Alarm not set');
    }
} else {
    $$('#alarm').set('');
}

var weatherdivs = function () {
    //$$('#wicon').sel().style.display = "none";
    $$('#wicon').sel().src = "svg/"+weather.condition()+".svg";
    showSVG('#wicon', true);

    if(replaceagenda){
        $$('#agenda').set('Weather');
        $$('#reminder').set((celsius) ? Fcondition[weather.condition()]+ ", " + weather.temp(celsius)+"&deg;C" : Fcondition[weather.condition()]+ ", " + weather.temp(celsius)+"&deg;F")
    }
};

try {
    weather.start(60000 * 15);
} catch (err) {
    $$('#date').set($$('#date').sel().innerHTML + " - Weather went wrong");
}

function refreshUri(uri, callback) {
    var reload = function () {
        // Force a reload of the iframe
        this.contentWindow.location.reload(true);

        // Remove `load` event listener and remove iframe
        this.removeEventListener('load', reload, false);
        this.parentElement.removeChild(this);

        // Run the callback if it is provided
        if (typeof callback === 'function') {
            callback();
        }
    };

    var iframe = document.createElement('iframe');
    iframe.style.display = 'none';

    // Reload iframe once it has loaded
    iframe.addEventListener('load', reload, false);

    // Only call callback if error occured while loading
    iframe.addEventListener('error', callback, false);
    iframe.src = uri;
    document.body.appendChild(iframe);
}

function replaceImage(oldImage, loadedCall) {
    return function() {
        var newImage = new Image();
        newImage.style = "display: none";
        newImage.src = oldImage.src;
        newImage.id = oldImage.id;
        newImage.onload = loadedCall;
        oldImage = newImage;
    }
}

function hexToRGB(hex) {
    var stringResult = "";
    if (hex.charAt(0) === "#" && hex.length === 7) {
        hex = hex.substring(1,7);
        try {
            stringResult = stringResult + "rgba(" + parseInt(hex.substring(0,2), 16) + "," + parseInt(hex.substring(2,4), 16) +
                "," + parseInt(hex.substring(4,6), 16) + "," + BGOpacity + ")";
        } catch (e) {
            alert("You probably didn't format your hex value of\"" + hex + "\" correctly.")
        }
    }
    return stringResult;
}

//No longer needed
/*function getRGB(colorThief, image, quality) {
    var color = colorThief.getColor(image, quality);
    var rgb = "rgba(" + color + "," + BGOpacity + ")";
    return rgb;
}*/

function getColorFromSettings(setting, def) { // Because the word "default" is a no-no
    if (typeof setting !== "undefined" && setting.length !== 0) { //If this has been specified
        return (setting.charAt(0) === "#" ? hexToRGB(setting) : setting);
    } else {
        return def;
    }
}

function getPaletteRGB(palette, index) {
    try {
        var numIndex = JSON.parse(index);
        var rgba = "rgba(" + palette[numIndex][0] + "," + palette[numIndex][1] + "," + palette[numIndex][2] + "," + BGOpacity + ")";
        return rgba;
    } catch (error) {
        alert("index: " + index + "\n length: " + palette.length);
    }
}

function setBackgroundColor(rgbColor) {
    $$('#panel').sel().style.backgroundColor = rgbColor; // Sets it for just this instance
    localStorage.setItem('onepluscolor',rgbColor); // Permanent solution
}

function updateBackgroundColor() {
    if (updateBGColor) {
        try {
            var colorThief = new ColorThief();

            var newWallpaper = new Image();
            newWallpaper.style = "display: none";
            newWallpaper.id = "wallpaper" + loadCount;
            newWallpaper.src = "file:///private/var/mobile/Library/SpringBoard/LockBackgroundThumbnail.jpg";

            refreshUri("file:///private/var/mobile/Library/SpringBoard/LockBackgroundThumbnail.jpg", replaceImage(newWallpaper, loaded()));

            function loaded() {
                //alert('Main.js \n Width: ' + newWallpaper.width + "\n Height: " + newWallpaper.height);
                if (newWallpaper.width > 0 && newWallpaper.height > 0) {

                    //This just gets the data for the top left pixel of the image. A different image will (almost, whatever) always have a different top left pixel.
                    var canvas = document.createElement('canvas');
                    var context = canvas.getContext('2d');
                    context.drawImage(newWallpaper, 0, 0);
                    var pixels = context.getImageData(0, 0, 1, 1).data;
                    var rgbaFast = "[" + pixels[0] + ", " + pixels[1] + ", " + pixels[2] + ", " + pixels[3];

                    //var rgbColorFast = getRGB(colorThief, newWallpaper, 10000); -- Old Method... good to keep
                    //alert("rgbColorFast = " + rgbaFast + "\n localStorage.prevRGB = " + localStorage.prevRGB + "\n" + updateBGColor + "\n OPC: " + localStorage.onepluscolor + "\n SBC: " + getColorFromSettings(settings.backgroundColor, "nope"));
                    //alert("OPC: " + localStorage.onepluscolor + "\nBC:" + getColorFromSettings(settings.backgroundColor, "nope"))
                    if ((rgbaFast !== localStorage.prevRGB) || (localStorage.onepluscolor === getColorFromSettings(settings.backgroundColor, "nope"))) {
                        var palette = colorThief.getPalette(newWallpaper, 10, 3);
                        localStorage.setItem('paletteIndex', 0);
                        localStorage.setItem('palette', JSON.stringify(palette));
                        var rgbColorSlow = getPaletteRGB(palette, localStorage.paletteIndex);
                        setBackgroundColor(rgbColorSlow);
                        $$('#date').set($$('#date').sel().innerHTML + " - Background updated");
                    }

                    localStorage.setItem('prevRGB', rgbaFast);
                }
            }
        } catch (err) {
            $$('#date').set($$('#date').sel().innerHTML + " - Background went wrong");
        }
    }
}
updateBackgroundColor();

//Ensure that the opacity is synced with the settings
var currentBGColor = localStorage.onepluscolor;
var parts = currentBGColor.split(",");
setBackgroundColor(parts[0] + "," + parts[1] + "," + parts[2] + "," + BGOpacity + ")");

//if (localStorage.lastLineReached === 325 && allGood) localStorage.lastLineReached = 444;

/*$$('.time').sel().addEventListener('touchend', function() {
    location.reload();
});*/

//alert(getLastBackgroundUpdate());

opens();
if (showLoadTime) {
    postDate = Date.now();
    $$('#swipe').sel().innerHTML = "-" + (postDate - preDate) + "ms-";
} else {
	$$('#swipe').sel().innerHTML = "&#8209;Swipe&#8209;"; // Have to do the freaking ASCII codes for the dash because otherwise it creates a line break
}

//if (localStorage.lastLineReached === 444 && allGood) localStorage.lastLineReached = 458;
//$$('#swipe').sel().innerHTML = "-" + localStorage.lastLineReached + "-";