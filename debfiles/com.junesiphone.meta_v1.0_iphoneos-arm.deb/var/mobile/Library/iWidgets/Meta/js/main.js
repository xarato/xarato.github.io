//var highColor = "red"; //set from Options.plist
//var bgColor = "red"; //set from Options.plist
document.querySelector('.container').style.backgroundColor = bgColor;
document.querySelector('.batterybar').style.backgroundColor = highColor;
document.getElementById('drawer').style.color = highColor;
document.getElementById('home').style.color = highColor;
document.getElementById('switchertext').style.color = highColor;

if(hideApps){
    document.getElementById('drawer').style.display = 'none';
}


var meta = {
    changing: false,
    currentApp: '',
    appArray: [],
    change: function(el) {
        this.currentApp = el.parentNode.id;
        document.querySelector('.list').style.display = "block";
        console.log(el.parentNode.id);
    },
    toggleViews: function(el) {
        var divs = ['home', 'fav', 'social', 'music'];
        for (i = 0; i < divs.length; i += 1) {
            document.querySelector('.' + divs[i]).style.display = "none";
            document.getElementById(divs[i]).style.color = "white";
        }
        document.querySelector('.' + el).style.display = "block";
        document.getElementById(el).style.color = highColor;
    },
    openApp: function(el) {
        cyMeta.launchApp(document.getElementById(el).getElementsByTagName('img')[0].title);
    },
    createAppList: function() {
        for (var i = 0; i < cyMeta.appInfo.length; i++) {
            name = cyMeta.appInfo[i].split('-')[0];
            bundle = cyMeta.appInfo[i].split('-')[1];
            try {
                badge = cyMeta.getBadge(String(bundle));
                if (badge == 0) {
                    badge = '';
                } else {
                    badge = "<a class='badge'>" + badge + "</a>";
                }
            } catch (err) {}
            var li = document.createElement("li");
            li.setAttribute('name', bundle);
            li.innerHTML = name + " " + badge;
            li.className = 'icon';
            document.querySelector('.list').appendChild(li);
        };

    },
    showAppList: function() {
        document.querySelector('.list').style.display = "block";

    },
    setBattery: function(battery, timeout, count, element, elwidth) {
        var calc, width, interval;
        width = 0;
        calc = Math.round((battery / 100) * elwidth);
        document.querySelector('.' + element).style.width = calc + 'px';
    },
    loadBattery: function() {
        document.getElementById('percent').innerHTML = cyMeta.getBattery() + "%";
        this.setBattery(cyMeta.getBattery(), 1, 3, 'batterybar', 225);
    },
    checkBadges: function() {
        var apps = document.querySelector('.apps'),
            badge;
        for (var i = 0; i < apps.children.length; i++) {
            badge = (cyMeta.getBadge(String(apps.children[i].getAttribute('name'))) === 0) ? "" : cyMeta.getBadge(String(apps.children[i].getAttribute('name')));
            apps.children[i].setAttribute('title', badge);
        }
    },
    generateSwitcher: function(switcher) {
        var item, name, sp;
        for (var i = 0; i < switcher.length; i++) {
            if(cyMeta.iOSVersion < 9){
                item = switcher[i].displayItems[0].displayIdentifier;
            }else{
                item = switcher[i].displayIdentifier;
            }
                name = item.split('.')[2];
                sp = document.createElement("span");

            if (name == undefined) {
                name = item.split('.')[0];
            }
            sp.setAttribute('name', item);
            sp.innerHTML = name;
            document.querySelector('.switcherlist').appendChild(sp);
        }

    },
    createSwitcher: function(switcher) {
        var state = document.querySelector('.switcherlist');
            state.innerHTML = "";
        if (state.style.display === "none") {
            state.style.display = "block";
            this.generateSwitcher(switcher);
            document.getElementById('switchertext').style.display = 'block';
        } else {
            state.style.display = "none";
            document.getElementById('switchertext').style.display = 'none';
        }
    },
    changeEditMode: function() {
        var elements = document.getElementsByClassName('editable'),
            i,
            elementArray;
        if (elements.length === 0) {
            elements = document.getElementsByClassName('editableNow');
            elementArray = [].slice.call(elements, 0);
            for (i = 0; i < elementArray.length; i += 1) {
                elementArray[i].className = "editable";
                meta.changing = false;
            }
        } else {
            elementArray = [].slice.call(elements, 0);
            for (i = 0; i < elementArray.length; i += 1) {
                elementArray[i].className = "editableNow";
                meta.changing = true;
            }
        }
    },
    changeApp: function(app, name) {
        var cA = document.getElementById(app).getElementsByTagName('img')[0],
            ext = "var/mobile/Library/iWidgets/Meta/";
        source = "icon/bundles/" + name + ".svg";
        if (!cyMeta.fileExists(ext + source)) {
            source = "icon/bundles/noicon.svg";
        }
        cA.title = name;
        cA.src = source;
        meta.appArray.push(app + '-' + name);
    }
}; //end
document.getElementById('picker').addEventListener('touchstart', function(el) {
    if (el.target.tagName === "SPAN") {
        meta.toggleViews(el.target.id);
    }
});
document.getElementById('switchericon').addEventListener('touchstart', function() {

    meta.createSwitcher(cyMeta.switcherApps());
});
document.getElementById('menu').addEventListener('touchstart', function() {
    var display = document.querySelector('.list').style.display;
    if (display === "none") {
        meta.showAppList();
        document.getElementById('lists').scrollTop = 0;
    } else {

        document.querySelector('.list').style.display = "none";

    }
});
document.querySelector('.quickapps').addEventListener('touchend', function(el) {
    meta.openApp(el.target.id);
});
document.querySelector('.switcherlist').addEventListener('touchend', function(el) {
    cyMeta.launchApp(el.target.getAttribute('name'));
    el.preventDefault();
});
document.getElementById('refresh').addEventListener('click', function() {
    document.querySelector('.list').innerHTML = '<li id="settings" class="fa fa-cog"></li><li id="refresh" class="fa fa-refresh"></li>';
    cyMeta.appInfo = [];
    cyMeta.getAppList();
    cyMeta.appInfo.sort();
    meta.createAppList();
});
document.getElementById('settings').addEventListener('click', function() {
    meta.changeEditMode();
    document.querySelector('.list').style.display = "none";
});

//change to touchend
document.querySelector('.list').addEventListener('touchend', function(el) {
    if (el.target.id != 'refresh' && el.target.id != 'settings') {
        if (meta.changing) {
            if (meta.currentApp) {
                if (!cyMeta.dragging) {
                    meta.changeApp(meta.currentApp, el.target.getAttribute('name'));
                    meta.changeEditMode();
                    localStorage.setItem('appArray', meta.appArray);
                    meta.changing = false;
                    meta.currentApp = '';
                }
            }
        } else {
            cyMeta.launchApp(el.target.getAttribute('name'));
        }
    }
});



document.body.addEventListener('touchmove', function() {
    cyMeta.dragging = true;
});
document.body.addEventListener('touchstart', function() {
    cyMeta.dragging = false;
});

//document.querySelector('.list').style.display = "block";

document.querySelector('.apps').addEventListener('touchstart',function(el){
    //alert(el.target.getAttribute('name'));
    if (el.target.tagName === "SPAN") {
        cyMeta.dragging = false;
        cyMeta.launchApp(el.target.getAttribute('name'));
    }
});

function tick() {
    meta.loadBattery();
    meta.checkBadges();
    setTimeout(tick, 10000);
}
function loadApps(){
    if (localStorage.appArray) {
        appAr = localStorage.appArray;
        AA = appAr.split(",");
        for (var i = 0; i < AA.length; i++) {
            app = AA[i].split('-')[0];
            name = AA[i].split('-')[1];
            meta.changeApp(app, name);
        };
    }
    if(disableMove){
      document.body.addEventListener('touchmove', function (e) {
        if(e.srcElement != '[object HTMLLIElement]' && e.srcElement != '[object HTMLSpanElement]'){
          e.preventDefault();
        }
      });
    }
}

if(airMail){
    document.getElementById('mail').setAttribute('name', 'com.airmailapp.iphone');
}

cyMeta.getAppList();
cyMeta.appInfo.sort();
meta.createAppList();
loadApps();
tick();

document.getElementById('drawer').addEventListener('touchstart',function(){
    if(drawer === 'Fern'){
        cyMeta.fern();
    }else if(drawer === 'InstaLauncher'){
        cyMeta.instalauncher();
    }else if (drawer === 'AppDrawer'){
        cyMeta.appdrawer();
    }
});



