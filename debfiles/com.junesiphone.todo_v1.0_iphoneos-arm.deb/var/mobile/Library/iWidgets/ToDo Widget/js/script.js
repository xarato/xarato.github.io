
(function () {
    'use strict';
    var Tasks = {};
    Tasks = {
        init: function () {
            var button1, button2, inputtext;
            button1 = document.getElementById('addbutton');
            inputtext = document.getElementById('tasktext');
            inputtext.addEventListener('blur',Tasks.createTask);
            button1.addEventListener('click', Tasks.createTask);
            button2 = document.getElementById('removebutton');
            button2.addEventListener('click', Tasks.removeTasks);
            Tasks.getAllTasks();
        },
        data: (JSON.parse(localStorage.getItem('data')) ? JSON.parse(localStorage.getItem('data')) : ["Add a new Task"]),
        moving: false,
        element: '',
        createTask: function () {
            var input = document.getElementById('tasktext');
            if (input.value !== '') {
                Tasks.data.push(input.value);
                input.value = '';
                Tasks.saveTasks();
                Tasks.getAllTasks();
            }
        },
        removeTasks: function () {
            localStorage.clear();
            location.reload();
        },
        saveTasks: function () {
            localStorage.setItem('data', JSON.stringify(Tasks.data));
        },
        getAllTasks: function () {
            var i, list, task;
            list = document.getElementById('list');
            list.innerHTML = '';
            for (i = 0; i < Tasks.data.length; i += 1) {
                task = document.createElement('li');
                task.className = 'task';
                task.setAttribute('data-id', i);
                task.innerHTML = '<div class="text"> ' + Tasks.data[i] + '</div>';
                task.children[0].addEventListener('click', Tasks.deleteTask);
                list.appendChild(task);
            }
        },
        deleteTask: function (e) {
            var task, id;
            task = e.target.parentNode;
            id = parseInt(task.getAttribute('data-id'));
            Tasks.data.splice(id, 1);
            Tasks.saveTasks();
            Tasks.getAllTasks();
        }

    };
    Tasks.init();
}());