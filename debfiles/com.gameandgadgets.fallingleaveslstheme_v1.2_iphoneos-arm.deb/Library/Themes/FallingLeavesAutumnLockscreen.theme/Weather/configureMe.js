var locale = 24505179; // The location WOEID, see README.txt for more information
var isCelsius = true;
var enableBG = true; // Enable semi-transparent background or not. Recommended for bright/light coloured wallpapers.
var updateInterval = 3600; // In seconds, time between a new update is fetched
var failedInterval = 300; // In seconds, time between another attempt is made for an update when the previous one fails
var ampm_format = true; // Whether to have in 12 hour format(true) or 24 hour format(false)
var show_ampm = true; // Whether to show AM/PM in time display(true) or not(false)